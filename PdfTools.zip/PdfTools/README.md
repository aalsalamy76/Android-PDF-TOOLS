# PDFBox — محرّر PDF متكامل

تطبيق Android شخصي يعمل دون إنترنت: قراءة، تعليقات (قلم، تظليل، نص)، توقيع، تعبئة النماذج، OCR، دمج، تقسيم، تنظيم الصفحات، ضغط، حماية بكلمة مرور، ترقيم، علامة مائية، مسح بالكاميرا، وتحويل.
الواجهة بالعربية (من اليمين لليسار) مع الإنجليزية والفرنسية والإسبانية، ووضع فاتح وداكن.

المطوّر: **Abdullah AL-SALAMY** — https://www.linkedin.com/in/abdullah-a-2982451a6

## المتطلبات
- Android Studio Koala (2024.1.1) أو أحدث
- JDK 17 (المدمج مع Android Studio يكفي)
- Android SDK Platform 34

## البناء
1. افتح المجلد `PdfTools` من **File > Open** في Android Studio.
2. انتظر انتهاء **Gradle Sync** (يحتاج إنترنت مرة واحدة لتنزيل المكتبات).
3. **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. الملف الناتج: `app/build/outputs/apk/debug/app-debug.apk`

## التقنيات
Kotlin 1.9.24 · AGP 8.5.2 · Gradle 8.7 · Jetpack Compose (Material 3) · ViewModel + StateFlow ·
PdfBox-Android 2.0.27.0 (التحرير) · PdfRenderer (العرض) · MediaStore (الحفظ في Download/PdfTools).

## الهيكل
```
app/src/main/java/com/example/pdftools/
├── PdfToolsApp.kt, MainActivity.kt
├── data/        PdfRepository (PdfBox) · PdfPageRenderer · FileRepository (MediaStore) · Recent/Settings
├── navigation/  Routes · AppNavHost
├── ui/components  مكوّنات مشتركة · لوحة التوقيع · صفحة قابلة للتكبير
├── ui/screens/  home · viewer · merge · split · pages · sign · convert · about (شاشة + ViewModel لكل منها)
└── util/        رسائل الأخطاء · نطاقات الصفحات · المشاركة
```
