package com.example.pdftools.ui.screens.split

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.OperationResult
import com.example.pdftools.data.SourcePdf
import com.example.pdftools.data.baseNameOf
import com.example.pdftools.data.container
import com.example.pdftools.navigation.Routes
import com.example.pdftools.util.AppException
import com.example.pdftools.util.PageRanges
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class SplitMode { SINGLE_FILE, FILE_PER_RANGE, FILE_PER_PAGE }

data class SplitUiState(
    val source: SourcePdf? = null,
    val loading: Boolean = false,
    val ranges: String = "",
    val mode: SplitMode = SplitMode.SINGLE_FILE,
    val rangeError: UiText? = null,
    val working: Boolean = false,
    val progress: Float = 0f,
    val result: OperationResult? = null,
    val message: UiText? = null,
)

class SplitViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(SplitUiState())
    val state: StateFlow<SplitUiState> = _state.asStateFlow()

    init {
        savedStateHandle.get<String>(Routes.ARG_URI)?.let { load(Uri.parse(it)) }
    }

    fun load(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, result = null) }
            ioCatching { container.openSource(uri) }
                .onSuccess { pdf ->
                    _state.update { it.copy(loading = false, source = pdf, ranges = "", rangeError = null) }
                }
                .onFailure { error ->
                    _state.update { it.copy(loading = false, message = error.toUiText()) }
                }
        }
    }

    fun setRanges(text: String) = _state.update { it.copy(ranges = text, rangeError = null) }

    fun setMode(mode: SplitMode) = _state.update { it.copy(mode = mode, rangeError = null) }

    fun startExtraction() {
        val snapshot = _state.value
        val source = snapshot.source ?: return
        if (snapshot.working) return

        val groups: List<List<Int>> = try {
            val text = snapshot.ranges.ifBlank {
                if (snapshot.mode == SplitMode.FILE_PER_PAGE) "1-${source.pageCount}" else ""
            }
            val parsed = PageRanges.parse(text, source.pageCount)
            when (snapshot.mode) {
                SplitMode.SINGLE_FILE -> listOf(parsed.flatten())
                SplitMode.FILE_PER_RANGE -> parsed
                SplitMode.FILE_PER_PAGE -> parsed.flatten().distinct().map { listOf(it) }
            }
        } catch (e: AppException) {
            _state.update { it.copy(rangeError = e.text) }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(working = true, progress = 0f, result = null) }
            ioCatching {
                val base = baseNameOf(source.name)
                val outputs = groups.map { group ->
                    container.files.newOutputFile("${base}_${label(group)}.pdf")
                }
                container.pdf.extract(source.file, groups, outputs) { p ->
                    _state.update { s -> s.copy(progress = p * 0.9f) }
                }
                container.files.publish(outputs, MIME_PDF)
            }.onSuccess { result ->
                _state.update { it.copy(working = false, result = result) }
            }.onFailure { error ->
                _state.update { it.copy(working = false, message = error.toUiText()) }
            }
        }
    }

    /** "p1-3_5" style label (1-based) used in output file names. */
    private fun label(group: List<Int>): String {
        val pages = group.map { it + 1 }
        if (pages.size == 1) return "p${pages[0]}"
        val parts = ArrayList<String>()
        var start = pages[0]
        var previous = pages[0]
        for (page in pages.drop(1) + Int.MIN_VALUE) {
            if (page == previous + 1) {
                previous = page
                continue
            }
            parts.add(if (start == previous) "$start" else "$start-$previous")
            start = page
            previous = page
        }
        val joined = "p" + parts.joinToString("_")
        return if (joined.length > 40) "p${pages.first()}-${pages.last()}_extract" else joined
    }

    fun clearResult() = _state.update { it.copy(result = null) }

    fun messageShown() = _state.update { it.copy(message = null) }
}
