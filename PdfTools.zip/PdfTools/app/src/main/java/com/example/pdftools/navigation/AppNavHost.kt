package com.example.pdftools.navigation

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.pdftools.ui.screens.about.AboutScreen
import com.example.pdftools.ui.screens.convert.ConvertScreen
import com.example.pdftools.ui.screens.home.HomeScreen
import com.example.pdftools.ui.screens.merge.MergeScreen
import com.example.pdftools.ui.screens.pages.PagesScreen
import com.example.pdftools.ui.screens.sign.SignScreen
import com.example.pdftools.ui.screens.split.SplitScreen
import com.example.pdftools.ui.screens.viewer.ViewerScreen

@Composable
fun AppNavHost(initialPdf: Uri?) {
    val navController = rememberNavController()
    var initialHandled by rememberSaveable { mutableStateOf(false) }

    val back: () -> Unit = {
        if (navController.previousBackStackEntry != null) navController.popBackStack()
    }
    val navigate: (String) -> Unit = { route ->
        navController.navigate(route) { launchSingleTop = true }
    }
    val openPdf: (Uri) -> Unit = { uri -> navigate(Routes.viewer(uri.toString())) }

    // A PDF opened from another app ("Open with PDF Tools")
    LaunchedEffect(initialPdf) {
        if (initialPdf != null && !initialHandled) {
            initialHandled = true
            openPdf(initialPdf)
        }
    }

    val uriArgument = navArgument(Routes.ARG_URI) {
        type = NavType.StringType
        nullable = true
        defaultValue = null
    }

    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(onOpenPdf = openPdf, onNavigate = navigate)
        }
        composable(Routes.VIEWER, arguments = listOf(uriArgument)) {
            ViewerScreen(onBack = back, onNavigate = navigate)
        }
        composable(Routes.MERGE) {
            MergeScreen(onBack = back, onOpenPdf = openPdf)
        }
        composable(Routes.SPLIT, arguments = listOf(uriArgument)) {
            SplitScreen(onBack = back, onOpenPdf = openPdf)
        }
        composable(Routes.PAGES, arguments = listOf(uriArgument)) {
            PagesScreen(onBack = back, onOpenPdf = openPdf)
        }
        composable(Routes.SIGN, arguments = listOf(uriArgument)) {
            SignScreen(onBack = back, onOpenPdf = openPdf)
        }
        composable(
            Routes.CONVERT,
            arguments = listOf(
                navArgument(Routes.ARG_TAB) {
                    type = NavType.IntType
                    defaultValue = 0
                },
                uriArgument,
            ),
        ) {
            ConvertScreen(onBack = back, onOpenPdf = openPdf)
        }
        composable(Routes.ABOUT) {
            AboutScreen(onBack = back)
        }
    }
}
