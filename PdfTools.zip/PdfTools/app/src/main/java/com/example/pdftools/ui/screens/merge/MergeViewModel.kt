package com.example.pdftools.ui.screens.merge

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.pdftools.R
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.OperationResult
import com.example.pdftools.data.SourcePdf
import com.example.pdftools.data.container
import com.example.pdftools.data.timestamp
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import com.example.pdftools.util.uiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MergeItem(val id: Long, val source: SourcePdf)

data class MergeUiState(
    val items: List<MergeItem> = emptyList(),
    val adding: Boolean = false,
    val working: Boolean = false,
    val progress: Float = 0f,
    val result: OperationResult? = null,
    val message: UiText? = null,
) {
    val totalPages: Int get() = items.sumOf { it.source.pageCount }
    val canMerge: Boolean get() = items.size >= 2 && !working && !adding
}

class MergeViewModel(application: Application) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(MergeUiState())
    val state: StateFlow<MergeUiState> = _state.asStateFlow()

    private var nextId = 0L

    fun addFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(adding = true, result = null) }
            val added = ArrayList<MergeItem>()
            var firstError: UiText? = null
            for (uri in uris) {
                ioCatching { container.openSource(uri, rememberInRecents = false) }
                    .onSuccess { added.add(MergeItem(nextId++, it)) }
                    .onFailure { error ->
                        if (firstError == null) {
                            val name = ioCatching { container.files.queryInfo(uri).name }.getOrNull() ?: "?"
                            firstError = uiText(R.string.error_file_skipped, name, error.toUiText())
                        }
                    }
            }
            _state.update {
                it.copy(adding = false, items = it.items + added, message = firstError ?: it.message)
            }
        }
    }

    fun move(index: Int, delta: Int) {
        _state.update { s ->
            val target = index + delta
            if (index !in s.items.indices || target !in s.items.indices) return@update s
            val list = s.items.toMutableList()
            val item = list.removeAt(index)
            list.add(target, item)
            s.copy(items = list, result = null)
        }
    }

    fun remove(id: Long) {
        _state.update { s -> s.copy(items = s.items.filterNot { it.id == id }, result = null) }
    }

    fun merge() {
        val snapshot = _state.value
        if (!snapshot.canMerge) return
        viewModelScope.launch {
            _state.update { it.copy(working = true, progress = 0f, result = null) }
            ioCatching {
                val output = container.files.newOutputFile("merged_${timestamp()}.pdf")
                container.pdf.merge(
                    inputs = snapshot.items.map { it.source.file to it.source.name },
                    output = output,
                    onProgress = { p -> _state.update { s -> s.copy(progress = p) } },
                )
                container.files.publish(listOf(output), MIME_PDF)
            }.onSuccess { result ->
                _state.update { it.copy(working = false, result = result) }
            }.onFailure { error ->
                _state.update { it.copy(working = false, message = error.toUiText()) }
            }
        }
    }

    fun clearResult() = _state.update { it.copy(result = null) }

    fun messageShown() = _state.update { it.copy(message = null) }
}
