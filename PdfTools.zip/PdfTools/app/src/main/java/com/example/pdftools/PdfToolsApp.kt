package com.example.pdftools

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate
import com.example.pdftools.data.AppContainer
import com.example.pdftools.data.toNightMode
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class PdfToolsApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        // Required once before any PdfBox call (fonts, glyph lists...).
        PDFBoxResourceLoader.init(applicationContext)
        container = AppContainer(this)
        AppCompatDelegate.setDefaultNightMode(container.settings.themeMode.value.toNightMode())
        Thread { container.files.cleanOldCache() }.start()
    }
}
