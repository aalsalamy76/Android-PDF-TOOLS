package com.example.pdftools.data

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.example.pdftools.R
import com.example.pdftools.util.AppException
import com.example.pdftools.util.uiText
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import kotlin.math.roundToInt

/**
 * Text recognition (OCR) for scanned documents with Google ML Kit.
 * The Latin model is bundled inside the app: it works offline
 * (French, English, Spanish… — Arabic script is not supported by this model).
 * Blocking: call from Dispatchers.IO.
 */
class OcrRepository {

    fun recognize(input: File, onProgress: (Float) -> Unit): String {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            val builder = StringBuilder()
            ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                PdfRenderer(descriptor).use { renderer ->
                    val total = renderer.pageCount
                    for (index in 0 until total) {
                        val bitmap = renderer.openPage(index).use { page ->
                            val width = TARGET_WIDTH
                            val height = (width.toFloat() * page.height / page.width).roundToInt()
                                .coerceIn(1, width * 4)
                            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                            bmp
                        }
                        val text = try {
                            Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0))).text
                        } finally {
                            bitmap.recycle()
                        }
                        if (total > 1) builder.append("— ").append(index + 1).append(" —\n")
                        builder.append(text.trim()).append("\n\n")
                        onProgress((index + 1f) / total)
                    }
                }
            }
            val result = builder.toString().trim()
            if (result.replace(Regex("[—\\d\\s]"), "").isEmpty()) {
                throw AppException(uiText(R.string.error_ocr_nothing))
            }
            return result
        } finally {
            recognizer.close()
        }
    }

    private companion object {
        const val TARGET_WIDTH = 1700
    }
}
