package com.example.pdftools.data

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import kotlin.math.roundToInt

/**
 * Thread-safe wrapper around Android's [PdfRenderer] with a bitmap cache.
 * PdfRenderer can only have one page open at a time, so rendering is serialized by a [Mutex].
 */
class PdfPageRenderer private constructor(
    private val descriptor: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
) : Closeable {

    val pageCount: Int = renderer.pageCount

    /** Page sizes in PDF points, as displayed (page rotation already applied). */
    val pageSizes: List<Size> = List(pageCount) { index ->
        renderer.openPage(index).use { page -> Size(page.width, page.height) }
    }

    private val mutex = Mutex()

    @Volatile
    private var closeRequested = false
    private var released = false

    private val cache = object : LruCache<String, Bitmap>(cacheSizeKb()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    /** Renders [index] to a bitmap [targetWidth] pixels wide, on a white background. */
    suspend fun render(index: Int, targetWidth: Int): Bitmap = withContext(Dispatchers.IO) {
        val key = "$index@$targetWidth"
        cache.get(key) ?: mutex.withLock {
            cache.get(key) ?: renderLocked(index, targetWidth, key)
        }
    }

    /** Must be called while holding [mutex]. */
    private fun renderLocked(index: Int, targetWidth: Int, key: String): Bitmap {
        check(!released) { "Renderer closed" }
        try {
            return renderer.openPage(index).use { page ->
                val width = targetWidth.coerceAtLeast(1)
                val height = (width.toFloat() * page.height / page.width).roundToInt().coerceAtLeast(1)
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                cache.put(key, bitmap)
                bitmap
            }
        } finally {
            if (closeRequested) release()
        }
    }

    /** Same as [render] but returns null instead of throwing. */
    suspend fun renderOrNull(index: Int, targetWidth: Int): Bitmap? = try {
        render(index, targetWidth)
    } catch (e: CancellationException) {
        throw e
    } catch (t: Throwable) {
        null
    }

    override fun close() {
        if (closeRequested) return
        closeRequested = true
        if (mutex.tryLock()) {
            try {
                release()
            } finally {
                mutex.unlock()
            }
        }
        // Otherwise the render in progress releases the renderer when it finishes.
    }

    private fun release() {
        if (released) return
        released = true
        try {
            renderer.close()
        } catch (_: Exception) {
        }
        try {
            descriptor.close()
        } catch (_: Exception) {
        }
        cache.evictAll()
    }

    companion object {
        /** Throws IOException (corrupt file) or SecurityException (password protected). */
        fun open(file: File): PdfPageRenderer {
            val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = try {
                PdfRenderer(descriptor)
            } catch (t: Throwable) {
                descriptor.close()
                throw t
            }
            return try {
                PdfPageRenderer(descriptor, renderer)
            } catch (t: Throwable) {
                renderer.close()
                descriptor.close()
                throw t
            }
        }

        private fun cacheSizeKb(): Int = (Runtime.getRuntime().maxMemory() / 1024L / 6L).toInt()
    }
}
