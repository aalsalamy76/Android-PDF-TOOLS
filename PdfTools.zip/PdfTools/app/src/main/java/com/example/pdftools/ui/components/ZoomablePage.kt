package com.example.pdftools.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

private const val MAX_ZOOM = 5f
private const val DOUBLE_TAP_ZOOM = 2.5f

private sealed interface PageLoad {
    data object Loading : PageLoad
    data object Failed : PageLoad
    data class Ready(val bitmap: Bitmap) : PageLoad
}

/**
 * One PDF page with pinch-to-zoom, pan and double-tap zoom.
 * While the page is not zoomed, one-finger swipes are left to the parent pager.
 */
@Composable
fun ZoomablePdfPage(
    pageIndex: Int,
    loader: suspend (Int, Int) -> Bitmap?,
    modifier: Modifier = Modifier,
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize().clipToBounds()) {
        val density = LocalDensity.current
        val targetWidth = with(density) { (maxWidth.toPx() * 1.6f).roundToInt() }.coerceIn(400, 2200)

        val load by produceState<PageLoad>(PageLoad.Loading, pageIndex, targetWidth) {
            val bitmap = loader(pageIndex, targetWidth)
            value = if (bitmap != null) PageLoad.Ready(bitmap) else PageLoad.Failed
        }

        var scale by remember(pageIndex) { mutableFloatStateOf(1f) }
        var offset by remember(pageIndex) { mutableStateOf(Offset.Zero) }

        when (val state = load) {
            PageLoad.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))

            PageLoad.Failed -> Icon(
                Icons.Filled.BrokenImage,
                contentDescription = null,
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(48.dp),
            )

            is PageLoad.Ready -> {
                val image = remember(state.bitmap) { state.bitmap.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                        .pointerInput(pageIndex) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                do {
                                    val event = awaitPointerEvent()
                                    val fingers = event.changes.count { it.pressed }
                                    if (fingers >= 2 || scale > 1f) {
                                        val newScale = (scale * event.calculateZoom()).coerceIn(1f, MAX_ZOOM)
                                        val pan = event.calculatePan()
                                        val maxX = size.width * (newScale - 1f) / 2f
                                        val maxY = size.height * (newScale - 1f) / 2f
                                        offset = if (newScale <= 1f) {
                                            Offset.Zero
                                        } else {
                                            Offset(
                                                (offset.x + pan.x).coerceIn(-maxX, maxX),
                                                (offset.y + pan.y).coerceIn(-maxY, maxY),
                                            )
                                        }
                                        scale = newScale
                                        event.changes.forEach { if (it.positionChanged()) it.consume() }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                        .pointerInput(pageIndex) {
                            detectTapGestures(onDoubleTap = {
                                if (scale > 1f) {
                                    scale = 1f
                                    offset = Offset.Zero
                                } else {
                                    scale = DOUBLE_TAP_ZOOM
                                }
                            })
                        }
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        },
                )
            }
        }
    }
}
