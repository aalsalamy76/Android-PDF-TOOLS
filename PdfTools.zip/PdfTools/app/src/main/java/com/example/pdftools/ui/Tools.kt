package com.example.pdftools.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BorderColor
import androidx.compose.material.icons.filled.BrandingWatermark
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.pdftools.R
import com.example.pdftools.navigation.Routes
import com.example.pdftools.ui.theme.Accent
import com.example.pdftools.ui.theme.AccentAmberDark
import com.example.pdftools.ui.theme.AccentAmberLight
import com.example.pdftools.ui.theme.AccentIndigoDark
import com.example.pdftools.ui.theme.AccentIndigoLight
import com.example.pdftools.ui.theme.AccentRedDark
import com.example.pdftools.ui.theme.AccentRedLight
import com.example.pdftools.ui.theme.AccentTealDark
import com.example.pdftools.ui.theme.AccentTealLight

enum class ToolCategory(@StringRes val title: Int) {
    EDIT(R.string.category_edit),
    ORGANIZE(R.string.category_organize),
    CONVERT(R.string.category_convert),
    SECURITY(R.string.category_security),
}

/** Every tool of the app, in display order. Used by the home grid and the bottom sheets. */
enum class Tool(
    val icon: ImageVector,
    @StringRes val title: Int,
    @StringRes val description: Int,
    val category: ToolCategory,
    /** True when the tool works on one existing PDF (can be offered for a chosen file). */
    val worksOnPdf: Boolean,
) {
    ANNOTATE(Icons.Filled.BorderColor, R.string.tool_annotate, R.string.tool_annotate_desc, ToolCategory.EDIT, true),
    SIGN(Icons.Filled.Draw, R.string.tool_sign, R.string.tool_sign_desc, ToolCategory.EDIT, true),
    FORMS(Icons.Filled.CheckBox, R.string.tool_forms, R.string.tool_forms_desc, ToolCategory.EDIT, true),
    WATERMARK(
        Icons.Filled.BrandingWatermark, R.string.tool_watermark, R.string.tool_watermark_desc,
        ToolCategory.EDIT, true
    ),
    PAGE_NUMBERS(
        Icons.Filled.FormatListNumbered, R.string.tool_numbers, R.string.tool_numbers_desc,
        ToolCategory.EDIT, true
    ),

    MERGE(Icons.Filled.MergeType, R.string.tool_merge, R.string.tool_merge_desc, ToolCategory.ORGANIZE, false),
    SPLIT(Icons.Filled.ContentCut, R.string.tool_split, R.string.tool_split_desc, ToolCategory.ORGANIZE, true),
    PAGES(Icons.Filled.GridView, R.string.tool_pages, R.string.tool_pages_desc, ToolCategory.ORGANIZE, true),

    SCAN(Icons.Filled.PhotoCamera, R.string.tool_scan, R.string.tool_scan_desc, ToolCategory.CONVERT, false),
    OCR(Icons.Filled.CenterFocusStrong, R.string.tool_ocr, R.string.tool_ocr_desc, ToolCategory.CONVERT, true),
    IMAGES_TO_PDF(
        Icons.Filled.Collections, R.string.tool_images_to_pdf, R.string.tool_images_to_pdf_desc,
        ToolCategory.CONVERT, false
    ),
    PDF_TO_IMAGES(
        Icons.Filled.PhotoLibrary, R.string.tool_pdf_to_images, R.string.tool_pdf_to_images_desc,
        ToolCategory.CONVERT, true
    ),
    PDF_TO_TEXT(
        Icons.Filled.TextFields, R.string.tool_pdf_to_text, R.string.tool_pdf_to_text_desc,
        ToolCategory.CONVERT, true
    ),

    COMPRESS(Icons.Filled.Compress, R.string.tool_compress, R.string.tool_compress_desc, ToolCategory.SECURITY, true),
    PROTECT(Icons.Filled.Lock, R.string.tool_protect, R.string.tool_protect_desc, ToolCategory.SECURITY, true),
    UNLOCK(Icons.Filled.LockOpen, R.string.tool_unlock, R.string.tool_unlock_desc, ToolCategory.SECURITY, true);

    /** Navigation route of this tool, optionally pre-loaded with a document. */
    fun route(uri: String? = null): String = when (this) {
        MERGE -> Routes.MERGE
        SPLIT -> Routes.split(uri)
        PAGES -> Routes.pages(uri)
        SIGN -> Routes.sign(uri)
        ANNOTATE -> Routes.annotate(uri)
        FORMS -> Routes.forms(uri)
        SCAN -> Routes.convert(Routes.TAB_IMAGES_TO_PDF, camera = true)
        OCR -> Routes.convert(Routes.TAB_PDF_TO_TEXT, uri, ocr = true)
        IMAGES_TO_PDF -> Routes.convert(Routes.TAB_IMAGES_TO_PDF)
        PDF_TO_IMAGES -> Routes.convert(Routes.TAB_PDF_TO_IMAGES, uri)
        PDF_TO_TEXT -> Routes.convert(Routes.TAB_PDF_TO_TEXT, uri)
        WATERMARK, PAGE_NUMBERS, COMPRESS, PROTECT, UNLOCK -> Routes.tool(name, uri)
    }

    companion object {
        /** Tools that can be applied to one PDF, e.g. from the "what next?" sheets. */
        val forPdf: List<Tool> = values().filter { it.worksOnPdf }
    }
}

@Composable
fun ToolCategory.accent(): Accent {
    val dark = isSystemInDarkTheme()
    return when (this) {
        ToolCategory.ORGANIZE -> if (dark) AccentRedDark else AccentRedLight
        ToolCategory.EDIT -> if (dark) AccentIndigoDark else AccentIndigoLight
        ToolCategory.CONVERT -> if (dark) AccentTealDark else AccentTealLight
        ToolCategory.SECURITY -> if (dark) AccentAmberDark else AccentAmberLight
    }
}
