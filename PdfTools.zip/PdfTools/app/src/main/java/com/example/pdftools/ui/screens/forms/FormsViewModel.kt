package com.example.pdftools.ui.screens.forms

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.pdftools.data.FormField
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.OperationResult
import com.example.pdftools.data.SourcePdf
import com.example.pdftools.data.baseNameOf
import com.example.pdftools.data.container
import com.example.pdftools.navigation.Routes
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FormsUiState(
    val source: SourcePdf? = null,
    val loading: Boolean = false,
    val fields: List<FormField> = emptyList(),
    /** Values typed by the user, by field key. */
    val values: Map<String, String> = emptyMap(),
    val flatten: Boolean = false,
    val working: Boolean = false,
    val result: OperationResult? = null,
    val message: UiText? = null,
) {
    val hasChanges: Boolean get() = fields.any { field -> values[field.key]?.let { it != field.value } == true }
}

class FormsViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(FormsUiState())
    val state: StateFlow<FormsUiState> = _state.asStateFlow()

    init {
        savedStateHandle.get<String>(Routes.ARG_URI)?.let { load(Uri.parse(it)) }
    }

    fun load(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, result = null) }
            ioCatching {
                val pdf = container.openSource(uri)
                pdf to container.pdf.readForm(pdf.file)
            }.onSuccess { (pdf, fields) ->
                _state.update {
                    it.copy(
                        loading = false,
                        source = pdf,
                        fields = fields,
                        values = fields.associate { field -> field.key to field.value },
                    )
                }
            }.onFailure { error ->
                _state.update { it.copy(loading = false, message = error.toUiText()) }
            }
        }
    }

    fun setValue(key: String, value: String) = _state.update { it.copy(values = it.values + (key to value), result = null) }

    fun setFlatten(value: Boolean) = _state.update { it.copy(flatten = value) }

    fun save() {
        val s = _state.value
        val source = s.source ?: return
        if (s.working || s.fields.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(working = true, result = null) }
            ioCatching {
                val output = container.files.newOutputFile("${baseNameOf(source.name)}_filled.pdf")
                val changed = s.values.filter { (key, value) -> s.fields.firstOrNull { it.key == key }?.value != value }
                container.pdf.fillForm(source.file, output, changed, s.flatten)
                container.files.publish(listOf(output), MIME_PDF)
            }.onSuccess { result ->
                _state.update { it.copy(working = false, result = result) }
            }.onFailure { error ->
                _state.update { it.copy(working = false, message = error.toUiText()) }
            }
        }
    }

    fun clearResult() = _state.update { it.copy(result = null) }

    fun messageShown() = _state.update { it.copy(message = null) }
}
