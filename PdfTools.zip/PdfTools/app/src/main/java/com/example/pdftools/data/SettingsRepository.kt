package com.example.pdftools.data

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeMode { SYSTEM, LIGHT, DARK }

fun ThemeMode.toNightMode(): Int = when (this) {
    ThemeMode.SYSTEM -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    ThemeMode.LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
    ThemeMode.DARK -> AppCompatDelegate.MODE_NIGHT_YES
}

/** Stores the light / dark preference. The UI follows it through AppCompat night mode. */
class SettingsRepository(context: Context) {

    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(readTheme())
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private fun readTheme(): ThemeMode {
        val stored = prefs.getString(KEY_THEME, null) ?: return ThemeMode.SYSTEM
        return ThemeMode.values().firstOrNull { it.name == stored } ?: ThemeMode.SYSTEM
    }

    fun setThemeMode(mode: ThemeMode) {
        prefs.edit().putString(KEY_THEME, mode.name).apply()
        _themeMode.value = mode
        AppCompatDelegate.setDefaultNightMode(mode.toNightMode())
    }

    private companion object {
        const val KEY_THEME = "theme_mode"
    }
}

/** In-app language switch (Arabic, English, French, Spanish) based on per-app locales. */
object LanguageManager {

    /** [tag] empty = follow the system language. [nativeName] null = "system" label. */
    data class Language(val tag: String, val nativeName: String?)

    val languages: List<Language> = listOf(
        Language("", null),
        Language("ar", "العربية"),
        Language("en", "English"),
        Language("fr", "Français"),
        Language("es", "Español"),
    )

    fun currentTag(): String {
        val locales = AppCompatDelegate.getApplicationLocales()
        if (locales.isEmpty()) return ""
        return locales.get(0)?.language ?: ""
    }

    fun setLanguage(tag: String) {
        val locales = if (tag.isEmpty()) {
            LocaleListCompat.getEmptyLocaleList()
        } else {
            LocaleListCompat.forLanguageTags(tag)
        }
        AppCompatDelegate.setApplicationLocales(locales)
    }
}
