package com.example.pdftools.ui.screens.sign

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Size
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.pdftools.R
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.OperationResult
import com.example.pdftools.data.PdfPageRenderer
import com.example.pdftools.data.PdfRepository
import com.example.pdftools.data.SourcePdf
import com.example.pdftools.data.baseNameOf
import com.example.pdftools.data.container
import com.example.pdftools.navigation.Routes
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import com.example.pdftools.util.uiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

/** Signature position on a page, as fractions of the displayed page (0..1). */
data class SignPlacement(val centerX: Float, val centerY: Float, val widthFraction: Float)

data class SignUiState(
    val source: SourcePdf? = null,
    val loading: Boolean = false,
    val pageSizes: List<Size> = emptyList(),
    val currentPage: Int = 0,
    val placements: Map<Int, SignPlacement> = emptyMap(),
    val widthFraction: Float = 0.3f,
    val signature: Bitmap? = null,
    val showPad: Boolean = false,
    val working: Boolean = false,
    val result: OperationResult? = null,
    val message: UiText? = null,
) {
    val currentPlacement: SignPlacement? get() = placements[currentPage]
}

class SignViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(SignUiState())
    val state: StateFlow<SignUiState> = _state.asStateFlow()

    private var renderer: PdfPageRenderer? = null
    private val signatureFile = File(application.filesDir, "signature.png")

    init {
        loadSavedSignature()
        savedStateHandle.get<String>(Routes.ARG_URI)?.let { load(Uri.parse(it)) }
    }

    private fun loadSavedSignature() {
        viewModelScope.launch {
            ioCatching {
                if (signatureFile.exists()) BitmapFactory.decodeFile(signatureFile.absolutePath) else null
            }.onSuccess { bitmap ->
                if (bitmap != null) _state.update { it.copy(signature = bitmap) }
            }
        }
    }

    fun load(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, result = null) }
            ioCatching {
                val pdf = container.openSource(uri)
                pdf to PdfPageRenderer.open(pdf.file)
            }.onSuccess { (pdf, newRenderer) ->
                renderer?.close()
                renderer = newRenderer
                _state.update {
                    it.copy(
                        loading = false,
                        source = pdf,
                        pageSizes = newRenderer.pageSizes,
                        currentPage = 0,
                        placements = emptyMap(),
                        showPad = it.signature == null,
                    )
                }
            }.onFailure { error ->
                _state.update { it.copy(loading = false, message = error.toUiText()) }
            }
        }
    }

    suspend fun renderPage(index: Int, widthPx: Int): Bitmap? = renderer?.renderOrNull(index, widthPx)

    fun goToPage(index: Int) {
        _state.update { s ->
            if (index !in s.pageSizes.indices) s else s.copy(currentPage = index)
        }
    }

    fun showPad(show: Boolean) = _state.update { it.copy(showPad = show) }

    fun setSignature(bitmap: Bitmap) {
        _state.update { it.copy(signature = bitmap, showPad = false, result = null) }
        viewModelScope.launch {
            ioCatching {
                signatureFile.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
        }
    }

    /** Places (or moves) the signature on the current page, centered on the touched point. */
    fun place(fx: Float, fy: Float) {
        _state.update { s ->
            if (s.signature == null) return@update s.copy(showPad = true)
            val width = s.currentPlacement?.widthFraction ?: s.widthFraction
            s.copy(
                placements = s.placements + (s.currentPage to clamp(s, SignPlacement(fx, fy, width))),
                result = null,
            )
        }
    }

    fun moveBy(dx: Float, dy: Float) {
        _state.update { s ->
            val current = s.currentPlacement ?: return@update s
            val moved = current.copy(centerX = current.centerX + dx, centerY = current.centerY + dy)
            s.copy(placements = s.placements + (s.currentPage to clamp(s, moved)))
        }
    }

    fun setWidth(fraction: Float) {
        _state.update { s ->
            val current = s.currentPlacement
            if (current == null) {
                s.copy(widthFraction = fraction)
            } else {
                s.copy(
                    widthFraction = fraction,
                    placements = s.placements + (s.currentPage to clamp(s, current.copy(widthFraction = fraction))),
                )
            }
        }
    }

    fun removeCurrentPlacement() {
        _state.update { s -> s.copy(placements = s.placements - s.currentPage) }
    }

    /** Keeps the whole signature inside the page. */
    private fun clamp(s: SignUiState, placement: SignPlacement): SignPlacement {
        val signature = s.signature ?: return placement
        val page = s.pageSizes.getOrNull(s.currentPage) ?: return placement
        val pageAspect = page.width.toFloat() / page.height.toFloat()
        val signatureAspect = signature.height.toFloat() / signature.width.toFloat()
        val halfW = (placement.widthFraction / 2f).coerceAtMost(0.5f)
        val halfH = (placement.widthFraction * signatureAspect * pageAspect / 2f).coerceAtMost(0.5f)
        return placement.copy(
            centerX = placement.centerX.coerceIn(halfW, 1f - halfW),
            centerY = placement.centerY.coerceIn(halfH, 1f - halfH),
        )
    }

    fun save() {
        val snapshot = _state.value
        val source = snapshot.source ?: return
        val signature = snapshot.signature ?: return
        if (snapshot.working) return
        if (snapshot.placements.isEmpty()) {
            _state.update { it.copy(message = uiText(R.string.sign_no_placement)) }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(working = true, result = null) }
            ioCatching {
                val output = container.files.newOutputFile("${baseNameOf(source.name)}_signed.pdf")
                container.pdf.addSignature(
                    input = source.file,
                    output = output,
                    signature = signature,
                    placements = snapshot.placements.map { (page, p) ->
                        PdfRepository.Placement(page, p.centerX, p.centerY, p.widthFraction)
                    },
                )
                container.files.publish(listOf(output), MIME_PDF)
            }.onSuccess { result ->
                _state.update { it.copy(working = false, result = result) }
            }.onFailure { error ->
                _state.update { it.copy(working = false, message = error.toUiText()) }
            }
        }
    }

    fun clearResult() = _state.update { it.copy(result = null) }

    fun messageShown() = _state.update { it.copy(message = null) }

    override fun onCleared() {
        renderer?.close()
        renderer = null
    }
}
