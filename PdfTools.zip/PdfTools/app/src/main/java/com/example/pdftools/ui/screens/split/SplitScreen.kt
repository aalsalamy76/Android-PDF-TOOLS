@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.pdftools.ui.screens.split

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.ui.Tool
import com.example.pdftools.ui.components.BottomActionBar
import com.example.pdftools.ui.components.MessageEffect
import com.example.pdftools.ui.components.PickFileCard
import com.example.pdftools.ui.components.ResultSheet
import com.example.pdftools.ui.components.SourceFileCard
import com.example.pdftools.ui.components.ToolScaffold
import com.example.pdftools.ui.components.WorkingCard
import com.example.pdftools.util.asString

@Composable
fun SplitScreen(
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: SplitViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    MessageEffect(state.message, snackbarHostState, viewModel::messageShown)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.load(uri)
    }
    val pick: () -> Unit = { picker.launch(arrayOf("application/pdf")) }
    val source = state.source

    ToolScaffold(
        title = stringResource(R.string.tool_split),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
        bottomBar = {
            if (source != null) {
                BottomActionBar {
                    Button(
                        onClick = viewModel::startExtraction,
                        enabled = !state.working,
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.ContentCut, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.action_extract))
                    }
                }
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (state.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

            if (source == null) {
                if (!state.loading) {
                    PickFileCard(
                        icon = Icons.Filled.ContentCut,
                        title = stringResource(R.string.split_empty_title),
                        description = stringResource(R.string.split_empty_desc),
                        buttonText = stringResource(R.string.action_choose_pdf),
                        onPick = pick,
                    )
                }
            } else {
                SourceFileCard(source = source, onChange = if (state.working) null else pick)

                OutlinedTextField(
                    value = state.ranges,
                    onValueChange = viewModel::setRanges,
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text(stringResource(R.string.split_ranges_label)) },
                    placeholder = { Text(stringResource(R.string.split_ranges_placeholder)) },
                    supportingText = {
                        val error = state.rangeError
                        if (error != null) {
                            Text(error.asString())
                        } else {
                            Text(stringResource(R.string.split_ranges_help, source.pageCount))
                        }
                    },
                    isError = state.rangeError != null,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done,
                    ),
                )

                Text(stringResource(R.string.split_mode_title), style = MaterialTheme.typography.titleSmall)
                OutlinedCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.selectableGroup().padding(vertical = 4.dp)) {
                        ModeRow(SplitMode.SINGLE_FILE, R.string.split_mode_single, R.string.split_mode_single_desc, state.mode, viewModel::setMode)
                        ModeRow(SplitMode.FILE_PER_RANGE, R.string.split_mode_per_range, R.string.split_mode_per_range_desc, state.mode, viewModel::setMode)
                        ModeRow(SplitMode.FILE_PER_PAGE, R.string.split_mode_per_page, R.string.split_mode_per_page_desc, state.mode, viewModel::setMode)
                    }
                }
            }

            if (state.working) WorkingCard(progress = state.progress)

        }
    }
    state.result?.let { result ->
        ResultSheet(
            result = result,
            onDismiss = viewModel::clearResult,
            onOpenPdf = { onOpenPdf(it.uri) },
            onContinue = { tool, file -> onNavigate(tool.route(file.uri.toString())) },
            exclude = Tool.SPLIT,
        )
    }
}

@Composable
private fun ModeRow(
    mode: SplitMode,
    @StringRes title: Int,
    @StringRes description: Int,
    selected: SplitMode,
    onSelect: (SplitMode) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .selectable(selected = mode == selected, role = Role.RadioButton, onClick = { onSelect(mode) })
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = mode == selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(stringResource(title), style = MaterialTheme.typography.bodyLarge)
            Text(
                stringResource(description),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
