package com.example.pdftools.ui.screens.annotate

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.util.Size
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.pdftools.R
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.Mark
import com.example.pdftools.data.MarkPoint
import com.example.pdftools.data.MarkType
import com.example.pdftools.data.OperationResult
import com.example.pdftools.data.PdfPageRenderer
import com.example.pdftools.data.SourcePdf
import com.example.pdftools.data.baseNameOf
import com.example.pdftools.data.container
import com.example.pdftools.navigation.Routes
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import com.example.pdftools.util.uiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Colors of the annotate palette (the highlighter uses them with transparency). */
val InkPalette: List<Int> = listOf(
    0xFF111111.toInt(), // black
    0xFFD32F2F.toInt(), // red
    0xFF1565C0.toInt(), // blue
    0xFF2E7D32.toInt(), // green
    0xFFFFEB3B.toInt(), // yellow
    0xFFFF9800.toInt(), // orange
)

data class AnnotateUiState(
    val source: SourcePdf? = null,
    val loading: Boolean = false,
    val pageSizes: List<Size> = emptyList(),
    val currentPage: Int = 0,
    val tool: MarkType = MarkType.PEN,
    val color: Int = InkPalette[2],
    /** Multiplier applied to the default size of the tool (0.5x .. 3x). */
    val sizeFactor: Float = 1f,
    val marks: List<Mark> = emptyList(),
    /** Rendered text stamps for preview, by mark id. */
    val textBitmaps: Map<Long, Bitmap> = emptyMap(),
    /** Where the user tapped with the text tool: waiting for the text. */
    val pendingTextAt: MarkPoint? = null,
    val working: Boolean = false,
    val progress: Float = 0f,
    val result: OperationResult? = null,
    val message: UiText? = null,
) {
    val pageMarks: List<Mark> get() = marks.filter { it.page == currentPage }
}

class AnnotateViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(AnnotateUiState())
    val state: StateFlow<AnnotateUiState> = _state.asStateFlow()

    private var renderer: PdfPageRenderer? = null
    private var nextId = 1L

    init {
        savedStateHandle.get<String>(Routes.ARG_URI)?.let { load(Uri.parse(it)) }
    }

    fun load(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, result = null) }
            ioCatching {
                val pdf = container.openSource(uri)
                pdf to PdfPageRenderer.open(pdf.file)
            }.onSuccess { (pdf, newRenderer) ->
                renderer?.close()
                renderer = newRenderer
                _state.update {
                    it.copy(
                        loading = false,
                        source = pdf,
                        pageSizes = newRenderer.pageSizes,
                        currentPage = 0,
                        marks = emptyList(),
                        textBitmaps = emptyMap(),
                    )
                }
            }.onFailure { error ->
                _state.update { it.copy(loading = false, message = error.toUiText()) }
            }
        }
    }

    suspend fun renderPage(index: Int, widthPx: Int): Bitmap? = renderer?.renderOrNull(index, widthPx)

    fun goToPage(index: Int) = _state.update { s ->
        if (index in s.pageSizes.indices) s.copy(currentPage = index, pendingTextAt = null) else s
    }

    fun selectTool(tool: MarkType) = _state.update { s ->
        // The highlighter starts in yellow, the other tools keep the chosen color.
        val color = if (tool == MarkType.HIGHLIGHT && s.tool != MarkType.HIGHLIGHT) InkPalette[4] else s.color
        s.copy(tool = tool, color = color, pendingTextAt = null)
    }

    fun selectColor(color: Int) = _state.update { it.copy(color = color) }

    fun setSizeFactor(value: Float) = _state.update { it.copy(sizeFactor = value) }

    /** Called when a finger stroke ends (pen, highlighter, rectangle). Points are page fractions. */
    fun addStroke(points: List<MarkPoint>) {
        if (points.isEmpty()) return
        _state.update { s ->
            val markPoints = if (s.tool == MarkType.RECT) {
                if (points.size < 2) return@update s
                listOf(points.first(), points.last())
            } else {
                points
            }
            val mark = Mark(nextId++, s.currentPage, s.tool, markPoints, s.color, baseSize(s.tool) * s.sizeFactor)
            s.copy(marks = s.marks + mark, result = null)
        }
    }

    fun requestText(at: MarkPoint) = _state.update { it.copy(pendingTextAt = at) }

    fun cancelText() = _state.update { it.copy(pendingTextAt = null) }

    fun addText(text: String) {
        val s = _state.value
        val at = s.pendingTextAt ?: return
        val clean = text.trim()
        if (clean.isEmpty()) {
            cancelText()
            return
        }
        val mark = Mark(nextId++, s.currentPage, MarkType.TEXT, listOf(at), s.color, baseSize(MarkType.TEXT) * s.sizeFactor, clean)
        _state.update { it.copy(pendingTextAt = null, marks = it.marks + mark, result = null) }
        viewModelScope.launch {
            ioCatching { container.pdf.renderTextStamp(clean, mark.color, 1f) }
                .onSuccess { bitmap -> _state.update { it.copy(textBitmaps = it.textBitmaps + (mark.id to bitmap)) } }
        }
    }

    fun undo() = _state.update { s ->
        val last = s.marks.lastOrNull { it.page == s.currentPage } ?: s.marks.lastOrNull() ?: return@update s
        s.copy(marks = s.marks - last, textBitmaps = s.textBitmaps - last.id, currentPage = last.page)
    }

    fun clearPage() = _state.update { s ->
        val removed = s.pageMarks.map { it.id }.toSet()
        s.copy(marks = s.marks.filterNot { it.id in removed }, textBitmaps = s.textBitmaps - removed)
    }

    fun save() {
        val s = _state.value
        val source = s.source ?: return
        if (s.working) return
        if (s.marks.isEmpty()) {
            _state.update { it.copy(message = uiText(R.string.annotate_nothing)) }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(working = true, progress = 0f, result = null) }
            ioCatching {
                val output = container.files.newOutputFile("${baseNameOf(source.name)}_annotated.pdf")
                container.pdf.applyMarks(source.file, output, s.marks) { p ->
                    _state.update { st -> st.copy(progress = p * 0.9f) }
                }
                container.files.publish(listOf(output), MIME_PDF)
            }.onSuccess { result ->
                _state.update { it.copy(working = false, result = result) }
            }.onFailure { error ->
                _state.update { it.copy(working = false, message = error.toUiText()) }
            }
        }
    }

    fun clearResult() = _state.update { it.copy(result = null) }

    fun messageShown() = _state.update { it.copy(message = null) }

    override fun onCleared() {
        renderer?.close()
        renderer = null
    }

    companion object {
        /** Default size of each tool, as a fraction of the page width. */
        fun baseSize(tool: MarkType): Float = when (tool) {
            MarkType.PEN -> 0.004f
            MarkType.HIGHLIGHT -> 0.025f
            MarkType.RECT -> 0.004f
            MarkType.TEXT -> 0.045f
        }
    }
}
