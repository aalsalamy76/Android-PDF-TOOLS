package com.example.pdftools.ui.screens.home

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.pdftools.data.LanguageManager
import com.example.pdftools.data.PdfQuickInfo
import com.example.pdftools.data.RecentFile
import com.example.pdftools.data.ThemeMode
import com.example.pdftools.data.container
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** A document chosen on the home screen, waiting for the user to pick what to do with it. */
data class PickedPdf(
    val uri: Uri,
    val name: String,
    val info: PdfQuickInfo?,
    val isRecent: Boolean,
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    val recents: StateFlow<List<RecentFile>> = container.recents.items
    val themeMode: StateFlow<ThemeMode> = container.settings.themeMode

    private val _picked = MutableStateFlow<PickedPdf?>(null)
    val picked: StateFlow<PickedPdf?> = _picked.asStateFlow()

    /** Called with the URI returned by the system picker. */
    fun onPdfPicked(uri: Uri) {
        // Keeps access after a restart, so the file can appear in the recent list.
        container.recents.takePersistablePermission(uri)
        showActions(uri, name = null, isRecent = false)
    }

    fun showActionsForRecent(recent: RecentFile) {
        showActions(Uri.parse(recent.uri), recent.name, isRecent = true)
    }

    private fun showActions(uri: Uri, name: String?, isRecent: Boolean) {
        _picked.value = PickedPdf(uri, name ?: "…", info = null, isRecent = isRecent)
        viewModelScope.launch {
            val info = container.thumbnails.quickInfo(uri, container.files)
            _picked.update { current ->
                if (current?.uri == uri) current.copy(name = info.name, info = info) else current
            }
        }
    }

    fun dismissActions() {
        _picked.value = null
    }

    suspend fun thumbnail(uri: String): Bitmap? = container.thumbnails.thumbnail(uri)

    fun removeRecent(uri: String) {
        container.recents.remove(uri)
        container.thumbnails.forget(uri)
    }

    fun clearRecents() {
        recents.value.forEach { container.thumbnails.forget(it.uri) }
        container.recents.clear()
    }

    fun setTheme(mode: ThemeMode) = container.settings.setThemeMode(mode)

    fun setLanguage(tag: String) = LanguageManager.setLanguage(tag)
}
