package com.example.pdftools.ui.screens.home

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import com.example.pdftools.data.LanguageManager
import com.example.pdftools.data.RecentFile
import com.example.pdftools.data.ThemeMode
import com.example.pdftools.data.container
import kotlinx.coroutines.flow.StateFlow

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    val recents: StateFlow<List<RecentFile>> = container.recents.items
    val themeMode: StateFlow<ThemeMode> = container.settings.themeMode

    /** Must be called with the URI returned by the picker to keep access after a restart. */
    fun onPdfPicked(uri: Uri) {
        container.recents.takePersistablePermission(uri)
    }

    fun removeRecent(uri: String) = container.recents.remove(uri)

    fun clearRecents() = container.recents.clear()

    fun setTheme(mode: ThemeMode) = container.settings.setThemeMode(mode)

    fun setLanguage(tag: String) = LanguageManager.setLanguage(tag)
}
