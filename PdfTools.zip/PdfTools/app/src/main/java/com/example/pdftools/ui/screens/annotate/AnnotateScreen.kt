@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.pdftools.ui.screens.annotate

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.BorderColor
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.data.Mark
import com.example.pdftools.data.MarkPoint
import com.example.pdftools.data.MarkType
import com.example.pdftools.ui.Tool
import com.example.pdftools.ui.accent
import com.example.pdftools.ui.components.BottomActionBar
import com.example.pdftools.ui.components.MessageEffect
import com.example.pdftools.ui.components.PickFileCard
import com.example.pdftools.ui.components.ResultSheet
import com.example.pdftools.ui.components.ToolScaffold
import com.example.pdftools.ui.components.WorkingCard
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

private data class ToolChoice(val type: MarkType, val icon: ImageVector, @StringRes val label: Int)

private val ToolChoices = listOf(
    ToolChoice(MarkType.PEN, Icons.Filled.Edit, R.string.annotate_pen),
    ToolChoice(MarkType.HIGHLIGHT, Icons.Filled.BorderColor, R.string.annotate_highlight),
    ToolChoice(MarkType.RECT, Icons.Filled.CropSquare, R.string.annotate_rect),
    ToolChoice(MarkType.TEXT, Icons.Filled.TextFields, R.string.annotate_text),
)

@Composable
fun AnnotateScreen(
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: AnnotateViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    MessageEffect(state.message, snackbarHostState, viewModel::messageShown)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.load(uri)
    }
    val pick: () -> Unit = { picker.launch(arrayOf("application/pdf")) }
    val source = state.source

    ToolScaffold(
        title = stringResource(R.string.tool_annotate),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
        actions = {
            if (source != null) {
                IconButton(onClick = viewModel::undo, enabled = state.marks.isNotEmpty() && !state.working) {
                    Icon(Icons.Filled.Undo, contentDescription = stringResource(R.string.action_undo))
                }
                IconButton(onClick = viewModel::clearPage, enabled = state.pageMarks.isNotEmpty() && !state.working) {
                    Icon(Icons.Filled.DeleteSweep, contentDescription = stringResource(R.string.annotate_clear_page))
                }
            }
        },
        bottomBar = {
            if (source != null) {
                BottomActionBar {
                    IconButton(
                        enabled = state.currentPage > 0,
                        onClick = { viewModel.goToPage(state.currentPage - 1) },
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, stringResource(R.string.action_previous_page))
                    }
                    Text(
                        stringResource(R.string.page_x_of_y, state.currentPage + 1, state.pageSizes.size),
                        style = MaterialTheme.typography.titleSmall,
                    )
                    IconButton(
                        enabled = state.currentPage < state.pageSizes.lastIndex,
                        onClick = { viewModel.goToPage(state.currentPage + 1) },
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, stringResource(R.string.action_next_page))
                    }
                    Spacer(Modifier.weight(1f))
                    Button(
                        onClick = viewModel::save,
                        enabled = !state.working && state.marks.isNotEmpty(),
                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.action_save))
                    }
                }
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (state.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

            if (source == null) {
                if (!state.loading) {
                    PickFileCard(
                        icon = Tool.ANNOTATE.icon,
                        title = stringResource(R.string.tool_annotate),
                        description = stringResource(R.string.annotate_empty_desc),
                        buttonText = stringResource(R.string.action_choose_pdf),
                        onPick = pick,
                        accent = Tool.ANNOTATE.category.accent(),
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
                return@Column
            }

            // Tools
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ToolChoices) { choice ->
                    FilterChip(
                        selected = state.tool == choice.type,
                        onClick = { viewModel.selectTool(choice.type) },
                        label = { Text(stringResource(choice.label)) },
                        leadingIcon = { Icon(choice.icon, contentDescription = null, modifier = Modifier.size(18.dp)) },
                    )
                }
            }

            // Colors + size
            Row(verticalAlignment = Alignment.CenterVertically) {
                InkPalette.forEach { argb ->
                    val selected = argb == state.color
                    Box(
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .size(if (selected) 30.dp else 24.dp)
                            .clip(CircleShape)
                            .background(Color(argb))
                            .border(
                                width = if (selected) 3.dp else 1.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                shape = CircleShape,
                            )
                            .clickable { viewModel.selectColor(argb) },
                    )
                }
                Slider(
                    value = state.sizeFactor,
                    onValueChange = viewModel::setSizeFactor,
                    valueRange = 0.5f..3f,
                    modifier = Modifier.weight(1f),
                )
            }

            Text(
                stringResource(if (state.tool == MarkType.TEXT) R.string.annotate_hint_text else R.string.annotate_hint_draw),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            AnnotatablePage(
                state = state,
                loader = viewModel::renderPage,
                onStroke = viewModel::addStroke,
                onTextTap = viewModel::requestText,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
            )

            if (state.working) WorkingCard(progress = state.progress, modifier = Modifier.padding(bottom = 8.dp))
        }
    }

    if (state.pendingTextAt != null) {
        TextInputDialog(onDismiss = viewModel::cancelText, onConfirm = viewModel::addText)
    }

    state.result?.let { result ->
        ResultSheet(
            result = result,
            onDismiss = viewModel::clearResult,
            onOpenPdf = { onOpenPdf(it.uri) },
            onContinue = { tool, file -> onNavigate(tool.route(file.uri.toString())) },
            exclude = Tool.ANNOTATE,
        )
    }
}

/** Current page with the marks drawn on top; the finger draws with the selected tool. */
@Composable
private fun AnnotatablePage(
    state: AnnotateUiState,
    loader: suspend (Int, Int) -> Bitmap?,
    onStroke: (List<MarkPoint>) -> Unit,
    onTextTap: (MarkPoint) -> Unit,
    modifier: Modifier = Modifier,
) {
    val pageSize = state.pageSizes.getOrNull(state.currentPage) ?: return
    val aspect = pageSize.width.toFloat() / pageSize.height.toFloat()
    val density = LocalDensity.current
    val pageIndex = state.currentPage
    val textImages: Map<Long, ImageBitmap> = remember(state.textBitmaps) {
        state.textBitmaps.mapValues { it.value.asImageBitmap() }
    }

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val boxWidth = min(maxWidth, maxHeight * aspect)
        val boxHeight = boxWidth / aspect
        val renderWidth = with(density) { (boxWidth.toPx() * 1.5f).roundToInt() }.coerceIn(300, 2000)

        val page by produceState<Bitmap?>(null, pageIndex, renderWidth) {
            value = null
            value = loader(pageIndex, renderWidth)
        }
        val current = remember(pageIndex) { mutableStateListOf<Offset>() }
        val tool = state.tool

        // Touch coordinates are left-to-right, so this area is laid out LTR even in Arabic.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(
                modifier = Modifier
                    .size(boxWidth, boxHeight)
                    .shadow(4.dp)
                    .background(Color.White),
            ) {
                val bitmap = page
                if (bitmap == null) {
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                } else {
                    val image = remember(bitmap) { bitmap.asImageBitmap() }
                    Image(
                        bitmap = image,
                        contentDescription = null,
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(pageIndex, tool) {
                            awaitEachGesture {
                                val down = awaitFirstDown()
                                down.consume()
                                val width = size.width.toFloat().coerceAtLeast(1f)
                                val height = size.height.toFloat().coerceAtLeast(1f)
                                if (tool == MarkType.TEXT) {
                                    do {
                                        val event = awaitPointerEvent()
                                        event.changes.forEach { it.consume() }
                                    } while (event.changes.any { it.pressed })
                                    onTextTap(
                                        MarkPoint(
                                            (down.position.x / width).coerceIn(0f, 0.95f),
                                            (down.position.y / height).coerceIn(0f, 0.95f),
                                        )
                                    )
                                } else {
                                    current.clear()
                                    current.add(down.position)
                                    while (true) {
                                        val event = awaitPointerEvent()
                                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                        if (!change.pressed) break
                                        current.add(change.position)
                                        change.consume()
                                    }
                                    onStroke(
                                        current.map {
                                            MarkPoint((it.x / width).coerceIn(0f, 1f), (it.y / height).coerceIn(0f, 1f))
                                        }
                                    )
                                    current.clear()
                                }
                            }
                        },
                ) {
                    state.pageMarks.forEach { mark -> drawMark(mark, textImages[mark.id]) }
                    if (current.isNotEmpty()) {
                        val preview = Mark(
                            id = -1L,
                            page = pageIndex,
                            type = tool,
                            points = current.map { MarkPoint(it.x / size.width, it.y / size.height) },
                            color = state.color,
                            size = AnnotateViewModel.baseSize(tool) * state.sizeFactor,
                        )
                        drawMark(preview, null)
                    }
                }
            }
        }
    }
}

/** Draws one mark; coordinates are page fractions, sizes are fractions of the page width. */
private fun DrawScope.drawMark(mark: Mark, textImage: ImageBitmap?) {
    val w = size.width
    val h = size.height
    if (mark.points.isEmpty()) return
    val strokeWidth = max(1f, mark.size * w)
    when (mark.type) {
        MarkType.PEN, MarkType.HIGHLIGHT -> {
            val highlight = mark.type == MarkType.HIGHLIGHT
            val color = Color(mark.color).copy(alpha = if (highlight) 0.4f else 1f)
            val first = mark.points[0]
            if (mark.points.size == 1) {
                drawCircle(color, radius = strokeWidth / 2f, center = Offset(first.x * w, first.y * h))
                return
            }
            val path = Path()
            path.moveTo(first.x * w, first.y * h)
            for (i in 1 until mark.points.size) {
                val p = mark.points[i]
                path.lineTo(p.x * w, p.y * h)
            }
            drawPath(
                path,
                color = color,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round),
                blendMode = if (highlight) BlendMode.Multiply else BlendMode.SrcOver,
            )
        }

        MarkType.RECT -> {
            val a = mark.points.first()
            val b = mark.points.last()
            drawRect(
                color = Color(mark.color),
                topLeft = Offset(minOf(a.x, b.x) * w, minOf(a.y, b.y) * h),
                size = Size(abs(a.x - b.x) * w, abs(a.y - b.y) * h),
                style = Stroke(width = strokeWidth),
            )
        }

        MarkType.TEXT -> if (textImage != null) {
            val top = mark.points[0]
            val boxHeight = mark.size * w
            val boxWidth = boxHeight * textImage.width / textImage.height
            drawImage(
                image = textImage,
                srcOffset = IntOffset.Zero,
                srcSize = IntSize(textImage.width, textImage.height),
                dstOffset = IntOffset((top.x * w).roundToInt(), (top.y * h).roundToInt()),
                dstSize = IntSize(boxWidth.roundToInt().coerceAtLeast(1), boxHeight.roundToInt().coerceAtLeast(1)),
            )
        }
    }
}

@Composable
private fun TextInputDialog(onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(stringResource(R.string.annotate_text_title)) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(200) },
                label = { Text(stringResource(R.string.annotate_text_label)) },
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text(stringResource(R.string.action_add))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}
