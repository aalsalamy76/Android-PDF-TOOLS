package com.example.pdftools.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.util.LruCache
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import kotlin.math.roundToInt

/** Quick facts about a document, read without copying it. */
data class PdfQuickInfo(
    val uri: Uri,
    val name: String,
    val size: Long,
    /** null while unknown (still loading or unreadable). */
    val pageCount: Int?,
    val locked: Boolean = false,
)

/**
 * First-page thumbnails for the recent files (memory + disk cache),
 * and quick information about a document.
 */
class ThumbnailRepository(private val context: Context) {

    private val memory = object : LruCache<String, Bitmap>(MEMORY_CACHE_KB) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    /** PdfRenderer (pdfium) is not safe to use from several threads at once. */
    private val lock = Mutex()

    private val dir: File get() = File(context.cacheDir, "thumbs").apply { mkdirs() }

    suspend fun thumbnail(uri: String): Bitmap? {
        val inMemory: Bitmap? = memory.get(uri)
        if (inMemory != null) return inMemory
        return withContext(Dispatchers.IO) {
            try {
                val file = File(dir, key(uri) + ".jpg")
                val cached = if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
                val bitmap = cached ?: lock.withLock { render(Uri.parse(uri)) }?.also { rendered ->
                    file.outputStream().use { rendered.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                }
                if (bitmap != null) memory.put(uri, bitmap)
                bitmap
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                null
            }
        }
    }

    /** Name, size and page count of [uri]. Never throws. */
    suspend fun quickInfo(uri: Uri, files: FileRepository): PdfQuickInfo = withContext(Dispatchers.IO) {
        val info = files.queryInfo(uri)
        var locked = false
        val pages = try {
            lock.withLock {
                context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
                    PdfRenderer(descriptor).use { it.pageCount }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: SecurityException) {
            locked = true
            null
        } catch (_: Throwable) {
            null
        }
        PdfQuickInfo(uri, info.name, info.size, pages, locked)
    }

    fun forget(uri: String) {
        memory.remove(uri)
        File(dir, key(uri) + ".jpg").delete()
    }

    private fun render(uri: Uri): Bitmap? =
        context.contentResolver.openFileDescriptor(uri, "r")?.use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                if (renderer.pageCount == 0) return@use null
                renderer.openPage(0).use { page ->
                    val width = THUMB_WIDTH
                    val height = (width.toFloat() * page.height / page.width).roundToInt().coerceIn(1, width * 3)
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmap
                }
            }
        }

    private fun key(uri: String): String =
        MessageDigest.getInstance("SHA-1").digest(uri.toByteArray())
            .joinToString("") { "%02x".format(it) }

    private companion object {
        const val THUMB_WIDTH = 240
        const val MEMORY_CACHE_KB = 8 * 1024
    }
}
