package com.example.pdftools.util

import android.content.Context
import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

/**
 * Text that is resolved in the UI layer, so ViewModels never hold a Context
 * and the text always follows the language chosen in the app.
 */
sealed interface UiText {
    data class Res(@StringRes val id: Int, val args: List<Any> = emptyList()) : UiText
    data class Plain(val value: String) : UiText

    fun asString(context: Context): String = when (this) {
        is Plain -> value
        is Res -> {
            val resolved = args.map { if (it is UiText) it.asString(context) else it }
            context.getString(id, *resolved.toTypedArray())
        }
    }
}

@Composable
fun UiText.asString(): String {
    // LocalContext is the Activity, whose resources follow the in-app language.
    val context = LocalContext.current
    return asString(context)
}

fun uiText(@StringRes id: Int, vararg args: Any): UiText = UiText.Res(id, args.toList())
