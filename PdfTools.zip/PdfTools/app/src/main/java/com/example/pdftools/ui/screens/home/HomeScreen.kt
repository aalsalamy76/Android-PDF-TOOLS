@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)

package com.example.pdftools.ui.screens.home

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.data.LanguageManager
import com.example.pdftools.data.RecentFile
import com.example.pdftools.data.ThemeMode
import com.example.pdftools.navigation.Routes
import com.example.pdftools.ui.Tool
import com.example.pdftools.ui.ToolCategory
import com.example.pdftools.ui.accent
import com.example.pdftools.ui.components.AppBottomSheet
import com.example.pdftools.ui.components.AppCard
import com.example.pdftools.ui.components.PdfActionSheet
import com.example.pdftools.ui.components.ToolIcon
import com.example.pdftools.ui.theme.HeroGradientDark
import com.example.pdftools.ui.theme.HeroGradientLight
import androidx.compose.foundation.isSystemInDarkTheme
import java.text.DateFormat
import java.util.Date

const val DEVELOPER_NAME = "Abdullah AL-SALAMY"

@Composable
fun HomeScreen(
    onOpenPdf: (Uri) -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: HomeViewModel = viewModel(),
) {
    val recents by viewModel.recents.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val picked by viewModel.picked.collectAsStateWithLifecycle()
    var settingsOpen by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.onPdfPicked(uri)
    }
    val pickPdf: () -> Unit = { picker.launch(arrayOf("application/pdf")) }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        val layoutDirection = LocalLayoutDirection.current
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = padding.calculateStartPadding(layoutDirection) + 16.dp,
                end = padding.calculateEndPadding(layoutDirection) + 16.dp,
                top = padding.calculateTopPadding() + 8.dp,
                bottom = padding.calculateBottomPadding() + 24.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item(key = "header") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            stringResource(R.string.app_name),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            stringResource(R.string.home_tagline),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    RoundIconButton(Icons.Filled.Settings, stringResource(R.string.menu_settings)) {
                        settingsOpen = true
                    }
                    Spacer(Modifier.width(8.dp))
                    RoundIconButton(Icons.Filled.Info, stringResource(R.string.menu_about)) {
                        onNavigate(Routes.ABOUT)
                    }
                }
            }

            item(key = "hero") {
                HeroCard(onOpen = pickPdf, onScan = { onNavigate(Tool.SCAN.route()) })
            }

            item(key = "recent_header") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionTitle(stringResource(R.string.section_recent), Modifier.weight(1f))
                    if (recents.isNotEmpty()) {
                        TextButton(onClick = viewModel::clearRecents) {
                            Text(stringResource(R.string.action_clear_all))
                        }
                    }
                }
            }
            item(key = "recent_list") {
                if (recents.isEmpty()) {
                    AppCard(Modifier.fillMaxWidth()) {
                        Text(
                            stringResource(R.string.recent_empty),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(18.dp),
                        )
                    }
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(recents, key = { it.uri }) { recent ->
                            RecentCard(
                                recent = recent,
                                loader = viewModel::thumbnail,
                                onClick = { onOpenPdf(Uri.parse(recent.uri)) },
                                onMore = { viewModel.showActionsForRecent(recent) },
                            )
                        }
                    }
                }
            }

            ToolCategory.values().forEach { category ->
                item(key = "cat_${category.name}") {
                    SectionTitle(stringResource(category.title), Modifier.padding(top = 6.dp))
                }
                Tool.values().filter { it.category == category }.chunked(2).forEachIndexed { index, row ->
                    item(key = "tools_${category.name}_$index") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(IntrinsicSize.Min),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            row.forEach { tool ->
                                ToolCard(
                                    tool = tool,
                                    onClick = { onNavigate(tool.route()) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight(),
                                )
                            }
                            if (row.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }

            item(key = "credit") {
                Text(
                    text = stringResource(R.string.developed_by, DEVELOPER_NAME),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onNavigate(Routes.ABOUT) }
                        .padding(vertical = 16.dp),
                )
            }
        }
    }

    picked?.let { current ->
        PdfActionSheet(
            name = current.name,
            info = current.info,
            onDismiss = viewModel::dismissActions,
            onOpen = { onOpenPdf(current.uri) },
            onTool = { tool -> onNavigate(tool.route(current.uri.toString())) },
            onRemove = if (current.isRecent) ({ viewModel.removeRecent(current.uri.toString()) }) else null,
        )
    }

    if (settingsOpen) {
        SettingsSheet(
            themeMode = themeMode,
            onTheme = viewModel::setTheme,
            onLanguage = { tag ->
                settingsOpen = false
                viewModel.setLanguage(tag)
            },
            onDismiss = { settingsOpen = false },
        )
    }
}

@Composable
private fun RoundIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape),
    ) {
        Icon(icon, contentDescription = description)
    }
}

@Composable
private fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onBackground,
        modifier = modifier,
    )
}

/** Big gradient card: open a PDF or scan a document. */
@Composable
private fun HeroCard(onOpen: () -> Unit, onScan: () -> Unit) {
    val gradient = if (isSystemInDarkTheme()) HeroGradientDark else HeroGradientLight
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(gradient)),
    ) {
        Icon(
            Icons.Filled.PictureAsPdf,
            contentDescription = null,
            tint = Color.White.copy(alpha = 0.14f),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .offset(x = 36.dp, y = (-24).dp)
                .size(170.dp),
        )
        Column(Modifier.padding(22.dp)) {
            Text(
                stringResource(R.string.home_open_title),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
            )
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(R.string.home_open_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.92f),
            )
            Spacer(Modifier.height(18.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Button(
                    onClick = onOpen,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFFC62828),
                    ),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                ) {
                    Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.action_choose_pdf), fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(
                    onClick = onScan,
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.75f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                ) {
                    Icon(Icons.Filled.PhotoCamera, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.action_scan))
                }
            }
        }
    }
}

@Composable
private fun ToolCard(tool: Tool, onClick: () -> Unit, modifier: Modifier = Modifier) {
    AppCard(modifier = modifier, onClick = onClick) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            ToolIcon(tool.icon, tool.category.accent())
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(stringResource(tool.title), style = MaterialTheme.typography.titleSmall)
                Text(
                    stringResource(tool.description),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** Recent document with its first page as a thumbnail. */
@Composable
private fun RecentCard(
    recent: RecentFile,
    loader: suspend (String) -> Bitmap?,
    onClick: () -> Unit,
    onMore: () -> Unit,
) {
    val locale = LocalConfiguration.current.locales[0]
    val date = remember(recent.openedAt, locale) {
        DateFormat.getDateInstance(DateFormat.MEDIUM, locale).format(Date(recent.openedAt))
    }
    val thumbnail by produceState<Bitmap?>(null, recent.uri) { value = loader(recent.uri) }

    Column(
        modifier = Modifier
            .width(124.dp)
            .clip(MaterialTheme.shapes.medium)
            .combinedClickable(onClick = onClick, onLongClick = onMore),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.75f)
                .clip(MaterialTheme.shapes.medium)
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium),
            contentAlignment = Alignment.Center,
        ) {
            val bitmap = thumbnail
            if (bitmap != null) {
                val image = remember(bitmap) { bitmap.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    alignment = Alignment.TopCenter,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Icon(
                    Icons.Filled.PictureAsPdf,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp),
                )
            }
            IconButton(
                onClick = onMore,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
            ) {
                Icon(
                    Icons.Filled.MoreVert,
                    contentDescription = stringResource(R.string.menu_more),
                    modifier = Modifier.size(18.dp),
                )
            }
        }
        Text(
            recent.name,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp),
        )
        Text(
            date,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 2.dp),
        )
    }
}

/** Language and theme, in a sheet that slides up from the bottom. */
@Composable
private fun SettingsSheet(
    themeMode: ThemeMode,
    onTheme: (ThemeMode) -> Unit,
    onLanguage: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val currentLanguage = remember { LanguageManager.currentTag() }
    AppBottomSheet(onDismiss = onDismiss) {
        Text(stringResource(R.string.menu_settings), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))

        Text(stringResource(R.string.menu_theme), style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.values().forEach { mode ->
                FilterChip(
                    selected = mode == themeMode,
                    onClick = { onTheme(mode) },
                    label = { Text(stringResource(themeLabel(mode))) },
                    leadingIcon = { Icon(themeIcon(mode), contentDescription = null, modifier = Modifier.size(18.dp)) },
                )
            }
        }
        Spacer(Modifier.height(20.dp))

        Text(stringResource(R.string.menu_language), style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(4.dp))
        LanguageManager.languages.forEach { language ->
            val selected = language.tag == currentLanguage
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.medium)
                    .selectable(selected = selected, role = Role.RadioButton, onClick = { onLanguage(language.tag) })
                    .padding(vertical = 10.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RadioButton(selected = selected, onClick = null)
                Spacer(Modifier.width(12.dp))
                Text(
                    language.nativeName ?: stringResource(R.string.language_system),
                    style = MaterialTheme.typography.bodyLarge,
                )
            }
        }
    }
}

private fun themeIcon(mode: ThemeMode): ImageVector = when (mode) {
    ThemeMode.SYSTEM -> Icons.Filled.BrightnessAuto
    ThemeMode.LIGHT -> Icons.Filled.LightMode
    ThemeMode.DARK -> Icons.Filled.DarkMode
}

@StringRes
private fun themeLabel(mode: ThemeMode): Int = when (mode) {
    ThemeMode.SYSTEM -> R.string.theme_system
    ThemeMode.LIGHT -> R.string.theme_light
    ThemeMode.DARK -> R.string.theme_dark
}
