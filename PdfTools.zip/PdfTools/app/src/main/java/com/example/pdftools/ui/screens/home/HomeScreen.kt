@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.pdftools.ui.screens.home

import android.net.Uri
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MergeType
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.data.LanguageManager
import com.example.pdftools.data.RecentFile
import com.example.pdftools.data.ThemeMode
import com.example.pdftools.navigation.Routes
import java.text.DateFormat
import java.util.Date

private data class ToolEntry(
    val icon: ImageVector,
    @StringRes val title: Int,
    @StringRes val subtitle: Int,
    val route: String,
)

private val Tools = listOf(
    ToolEntry(Icons.Filled.MergeType, R.string.tool_merge, R.string.tool_merge_desc, Routes.MERGE),
    ToolEntry(Icons.Filled.ContentCut, R.string.tool_split, R.string.tool_split_desc, Routes.split(null)),
    ToolEntry(Icons.Filled.GridView, R.string.tool_pages, R.string.tool_pages_desc, Routes.pages(null)),
    ToolEntry(Icons.Filled.Draw, R.string.tool_sign, R.string.tool_sign_desc, Routes.sign(null)),
    ToolEntry(
        Icons.Filled.Collections, R.string.tool_images_to_pdf, R.string.tool_images_to_pdf_desc,
        Routes.convert(Routes.TAB_IMAGES_TO_PDF)
    ),
    ToolEntry(
        Icons.Filled.PhotoLibrary, R.string.tool_pdf_to_images, R.string.tool_pdf_to_images_desc,
        Routes.convert(Routes.TAB_PDF_TO_IMAGES)
    ),
    ToolEntry(
        Icons.Filled.Description, R.string.tool_pdf_to_text, R.string.tool_pdf_to_text_desc,
        Routes.convert(Routes.TAB_PDF_TO_TEXT)
    ),
)

@Composable
fun HomeScreen(
    onOpenPdf: (Uri) -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: HomeViewModel = viewModel(),
) {
    val recents by viewModel.recents.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    var languageMenu by remember { mutableStateOf(false) }
    var themeMenu by remember { mutableStateOf(false) }
    val currentLanguage = remember { LanguageManager.currentTag() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            viewModel.onPdfPicked(uri)
            onOpenPdf(uri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    Box {
                        IconButton(onClick = { languageMenu = true }) {
                            Icon(Icons.Filled.Language, contentDescription = stringResource(R.string.menu_language))
                        }
                        DropdownMenu(expanded = languageMenu, onDismissRequest = { languageMenu = false }) {
                            LanguageManager.languages.forEach { language ->
                                DropdownMenuItem(
                                    text = {
                                        Text(language.nativeName ?: stringResource(R.string.language_system))
                                    },
                                    trailingIcon = {
                                        if (language.tag == currentLanguage) {
                                            Icon(Icons.Filled.Check, contentDescription = null)
                                        }
                                    },
                                    onClick = {
                                        languageMenu = false
                                        viewModel.setLanguage(language.tag)
                                    },
                                )
                            }
                        }
                    }
                    Box {
                        IconButton(onClick = { themeMenu = true }) {
                            Icon(themeIcon(themeMode), contentDescription = stringResource(R.string.menu_theme))
                        }
                        DropdownMenu(expanded = themeMenu, onDismissRequest = { themeMenu = false }) {
                            ThemeMode.values().forEach { mode ->
                                DropdownMenuItem(
                                    text = { Text(stringResource(themeLabel(mode))) },
                                    leadingIcon = { Icon(themeIcon(mode), contentDescription = null) },
                                    trailingIcon = {
                                        if (mode == themeMode) Icon(Icons.Filled.Check, contentDescription = null)
                                    },
                                    onClick = {
                                        themeMenu = false
                                        viewModel.setTheme(mode)
                                    },
                                )
                            }
                        }
                    }
                    IconButton(onClick = { onNavigate(Routes.ABOUT) }) {
                        Icon(Icons.Filled.Info, contentDescription = stringResource(R.string.menu_about))
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item(key = "open") {
                OpenPdfCard(onClick = { picker.launch(arrayOf("application/pdf")) })
            }

            item(key = "tools_header") {
                SectionHeader(stringResource(R.string.section_tools))
            }

            Tools.chunked(2).forEachIndexed { rowIndex, row ->
                item(key = "tools_$rowIndex") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        row.forEach { tool ->
                            ToolCard(
                                tool = tool,
                                onClick = { onNavigate(tool.route) },
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                            )
                        }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }

            item(key = "recent_header") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    SectionHeader(stringResource(R.string.section_recent), Modifier.weight(1f))
                    if (recents.isNotEmpty()) {
                        TextButton(onClick = viewModel::clearRecents) {
                            Text(stringResource(R.string.action_clear_all))
                        }
                    }
                }
            }

            if (recents.isEmpty()) {
                item(key = "recent_empty") {
                    Text(
                        stringResource(R.string.recent_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp),
                    )
                }
            } else {
                items(recents, key = { it.uri }) { recent ->
                    RecentRow(
                        recent = recent,
                        onClick = { onOpenPdf(Uri.parse(recent.uri)) },
                        onRemove = { viewModel.removeRecent(recent.uri) },
                    )
                }
            }

            item(key = "credit") {
                Text(
                    text = stringResource(R.string.developed_by, DEVELOPER_NAME),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onNavigate(Routes.ABOUT) }
                        .padding(vertical = 16.dp),
                )
            }
        }
    }
}

const val DEVELOPER_NAME = "Abdullah AL-SALAMY"

@Composable
private fun OpenPdfCard(onClick: () -> Unit) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
        ),
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.PictureAsPdf, contentDescription = null, modifier = Modifier.size(48.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(stringResource(R.string.home_open_title), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.home_open_subtitle), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = onClick,
                    colors = ButtonDefaults.buttonColors(),
                ) {
                    Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.action_choose_pdf))
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = modifier.padding(top = 8.dp),
    )
}

@Composable
private fun ToolCard(tool: ToolEntry, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedCard(onClick = onClick, modifier = modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.secondaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(tool.icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
            }
            Text(stringResource(tool.title), style = MaterialTheme.typography.titleSmall)
            Text(
                stringResource(tool.subtitle),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun RecentRow(recent: RecentFile, onClick: () -> Unit, onRemove: () -> Unit) {
    val context = LocalContext.current
    val locale = LocalConfiguration.current.locales[0]
    val date = remember(recent.openedAt, locale) {
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, locale).format(Date(recent.openedAt))
    }
    val size = if (recent.size > 0) Formatter.formatShortFileSize(context, recent.size) else null
    OutlinedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        ListItem(
            colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surface),
            leadingContent = { Icon(Icons.Filled.History, contentDescription = null) },
            headlineContent = { Text(recent.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            supportingContent = { Text(listOfNotNull(date, size).joinToString(" · ")) },
            trailingContent = {
                IconButton(onClick = onRemove) {
                    Icon(Icons.Filled.Close, contentDescription = stringResource(R.string.action_remove))
                }
            },
        )
    }
}

private fun themeIcon(mode: ThemeMode): ImageVector = when (mode) {
    ThemeMode.SYSTEM -> Icons.Filled.BrightnessAuto
    ThemeMode.LIGHT -> Icons.Filled.LightMode
    ThemeMode.DARK -> Icons.Filled.DarkMode
}

@StringRes
private fun themeLabel(mode: ThemeMode): Int = when (mode) {
    ThemeMode.SYSTEM -> R.string.theme_system
    ThemeMode.LIGHT -> R.string.theme_light
    ThemeMode.DARK -> R.string.theme_dark
}
