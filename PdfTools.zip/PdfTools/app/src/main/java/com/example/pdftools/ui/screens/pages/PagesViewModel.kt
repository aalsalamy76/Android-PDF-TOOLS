package com.example.pdftools.ui.screens.pages

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.pdftools.R
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.OperationResult
import com.example.pdftools.data.PdfPageRenderer
import com.example.pdftools.data.PdfRepository
import com.example.pdftools.data.SourcePdf
import com.example.pdftools.data.baseNameOf
import com.example.pdftools.data.container
import com.example.pdftools.data.normalizeRotation
import com.example.pdftools.navigation.Routes
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import com.example.pdftools.util.uiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** One page in the editor: the original page index and the extra rotation chosen by the user. */
data class PageTile(val sourceIndex: Int, val rotation: Int = 0)

data class PagesUiState(
    val source: SourcePdf? = null,
    val loading: Boolean = false,
    val pages: List<PageTile> = emptyList(),
    val working: Boolean = false,
    val result: OperationResult? = null,
    val message: UiText? = null,
) {
    val isModified: Boolean
        get() = source != null && (
            pages.size != source.pageCount ||
                pages.withIndex().any { (i, tile) -> tile.sourceIndex != i || tile.rotation != 0 }
            )
}

class PagesViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(PagesUiState())
    val state: StateFlow<PagesUiState> = _state.asStateFlow()

    private var renderer: PdfPageRenderer? = null

    init {
        savedStateHandle.get<String>(Routes.ARG_URI)?.let { load(Uri.parse(it)) }
    }

    fun load(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, result = null) }
            ioCatching {
                val pdf = container.openSource(uri)
                pdf to PdfPageRenderer.open(pdf.file)
            }.onSuccess { (pdf, newRenderer) ->
                renderer?.close()
                renderer = newRenderer
                _state.update {
                    it.copy(
                        loading = false,
                        source = pdf,
                        pages = List(pdf.pageCount) { index -> PageTile(index) },
                    )
                }
            }.onFailure { error ->
                _state.update { it.copy(loading = false, message = error.toUiText()) }
            }
        }
    }

    suspend fun thumbnail(index: Int, widthPx: Int): Bitmap? = renderer?.renderOrNull(index, widthPx)

    fun rotate(position: Int, degrees: Int) = editPages { pages ->
        pages.mapIndexed { i, tile ->
            if (i == position) tile.copy(rotation = normalizeRotation(tile.rotation + degrees)) else tile
        }
    }

    fun rotateAll(degrees: Int) = editPages { pages ->
        pages.map { it.copy(rotation = normalizeRotation(it.rotation + degrees)) }
    }

    fun move(position: Int, delta: Int) = editPages { pages ->
        val target = position + delta
        if (position !in pages.indices || target !in pages.indices) {
            pages
        } else {
            pages.toMutableList().apply { add(target, removeAt(position)) }
        }
    }

    fun delete(position: Int) {
        if (_state.value.pages.size <= 1) {
            _state.update { it.copy(message = uiText(R.string.pages_cannot_delete_all)) }
            return
        }
        editPages { pages -> pages.filterIndexed { i, _ -> i != position } }
    }

    fun reset() {
        val source = _state.value.source ?: return
        _state.update { it.copy(pages = List(source.pageCount) { index -> PageTile(index) }, result = null) }
    }

    private fun editPages(transform: (List<PageTile>) -> List<PageTile>) {
        if (_state.value.working) return
        _state.update { it.copy(pages = transform(it.pages), result = null) }
    }

    fun save() {
        val snapshot = _state.value
        val source = snapshot.source ?: return
        if (snapshot.working || snapshot.pages.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(working = true, result = null) }
            ioCatching {
                val output = container.files.newOutputFile("${baseNameOf(source.name)}_edited.pdf")
                container.pdf.organize(
                    input = source.file,
                    edits = snapshot.pages.map { PdfRepository.PageEdit(it.sourceIndex, it.rotation) },
                    output = output,
                )
                container.files.publish(listOf(output), MIME_PDF)
            }.onSuccess { result ->
                _state.update { it.copy(working = false, result = result) }
            }.onFailure { error ->
                _state.update { it.copy(working = false, message = error.toUiText()) }
            }
        }
    }

    fun clearResult() = _state.update { it.copy(result = null) }

    fun messageShown() = _state.update { it.copy(message = null) }

    override fun onCleared() {
        renderer?.close()
        renderer = null
    }
}
