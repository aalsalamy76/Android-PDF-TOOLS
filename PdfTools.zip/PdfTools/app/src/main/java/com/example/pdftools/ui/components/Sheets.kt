@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.pdftools.ui.components

import android.text.format.Formatter
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.pdftools.R
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.OUTPUT_FOLDER
import com.example.pdftools.data.OperationResult
import com.example.pdftools.data.OutputFile
import com.example.pdftools.data.PdfQuickInfo
import com.example.pdftools.ui.Tool
import com.example.pdftools.ui.accent
import com.example.pdftools.ui.theme.Accent
import com.example.pdftools.util.Intents
import com.example.pdftools.util.asString

/** Bottom sheet with the app's colors; slides up from the bottom and can be swiped away. */
@Composable
fun AppBottomSheet(onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface,
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, bottom = 24.dp),
            content = content,
        )
    }
}

/**
 * "What do you want to do with this PDF?" — shown after choosing a file.
 * Opens the reader or any tool directly on the document.
 */
@Composable
fun PdfActionSheet(
    name: String,
    info: PdfQuickInfo?,
    onDismiss: () -> Unit,
    onOpen: (() -> Unit)?,
    onTool: (Tool) -> Unit,
    onRemove: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    val locked = info?.locked == true
    AppBottomSheet(onDismiss = onDismiss) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ToolIcon(
                if (locked) Icons.Filled.Lock else Icons.Filled.PictureAsPdf,
                Accent(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.primary),
                size = 52.dp,
            )
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                val size = info?.size?.takeIf { it > 0 }?.let { Formatter.formatShortFileSize(context, it) } ?: "—"
                val pages = info?.pageCount
                Text(
                    when {
                        info == null -> stringResource(R.string.loading)
                        locked -> stringResource(R.string.file_locked_and_size, size)
                        pages != null -> stringResource(R.string.file_pages_and_size, pages, size)
                        else -> size
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(18.dp))

        if (onOpen != null) {
            Button(
                onClick = { onDismiss(); onOpen() },
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 14.dp),
            ) {
                Icon(Icons.Filled.MenuBook, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text(stringResource(R.string.action_read_pdf), style = MaterialTheme.typography.titleSmall)
            }
            Spacer(Modifier.height(20.dp))
        }

        Text(stringResource(R.string.sheet_what_next), style = MaterialTheme.typography.titleSmall)
        if (locked) {
            Text(
                stringResource(R.string.sheet_locked_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
        Spacer(Modifier.height(12.dp))
        val tools = if (locked) listOf(Tool.UNLOCK) else Tool.forPdf
        ToolTileGrid(tools = tools, onTool = { onDismiss(); onTool(it) })

        if (onRemove != null) {
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { onDismiss(); onRemove() }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Icon(Icons.Filled.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(R.string.action_remove_recent))
            }
        }
    }
}

/** Grid of tools, 4 per row: colored icon + short name. */
@Composable
fun ToolTileGrid(tools: List<Tool>, onTool: (Tool) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        tools.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { tool ->
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clip(MaterialTheme.shapes.medium)
                            .clickable { onTool(tool) }
                            .padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        ToolIcon(tool.icon, tool.category.accent(), size = 52.dp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            stringResource(tool.title),
                            style = MaterialTheme.typography.labelMedium,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 2.dp),
                        )
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

/**
 * Slides up when a tool has finished: open the result, share it,
 * or continue with another tool on the new file.
 */
@Composable
fun ResultSheet(
    result: OperationResult,
    onDismiss: () -> Unit,
    onOpenPdf: (OutputFile) -> Unit,
    onContinue: (Tool, OutputFile) -> Unit,
    exclude: Tool? = null,
) {
    val context = LocalContext.current
    val single = result.files.singleOrNull()?.takeIf { it.mime == MIME_PDF }

    var appeared by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { appeared = true }
    val scale by animateFloatAsState(
        targetValue = if (appeared) 1f else 0.3f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "check",
    )

    AppBottomSheet(onDismiss = onDismiss) {
        Box(
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.tertiaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                Icons.Filled.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(40.dp),
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(
            stringResource(R.string.result_done),
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.align(Alignment.CenterHorizontally),
        )
        result.summary?.let { summary ->
            Text(
                summary.asString(),
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.tertiary,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 4.dp),
            )
        }
        Text(
            stringResource(R.string.result_saved_in, OUTPUT_FOLDER),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 4.dp),
        )
        Spacer(Modifier.height(14.dp))

        AppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                result.files.take(MAX_LISTED_FILES).forEach { file ->
                    Text(
                        file.name,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(vertical = 3.dp),
                    )
                }
                if (result.files.size > MAX_LISTED_FILES) {
                    Text(
                        stringResource(R.string.result_more_files, result.files.size - MAX_LISTED_FILES),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (single != null) {
                Button(
                    onClick = { onDismiss(); onOpenPdf(single) },
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(vertical = 14.dp),
                ) {
                    Icon(Icons.Filled.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.action_open))
                }
            }
            FilledTonalButton(
                onClick = { Intents.shareFiles(context, result.files.map { it.file }, result.mime) },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 14.dp),
            ) {
                Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(stringResource(R.string.action_share))
            }
        }

        if (single != null) {
            Spacer(Modifier.height(20.dp))
            Text(stringResource(R.string.sheet_continue_with), style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(Tool.forPdf.filter { it != exclude }) { tool ->
                    val accent = tool.category.accent()
                    AssistChip(
                        onClick = { onDismiss(); onContinue(tool, single) },
                        label = { Text(stringResource(tool.title)) },
                        leadingIcon = {
                            Icon(tool.icon, contentDescription = null, tint = accent.content, modifier = Modifier.size(18.dp))
                        },
                        colors = AssistChipDefaults.assistChipColors(containerColor = accent.container),
                        shape = CircleShape,
                    )
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text(stringResource(R.string.action_close))
        }
    }
}

private const val MAX_LISTED_FILES = 4
