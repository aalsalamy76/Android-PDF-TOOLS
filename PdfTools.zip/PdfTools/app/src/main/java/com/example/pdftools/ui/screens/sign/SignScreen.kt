@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.pdftools.ui.screens.sign

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.min
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.ui.components.BottomActionBar
import com.example.pdftools.ui.components.GoToPageDialog
import com.example.pdftools.ui.components.MessageEffect
import com.example.pdftools.ui.components.PickFileCard
import com.example.pdftools.ui.components.ResultCard
import com.example.pdftools.ui.components.SignaturePadDialog
import com.example.pdftools.ui.components.SourceFileCard
import com.example.pdftools.ui.components.ToolScaffold
import com.example.pdftools.ui.components.WorkingCard
import kotlin.math.roundToInt
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

@Composable
fun SignScreen(
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    viewModel: SignViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    MessageEffect(state.message, snackbarHostState, viewModel::messageShown)
    var goToOpen by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.load(uri)
    }
    val pick: () -> Unit = { picker.launch(arrayOf("application/pdf")) }
    val source = state.source

    ToolScaffold(
        title = stringResource(R.string.tool_sign),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
        bottomBar = {
            if (source != null) {
                BottomActionBar {
                    Text(
                        stringResource(R.string.sign_placed_count, state.placements.size),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Button(
                        onClick = viewModel::save,
                        enabled = !state.working && state.placements.isNotEmpty(),
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.action_save))
                    }
                }
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (state.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

            if (source == null) {
                if (!state.loading) {
                    PickFileCard(
                        icon = Icons.Filled.Draw,
                        title = stringResource(R.string.sign_empty_title),
                        description = stringResource(R.string.sign_empty_desc),
                        buttonText = stringResource(R.string.action_choose_pdf),
                        onPick = pick,
                    )
                }
            } else {
                SourceFileCard(source = source, onChange = if (state.working) null else pick)

                SignatureCard(
                    signature = state.signature,
                    onDraw = { viewModel.showPad(true) },
                )

                Text(
                    stringResource(R.string.sign_tap_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                // Page navigation
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        enabled = state.currentPage > 0,
                        onClick = { viewModel.goToPage(state.currentPage - 1) },
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, stringResource(R.string.action_previous_page))
                    }
                    TextButton(onClick = { goToOpen = true }, modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.page_x_of_y, state.currentPage + 1, state.pageSizes.size))
                    }
                    IconButton(
                        enabled = state.currentPage < state.pageSizes.lastIndex,
                        onClick = { viewModel.goToPage(state.currentPage + 1) },
                    ) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, stringResource(R.string.action_next_page))
                    }
                }

                SignablePage(
                    state = state,
                    loader = viewModel::renderPage,
                    onTap = viewModel::place,
                    onDrag = viewModel::moveBy,
                )

                // Size + remove
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.sign_size), style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.width(8.dp))
                    Slider(
                        value = state.currentPlacement?.widthFraction ?: state.widthFraction,
                        onValueChange = viewModel::setWidth,
                        valueRange = 0.08f..0.7f,
                        modifier = Modifier.weight(1f),
                    )
                    IconButton(
                        enabled = state.currentPlacement != null,
                        onClick = viewModel::removeCurrentPlacement,
                    ) {
                        Icon(Icons.Filled.Delete, stringResource(R.string.sign_remove_here))
                    }
                }

                if (state.working) WorkingCard(progress = null)

                state.result?.let { result ->
                    ResultCard(
                        result = result,
                        onOpenPdf = { onOpenPdf(it.uri) },
                        onDismiss = viewModel::clearResult,
                    )
                }
            }
        }
    }

    if (state.showPad) {
        SignaturePadDialog(
            onDismiss = { viewModel.showPad(false) },
            onSave = viewModel::setSignature,
        )
    }

    if (goToOpen) {
        GoToPageDialog(
            pageCount = state.pageSizes.size,
            onDismiss = { goToOpen = false },
            onGo = viewModel::goToPage,
        )
    }
}

@Composable
private fun SignatureCard(signature: Bitmap?, onDraw: () -> Unit) {
    OutlinedCard(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(width = 120.dp, height = 56.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center,
            ) {
                if (signature != null) {
                    val image = remember(signature) { signature.asImageBitmap() }
                    Image(
                        bitmap = image,
                        contentDescription = stringResource(R.string.sign_your_signature),
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(4.dp),
                    )
                } else {
                    Text("—", color = Color.Gray)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.sign_your_signature), style = MaterialTheme.typography.titleSmall)
                Text(
                    stringResource(if (signature == null) R.string.sign_none_yet else R.string.sign_saved_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            FilledTonalButton(onClick = onDraw) {
                Icon(Icons.Filled.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(stringResource(if (signature == null) R.string.action_draw else R.string.action_redraw))
            }
        }
    }
}

/** Current page with the signature overlay. Tap to place, drag to move. */
@Composable
private fun SignablePage(
    state: SignUiState,
    loader: suspend (Int, Int) -> Bitmap?,
    onTap: (Float, Float) -> Unit,
    onDrag: (Float, Float) -> Unit,
) {
    val pageSize = state.pageSizes.getOrNull(state.currentPage) ?: return
    val pageAspect = pageSize.width.toFloat() / pageSize.height.toFloat()
    val density = LocalDensity.current

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxWidth()
            .height(520.dp),
        contentAlignment = Alignment.Center,
    ) {
        val boxWidth = min(maxWidth, maxHeight * pageAspect)
        val boxHeight = boxWidth / pageAspect
        val renderWidth = with(density) { (boxWidth.toPx() * 1.5f).roundToInt() }.coerceIn(300, 2000)
        val pageIndex = state.currentPage

        val page by produceState<Bitmap?>(null, pageIndex, renderWidth) {
            value = null
            value = loader(pageIndex, renderWidth)
        }

        // Raw touch coordinates are left-to-right, so this area is laid out LTR even in Arabic.
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Box(
                modifier = Modifier
                    .size(boxWidth, boxHeight)
                    .shadow(4.dp)
                    .background(Color.White)
                    .pointerInput(pageIndex) {
                        detectTapGestures { offset ->
                            onTap(offset.x / size.width, offset.y / size.height)
                        }
                    }
                    .pointerInput(pageIndex) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onDrag(dragAmount.x / size.width, dragAmount.y / size.height)
                        }
                    },
            ) {
                val bitmap = page
                if (bitmap == null) {
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                } else {
                    val image = remember(bitmap) { bitmap.asImageBitmap() }
                    Image(
                        bitmap = image,
                        contentDescription = null,
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier.fillMaxSize(),
                    )
                }

                val placement = state.currentPlacement
                val signature = state.signature
                if (placement != null && signature != null) {
                    val boxWidthPx = with(density) { boxWidth.toPx() }
                    val boxHeightPx = with(density) { boxHeight.toPx() }
                    val sigWidthPx = placement.widthFraction * boxWidthPx
                    val sigHeightPx = sigWidthPx * signature.height / signature.width
                    val signatureImage = remember(signature) { signature.asImageBitmap() }
                    Image(
                        bitmap = signatureImage,
                        contentDescription = stringResource(R.string.sign_your_signature),
                        contentScale = ContentScale.FillBounds,
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (placement.centerX * boxWidthPx - sigWidthPx / 2f).roundToInt(),
                                    (placement.centerY * boxHeightPx - sigHeightPx / 2f).roundToInt(),
                                )
                            }
                            .size(
                                width = with(density) { sigWidthPx.toDp() },
                                height = with(density) { sigHeightPx.toDp() },
                            )
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)),
                    )
                }
            }
        }
    }
}
