package com.example.pdftools.util

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.pdftools.R
import java.io.File

object Intents {

    /** Opens the system share sheet for one or several local files. */
    fun shareFiles(context: Context, files: List<File>, mime: String) {
        if (files.isEmpty()) return
        val authority = "${context.packageName}.fileprovider"
        val uris: List<Uri> = files.map { FileProvider.getUriForFile(context, authority, it) }

        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris.first())
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE)
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        }
        intent.type = mime
        val clip = ClipData.newRawUri("", uris.first())
        uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
        intent.clipData = clip
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        start(context, Intent.createChooser(intent, context.getString(R.string.share_title)))
    }

    /** Opens a web page in the user's browser (the app itself has no Internet permission). */
    fun openUrl(context: Context, url: String) {
        start(context, Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun start(context: Context, intent: Intent) {
        try {
            if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(context, R.string.error_no_app, Toast.LENGTH_SHORT).show()
        }
    }
}
