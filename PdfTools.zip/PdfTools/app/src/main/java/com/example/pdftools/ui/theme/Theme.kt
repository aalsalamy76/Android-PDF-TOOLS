package com.example.pdftools.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable

/**
 * Light / dark theme. The choice made in the app (system / light / dark) is applied
 * through AppCompat night mode, so [isSystemInDarkTheme] already reflects it.
 */
@Composable
fun PdfToolsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
