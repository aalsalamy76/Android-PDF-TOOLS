package com.example.pdftools.ui.screens.convert

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.pdftools.R
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.MIME_TEXT
import com.example.pdftools.data.OperationResult
import com.example.pdftools.data.PdfRepository
import com.example.pdftools.data.SourcePdf
import com.example.pdftools.data.baseNameOf
import com.example.pdftools.data.container
import com.example.pdftools.data.timestamp
import com.example.pdftools.navigation.Routes
import com.example.pdftools.util.AppException
import com.example.pdftools.util.PageRanges
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import com.example.pdftools.util.uiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ImageItem(val id: Long, val uri: Uri, val name: String, val thumbnail: Bitmap?)

/** Resolution choices for PDF -> image. */
enum class ImageQuality(val dpi: Int, val label: Int) {
    LOW(96, R.string.quality_low),
    MEDIUM(150, R.string.quality_medium),
    HIGH(220, R.string.quality_high),
}

data class ConvertUiState(
    val tab: Int = Routes.TAB_IMAGES_TO_PDF,
    // Images -> PDF
    val images: List<ImageItem> = emptyList(),
    val pageSizeMode: PdfRepository.PageSizeMode = PdfRepository.PageSizeMode.A4,
    // PDF -> images / text
    val source: SourcePdf? = null,
    val imageFormat: PdfRepository.ImageFormat = PdfRepository.ImageFormat.PNG,
    val quality: ImageQuality = ImageQuality.MEDIUM,
    val ranges: String = "",
    val rangeError: UiText? = null,
    val extractedText: String? = null,
    val textTruncated: Boolean = false,
    // Common
    val loading: Boolean = false,
    val working: Boolean = false,
    val progress: Float = 0f,
    val result: OperationResult? = null,
    val message: UiText? = null,
)

class ConvertViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(
        ConvertUiState(tab = (savedStateHandle.get<Int>(Routes.ARG_TAB) ?: 0).coerceIn(0, 2))
    )
    val state: StateFlow<ConvertUiState> = _state.asStateFlow()

    private var nextId = 0L

    init {
        savedStateHandle.get<String>(Routes.ARG_URI)?.let { loadPdf(Uri.parse(it)) }
    }

    fun selectTab(tab: Int) = _state.update { it.copy(tab = tab, result = null) }

    // ------------------------------------------------------------ images -> PDF

    fun addImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(loading = true, result = null) }
            val added = ArrayList<ImageItem>()
            for (uri in uris) {
                val id = nextId++
                val item = ioCatching {
                    val name = container.files.queryInfo(uri).name
                    val thumb = try {
                        container.pdf.decodeImage(uri, THUMB_SIDE)
                    } catch (e: Exception) {
                        null
                    }
                    ImageItem(id, uri, name, thumb)
                }.getOrNull()
                if (item != null) added.add(item)
            }
            _state.update { it.copy(loading = false, images = it.images + added) }
        }
    }

    fun moveImage(index: Int, delta: Int) {
        _state.update { s ->
            val target = index + delta
            if (index !in s.images.indices || target !in s.images.indices) return@update s
            val list = s.images.toMutableList()
            list.add(target, list.removeAt(index))
            s.copy(images = list, result = null)
        }
    }

    fun removeImage(id: Long) = _state.update { s ->
        s.copy(images = s.images.filterNot { it.id == id }, result = null)
    }

    fun setPageSizeMode(mode: PdfRepository.PageSizeMode) = _state.update { it.copy(pageSizeMode = mode) }

    fun convertImagesToPdf() {
        val snapshot = _state.value
        if (snapshot.images.isEmpty() || snapshot.working) return
        launchWork {
            val output = container.files.newOutputFile("images_${timestamp()}.pdf")
            container.pdf.imagesToPdf(
                images = snapshot.images.map { it.uri to it.name },
                mode = snapshot.pageSizeMode,
                output = output,
                onProgress = { p -> setProgress(p) },
            )
            container.files.publish(listOf(output), MIME_PDF)
        }
    }

    // ------------------------------------------------------------ PDF -> images / text

    fun loadPdf(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, result = null) }
            ioCatching { container.openSource(uri) }
                .onSuccess { pdf ->
                    _state.update {
                        it.copy(
                            loading = false,
                            source = pdf,
                            ranges = "",
                            rangeError = null,
                            extractedText = null,
                        )
                    }
                }
                .onFailure { error ->
                    _state.update { it.copy(loading = false, message = error.toUiText()) }
                }
        }
    }

    fun setImageFormat(format: PdfRepository.ImageFormat) = _state.update { it.copy(imageFormat = format) }

    fun setQuality(quality: ImageQuality) = _state.update { it.copy(quality = quality) }

    fun setRanges(text: String) = _state.update { it.copy(ranges = text, rangeError = null) }

    fun convertPdfToImages() {
        val snapshot = _state.value
        val source = snapshot.source ?: return
        if (snapshot.working) return
        val pages: List<Int> = try {
            if (snapshot.ranges.isBlank()) {
                (0 until source.pageCount).toList()
            } else {
                PageRanges.parse(snapshot.ranges, source.pageCount).flatten().distinct()
            }
        } catch (e: AppException) {
            _state.update { it.copy(rangeError = e.text) }
            return
        }
        launchWork {
            val base = baseNameOf(source.name)
            val format = snapshot.imageFormat
            val digits = source.pageCount.toString().length.coerceAtLeast(2)
            val outputs = pages.map { index ->
                val number = (index + 1).toString().padStart(digits, '0')
                container.files.newOutputFile("${base}_page_$number.${format.extension}")
            }
            container.pdf.pdfToImages(
                input = source.file,
                pages = pages,
                dpi = snapshot.quality.dpi,
                format = format,
                outputs = outputs,
                onProgress = { p -> setProgress(p * 0.85f) },
            )
            container.files.publish(outputs, format.mime)
        }
    }

    fun extractText() {
        val snapshot = _state.value
        val source = snapshot.source ?: return
        if (snapshot.working) return
        _state.update { it.copy(extractedText = null) }
        launchWork {
            val text = container.pdf.extractText(source.file) { p -> setProgress(p) }
            val output = container.files.newOutputFile("${baseNameOf(source.name)}.txt")
            output.writeText(text, Charsets.UTF_8)
            val truncated = text.length > MAX_PREVIEW_CHARS
            _state.update {
                it.copy(extractedText = text.take(MAX_PREVIEW_CHARS), textTruncated = truncated)
            }
            container.files.publish(listOf(output), MIME_TEXT)
        }
    }

    // ------------------------------------------------------------ common

    private fun setProgress(progress: Float) = _state.update { it.copy(progress = progress) }

    private fun launchWork(block: suspend () -> OperationResult) {
        viewModelScope.launch {
            _state.update { it.copy(working = true, progress = 0f, result = null) }
            ioCatching { block() }
                .onSuccess { result -> _state.update { it.copy(working = false, result = result) } }
                .onFailure { error -> _state.update { it.copy(working = false, message = error.toUiText()) } }
        }
    }

    fun clearResult() = _state.update { it.copy(result = null) }

    fun messageShown() = _state.update { it.copy(message = null) }

    fun textCopied() = _state.update { it.copy(message = uiText(R.string.text_copied)) }

    private companion object {
        const val THUMB_SIDE = 240
        const val MAX_PREVIEW_CHARS = 20_000
    }
}
