@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.pdftools.ui.screens.tool

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.data.PdfRepository
import com.example.pdftools.ui.Tool
import com.example.pdftools.ui.accent
import com.example.pdftools.ui.components.AppCard
import com.example.pdftools.ui.components.BottomActionBar
import com.example.pdftools.ui.components.MessageEffect
import com.example.pdftools.ui.components.PasswordField
import com.example.pdftools.ui.components.PickFileCard
import com.example.pdftools.ui.components.ResultSheet
import com.example.pdftools.ui.components.SourceFileCard
import com.example.pdftools.ui.components.ToolScaffold
import com.example.pdftools.ui.components.WorkingCard
import com.example.pdftools.util.asString

@Composable
fun ToolScreen(
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: ToolViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val tool = state.tool
    val snackbarHostState = remember { SnackbarHostState() }
    MessageEffect(state.message, snackbarHostState, viewModel::messageShown)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.load(uri)
    }
    val pick: () -> Unit = { picker.launch(arrayOf("application/pdf")) }
    val source = state.source

    ToolScaffold(
        title = stringResource(tool.title),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
        bottomBar = {
            if (source != null) {
                BottomActionBar {
                    Button(
                        onClick = viewModel::execute,
                        enabled = viewModel.canRun(state),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 14.dp),
                    ) {
                        Icon(tool.icon, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(actionLabel(tool)))
                    }
                }
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (state.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

            if (source == null) {
                if (!state.loading) {
                    PickFileCard(
                        icon = tool.icon,
                        title = stringResource(tool.title),
                        description = stringResource(tool.description),
                        buttonText = stringResource(R.string.action_choose_pdf),
                        onPick = pick,
                        accent = tool.category.accent(),
                    )
                }
            } else {
                SourceFileCard(source = source, onChange = if (state.working) null else pick)
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        when (tool) {
                            Tool.COMPRESS -> CompressOptions(state, viewModel)
                            Tool.PROTECT -> ProtectOptions(state, viewModel)
                            Tool.UNLOCK -> UnlockOptions(state, viewModel)
                            Tool.PAGE_NUMBERS -> NumberOptions(state, viewModel)
                            else -> WatermarkOptions(state, viewModel)
                        }
                    }
                }
            }

            if (state.working) WorkingCard(progress = if (tool == Tool.PROTECT || tool == Tool.UNLOCK) null else state.progress)
        }
    }

    state.result?.let { result ->
        ResultSheet(
            result = result,
            onDismiss = viewModel::clearResult,
            onOpenPdf = { onOpenPdf(it.uri) },
            onContinue = { next, file -> onNavigate(next.route(file.uri.toString())) },
            exclude = tool,
        )
    }
}

@StringRes
private fun actionLabel(tool: Tool): Int = when (tool) {
    Tool.COMPRESS -> R.string.action_compress
    Tool.PROTECT -> R.string.action_protect
    Tool.UNLOCK -> R.string.action_unlock
    Tool.PAGE_NUMBERS -> R.string.action_add_numbers
    else -> R.string.action_add_watermark
}

@Composable
private fun SectionLabel(@StringRes text: Int) {
    Text(stringResource(text), style = MaterialTheme.typography.titleSmall)
}

@Composable
private fun Choice(selected: Boolean, label: String, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        leadingIcon = if (selected) {
            { Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
        } else {
            null
        },
    )
}

@Composable
private fun SwitchRow(@StringRes label: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(label), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun Hint(@StringRes text: Int) {
    Text(
        stringResource(text),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun CompressOptions(state: ToolUiState, viewModel: ToolViewModel) {
    SectionLabel(R.string.compress_level)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Choice(state.compressLevel == PdfRepository.CompressLevel.LIGHT, stringResource(R.string.compress_light)) {
            viewModel.setCompressLevel(PdfRepository.CompressLevel.LIGHT)
        }
        Choice(state.compressLevel == PdfRepository.CompressLevel.MEDIUM, stringResource(R.string.compress_medium)) {
            viewModel.setCompressLevel(PdfRepository.CompressLevel.MEDIUM)
        }
        Choice(state.compressLevel == PdfRepository.CompressLevel.STRONG, stringResource(R.string.compress_strong)) {
            viewModel.setCompressLevel(PdfRepository.CompressLevel.STRONG)
        }
    }
    Hint(R.string.compress_hint)
}

@Composable
private fun ProtectOptions(state: ToolUiState, viewModel: ToolViewModel) {
    PasswordField(
        value = state.password,
        onValueChange = viewModel::setPassword,
        label = stringResource(R.string.password_new),
    )
    PasswordField(
        value = state.confirm,
        onValueChange = viewModel::setConfirm,
        label = stringResource(R.string.password_confirm),
        isError = state.passwordError != null,
        supportingText = state.passwordError?.asString(),
        onDone = viewModel::execute,
    )
    Hint(R.string.protect_hint)
}

@Composable
private fun UnlockOptions(state: ToolUiState, viewModel: ToolViewModel) {
    val source = state.source ?: return
    if (source.locked) {
        PasswordField(
            value = state.password,
            onValueChange = viewModel::setPassword,
            label = stringResource(R.string.password_label),
            onDone = viewModel::execute,
        )
        Hint(R.string.unlock_hint)
    } else {
        Hint(R.string.unlock_not_locked)
    }
}

@Composable
private fun NumberOptions(state: ToolUiState, viewModel: ToolViewModel) {
    SectionLabel(R.string.numbers_position)
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        val options = listOf(
            PdfRepository.NumberPosition.BOTTOM_CENTER to R.string.numbers_bottom_center,
            PdfRepository.NumberPosition.BOTTOM_RIGHT to R.string.numbers_bottom_right,
            PdfRepository.NumberPosition.BOTTOM_LEFT to R.string.numbers_bottom_left,
            PdfRepository.NumberPosition.TOP_RIGHT to R.string.numbers_top_right,
        )
        options.forEach { (position, label) ->
            Choice(state.numberPosition == position, stringResource(label)) { viewModel.setNumberPosition(position) }
        }
    }
    SwitchRow(R.string.numbers_with_total, state.numberWithTotal, viewModel::setNumberWithTotal)
    Text(
        if (state.numberWithTotal) "3 / 12" else "3",
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun WatermarkOptions(state: ToolUiState, viewModel: ToolViewModel) {
    OutlinedTextField(
        value = state.watermarkText,
        onValueChange = viewModel::setWatermarkText,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(stringResource(R.string.watermark_text)) },
        placeholder = { Text(stringResource(R.string.watermark_placeholder)) },
        shape = MaterialTheme.shapes.medium,
    )
    SectionLabel(R.string.watermark_color)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        WatermarkColors.forEach { argb ->
            val selected = argb == state.watermarkColor
            Box(
                modifier = Modifier
                    .size(if (selected) 38.dp else 32.dp)
                    .clip(CircleShape)
                    .background(Color(argb))
                    .border(if (selected) 3.dp else 0.dp, MaterialTheme.colorScheme.primary, CircleShape)
                    .clickable { viewModel.setWatermarkColor(argb) },
            )
        }
    }
    SectionLabel(R.string.watermark_opacity)
    Slider(value = state.watermarkOpacity, onValueChange = viewModel::setWatermarkOpacity, valueRange = 0.1f..0.8f)
    SwitchRow(R.string.watermark_diagonal, state.watermarkDiagonal, viewModel::setWatermarkDiagonal)

    // Live preview
    if (state.watermarkText.isNotBlank()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(90.dp)
                .clip(MaterialTheme.shapes.medium)
                .background(Color.White)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, MaterialTheme.shapes.medium),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                state.watermarkText,
                color = Color(state.watermarkColor).copy(alpha = state.watermarkOpacity),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
        }
    }
}
