package com.example.pdftools.navigation

import android.net.Uri

object Routes {
    const val ARG_URI = "uri"
    const val ARG_TAB = "tab"
    const val ARG_CAMERA = "camera"
    const val ARG_OCR = "ocr"
    const val ARG_KIND = "kind"

    const val HOME = "home"
    const val VIEWER = "viewer?uri={uri}"
    const val MERGE = "merge"
    const val SPLIT = "split?uri={uri}"
    const val PAGES = "pages?uri={uri}"
    const val SIGN = "sign?uri={uri}"
    const val ANNOTATE = "annotate?uri={uri}"
    const val FORMS = "forms?uri={uri}"
    const val CONVERT = "convert?tab={tab}&camera={camera}&ocr={ocr}&uri={uri}"
    const val TOOL = "tool/{kind}?uri={uri}"
    const val ABOUT = "about"

    /** Tabs of the convert screen. */
    const val TAB_IMAGES_TO_PDF = 0
    const val TAB_PDF_TO_IMAGES = 1
    const val TAB_PDF_TO_TEXT = 2

    fun viewer(uri: String): String = "viewer?uri=${Uri.encode(uri)}"
    fun split(uri: String?): String = withUri("split", uri)
    fun pages(uri: String?): String = withUri("pages", uri)
    fun sign(uri: String?): String = withUri("sign", uri)
    fun annotate(uri: String?): String = withUri("annotate", uri)
    fun forms(uri: String?): String = withUri("forms", uri)

    /** Generic single-file tools (compress, protect, unlock, page numbers, watermark). */
    fun tool(kind: String, uri: String?): String = withUri("tool/$kind", uri)

    fun convert(tab: Int, uri: String? = null, camera: Boolean = false, ocr: Boolean = false): String {
        val base = "convert?tab=$tab&camera=$camera&ocr=$ocr"
        return if (uri == null) base else "$base&uri=${Uri.encode(uri)}"
    }

    private fun withUri(base: String, uri: String?): String =
        if (uri == null) base else "$base?uri=${Uri.encode(uri)}"
}
