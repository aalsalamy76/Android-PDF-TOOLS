package com.example.pdftools.navigation

import android.net.Uri

object Routes {
    const val ARG_URI = "uri"
    const val ARG_TAB = "tab"

    const val HOME = "home"
    const val VIEWER = "viewer?uri={uri}"
    const val MERGE = "merge"
    const val SPLIT = "split?uri={uri}"
    const val PAGES = "pages?uri={uri}"
    const val SIGN = "sign?uri={uri}"
    const val CONVERT = "convert?tab={tab}&uri={uri}"
    const val ABOUT = "about"

    /** Tabs of the convert screen. */
    const val TAB_IMAGES_TO_PDF = 0
    const val TAB_PDF_TO_IMAGES = 1
    const val TAB_PDF_TO_TEXT = 2

    fun viewer(uri: String): String = "viewer?uri=${Uri.encode(uri)}"
    fun split(uri: String?): String = withUri("split", uri)
    fun pages(uri: String?): String = withUri("pages", uri)
    fun sign(uri: String?): String = withUri("sign", uri)

    fun convert(tab: Int, uri: String? = null): String =
        if (uri == null) "convert?tab=$tab" else "convert?tab=$tab&uri=${Uri.encode(uri)}"

    private fun withUri(base: String, uri: String?): String =
        if (uri == null) base else "$base?uri=${Uri.encode(uri)}"
}
