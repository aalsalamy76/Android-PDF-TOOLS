package com.example.pdftools.data

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.example.pdftools.R
import com.example.pdftools.util.AppException
import com.example.pdftools.util.uiText
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

const val MIME_PDF = "application/pdf"
const val MIME_PNG = "image/png"
const val MIME_JPEG = "image/jpeg"
const val MIME_TEXT = "text/plain"

/** Public folder used for every result: Download/PdfTools */
val OUTPUT_FOLDER: String = Environment.DIRECTORY_DOWNLOADS + "/PdfTools"

/** A generated file: private copy (for sharing) + its public copy in Downloads. */
data class OutputFile(val file: File, val uri: Uri, val mime: String) {
    val name: String get() = file.name
}

data class OperationResult(val files: List<OutputFile>) {
    val mime: String
        get() = files.map { it.mime }.distinct().singleOrNull() ?: "*/*"
}

/**
 * File plumbing: reading SAF documents into the private cache,
 * creating output files and publishing them to Downloads/PdfTools via MediaStore.
 * All functions are blocking and must be called from Dispatchers.IO.
 */
class FileRepository(private val context: Context) {

    data class FileInfo(val name: String, val size: Long)

    private val workDir: File get() = File(context.cacheDir, WORK_DIR).apply { mkdirs() }
    private val outputDir: File get() = File(context.cacheDir, OUTPUT_DIR).apply { mkdirs() }

    fun queryInfo(uri: Uri): FileInfo {
        var name: String? = null
        var size = -1L
        try {
            context.contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null, null, null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (nameIndex >= 0 && !cursor.isNull(nameIndex)) name = cursor.getString(nameIndex)
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (_: Exception) {
            // Some providers do not support queries; fall back to the URI.
        }
        val finalName = name?.takeIf { it.isNotBlank() }
            ?: uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.isNotBlank() }
            ?: "document.pdf"
        return FileInfo(finalName, size)
    }

    /** Copies a document into a private cache file (PdfRenderer and PdfBox need a real file). */
    fun copyToCache(uri: Uri, displayName: String): File {
        val dir = File(workDir, UUID.randomUUID().toString()).apply { mkdirs() }
        val target = File(dir, sanitizeFileName(displayName))
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw FileNotFoundException(uri.toString())
            input.use { source ->
                target.outputStream().use { sink -> source.copyTo(sink, BUFFER_SIZE) }
            }
        } catch (e: SecurityException) {
            dir.deleteRecursively()
            throw AppException(uiText(R.string.error_access_denied), e)
        } catch (e: FileNotFoundException) {
            dir.deleteRecursively()
            throw AppException(uiText(R.string.error_file_not_found), e)
        } catch (e: IOException) {
            dir.deleteRecursively()
            throw AppException(uiText(R.string.error_read_failed), e)
        }
        if (target.length() == 0L) {
            dir.deleteRecursively()
            throw AppException(uiText(R.string.error_empty_file))
        }
        return target
    }

    /** A new private file whose name is the final, user visible name. */
    fun newOutputFile(displayName: String): File {
        val dir = File(outputDir, UUID.randomUUID().toString().take(8)).apply { mkdirs() }
        return File(dir, sanitizeFileName(displayName))
    }

    /** Saves a copy of [file] to Download/PdfTools (MediaStore, no permission needed). */
    fun saveToDownloads(file: File, mime: String): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, OUTPUT_FOLDER)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = resolver.insert(collection, values)
            ?: throw AppException(uiText(R.string.error_save_failed))
        try {
            val output = resolver.openOutputStream(uri)
                ?: throw AppException(uiText(R.string.error_save_failed))
            output.use { sink -> file.inputStream().use { it.copyTo(sink, BUFFER_SIZE) } }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            try {
                resolver.delete(uri, null, null)
            } catch (_: Exception) {
            }
            if (e is AppException) throw e
            throw AppException(uiText(R.string.error_save_failed), e)
        }
        return uri
    }

    /** Publishes every file to Downloads/PdfTools and returns the result for the UI. */
    fun publish(files: List<File>, mime: String): OperationResult =
        OperationResult(files.map { OutputFile(it, saveToDownloads(it, mime), mime) })

    /** Removes temporary files left by previous sessions. */
    fun cleanOldCache(maxAgeMillis: Long = TimeUnit.HOURS.toMillis(12)) {
        val limit = System.currentTimeMillis() - maxAgeMillis
        listOf(File(context.cacheDir, WORK_DIR), File(context.cacheDir, OUTPUT_DIR)).forEach { root ->
            root.listFiles()?.forEach { child ->
                if (child.lastModified() < limit) child.deleteRecursively()
            }
        }
    }

    private companion object {
        const val WORK_DIR = "work"
        const val OUTPUT_DIR = "outputs"
        const val BUFFER_SIZE = 64 * 1024
    }
}

fun sanitizeFileName(name: String): String {
    val cleaned = name.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().trim('.')
    return cleaned.ifBlank { "file" }.take(120)
}

/** "My report.pdf" -> "My report" */
fun baseNameOf(name: String): String =
    sanitizeFileName(name.substringBeforeLast('.', name)).take(60)

fun timestamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
