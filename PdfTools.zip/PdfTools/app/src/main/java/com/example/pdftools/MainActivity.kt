package com.example.pdftools

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.pdftools.navigation.AppNavHost
import com.example.pdftools.ui.theme.PdfToolsTheme

/**
 * AppCompatActivity (instead of ComponentActivity) so that
 * AppCompatDelegate can switch the app language and the light/dark mode on Android 10–12.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val initialPdf: Uri? = intent?.takeIf { it.action == Intent.ACTION_VIEW }?.data
        setContent {
            PdfToolsTheme {
                AppNavHost(initialPdf = initialPdf)
            }
        }
    }
}
