@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.pdftools.ui.screens.viewer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.PdfQuickInfo
import com.example.pdftools.ui.components.ErrorState
import com.example.pdftools.ui.components.GoToPageDialog
import com.example.pdftools.ui.components.PageThumbnail
import com.example.pdftools.ui.components.PasswordField
import com.example.pdftools.ui.components.PdfActionSheet
import com.example.pdftools.ui.components.ZoomablePdfPage
import com.example.pdftools.ui.theme.ViewerBackdropDark
import com.example.pdftools.ui.theme.ViewerBackdropLight
import com.example.pdftools.util.Intents
import com.example.pdftools.util.asString
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Immersive reader: tap a page to hide / show the bars, pinch to zoom,
 * swipe the bottom bar up (or tap "Tools") to open the tools sheet.
 */
@Composable
fun ViewerScreen(
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: ViewerViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(pageCount = { state.pageCount })
    val uri = viewModel.uriString

    var barsVisible by rememberSaveable { mutableStateOf(true) }
    var vertical by rememberSaveable { mutableStateOf(false) }
    var night by rememberSaveable { mutableStateOf(false) }
    var toolsOpen by remember { mutableStateOf(false) }
    var pagesOpen by remember { mutableStateOf(false) }
    var goToOpen by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    val backdrop = if (isSystemInDarkTheme() || night) ViewerBackdropDark else ViewerBackdropLight

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backdrop),
    ) {
        val error = state.error
        when {
            state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
            error != null -> Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                ErrorState(message = error, onRetry = viewModel::load)
            }
            state.needsPassword -> Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                PasswordPrompt(
                    fileName = state.fileName,
                    busy = state.unlocking,
                    error = state.passwordError?.asString(),
                    onSubmit = viewModel::submitPassword,
                )
            }
            else -> PdfPager(
                pagerState = pagerState,
                vertical = vertical,
                night = night,
                loader = viewModel::renderPage,
                onTap = { barsVisible = !barsVisible },
            )
        }

        // ---------------- top bar
        AnimatedVisibility(
            visible = barsVisible || !state.ready,
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it },
            modifier = Modifier.align(Alignment.TopCenter),
        ) {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            state.fileName.ifEmpty { stringResource(R.string.viewer_title) },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium,
                        )
                        if (state.ready) {
                            Text(
                                stringResource(R.string.pages_count, state.pageCount),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    val file = viewModel.sourceFile
                    if (state.ready && file != null) {
                        IconButton(onClick = { Intents.shareFiles(context, listOf(file), MIME_PDF) }) {
                            Icon(Icons.Filled.Share, contentDescription = stringResource(R.string.action_share))
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.menu_more))
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                MenuEntry(Icons.Filled.GridView, stringResource(R.string.viewer_all_pages)) {
                                    menuOpen = false; pagesOpen = true
                                }
                                MenuEntry(
                                    if (vertical) Icons.Filled.SwapHoriz else Icons.Filled.SwapVert,
                                    stringResource(if (vertical) R.string.viewer_mode_horizontal else R.string.viewer_mode_vertical),
                                ) {
                                    menuOpen = false; vertical = !vertical
                                }
                                MenuEntry(
                                    if (night) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                                    stringResource(if (night) R.string.viewer_night_off else R.string.viewer_night_on),
                                ) {
                                    menuOpen = false; night = !night
                                }
                                MenuEntry(Icons.Filled.Apps, stringResource(R.string.action_open_with)) {
                                    menuOpen = false; Intents.openWith(context, file, MIME_PDF)
                                }
                                MenuEntry(Icons.Filled.Print, stringResource(R.string.action_print)) {
                                    menuOpen = false; Intents.print(context, file, state.fileName)
                                }
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                ),
            )
        }

        // ---------------- bottom bar (swipe up for tools)
        AnimatedVisibility(
            visible = barsVisible && state.ready,
            enter = fadeIn() + slideInVertically { it },
            exit = fadeOut() + slideOutVertically { it },
            modifier = Modifier.align(Alignment.BottomCenter),
        ) {
            ViewerBottomBar(
                currentPage = pagerState.currentPage,
                pageCount = state.pageCount,
                onPages = { pagesOpen = true },
                onGoTo = { goToOpen = true },
                onSeek = { page -> scope.launch { pagerState.scrollToPage(page) } },
                onTools = { toolsOpen = true },
            )
        }
    }

    if (toolsOpen && uri != null) {
        PdfActionSheet(
            name = state.fileName,
            info = PdfQuickInfo(
                uri = android.net.Uri.parse(uri),
                name = state.fileName,
                size = state.fileSize,
                pageCount = state.pageCount,
                locked = state.wasLocked,
            ),
            onDismiss = { toolsOpen = false },
            onOpen = null,
            onTool = { tool -> onNavigate(tool.route(uri)) },
        )
    }

    if (pagesOpen) {
        PagesSheet(
            pageCount = state.pageCount,
            current = pagerState.currentPage,
            loader = viewModel::renderPage,
            onDismiss = { pagesOpen = false },
            onSelect = { page ->
                pagesOpen = false
                scope.launch { pagerState.scrollToPage(page) }
            },
        )
    }

    if (goToOpen) {
        GoToPageDialog(
            pageCount = state.pageCount,
            onDismiss = { goToOpen = false },
            onGo = { page -> scope.launch { pagerState.scrollToPage(page) } },
        )
    }
}

@Composable
private fun PdfPager(
    pagerState: PagerState,
    vertical: Boolean,
    night: Boolean,
    loader: suspend (Int, Int) -> android.graphics.Bitmap?,
    onTap: () -> Unit,
) {
    if (vertical) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            key = { it },
        ) { page ->
            ZoomablePdfPage(pageIndex = page, loader = loader, onTap = onTap, invertColors = night)
        }
    } else {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            key = { it },
        ) { page ->
            ZoomablePdfPage(pageIndex = page, loader = loader, onTap = onTap, invertColors = night)
        }
    }
}

@Composable
private fun ViewerBottomBar(
    currentPage: Int,
    pageCount: Int,
    onPages: () -> Unit,
    onGoTo: () -> Unit,
    onSeek: (Int) -> Unit,
    onTools: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.97f),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        shadowElevation = 12.dp,
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -SWIPE_UP_THRESHOLD) onTools() },
                ) { change, amount ->
                    total += amount
                    change.consume()
                }
            },
    ) {
        Column(
            modifier = Modifier
                .navigationBarsPadding()
                .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Handle: tap or drag up to open the tools
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(onClick = onTools)
                    .padding(horizontal = 24.dp, vertical = 6.dp),
            ) {
                Box(
                    Modifier
                        .width(40.dp)
                        .height(5.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.6f)),
                )
            }
            Text(
                stringResource(R.string.viewer_swipe_hint),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onPages) {
                    Icon(Icons.Filled.GridView, contentDescription = stringResource(R.string.viewer_all_pages))
                }
                if (pageCount > 1) {
                    Slider(
                        value = currentPage.toFloat(),
                        onValueChange = { onSeek(it.roundToInt()) },
                        valueRange = 0f..(pageCount - 1).toFloat(),
                        modifier = Modifier.weight(1f),
                    )
                } else {
                    Spacer(Modifier.weight(1f))
                }
                TextButton(onClick = onGoTo, modifier = Modifier.widthIn(min = 72.dp)) {
                    Text(
                        stringResource(R.string.page_x_of_y, currentPage + 1, pageCount),
                        style = MaterialTheme.typography.titleSmall,
                    )
                }
                FilledTonalButton(onClick = onTools, contentPadding = PaddingValues(horizontal = 14.dp)) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.viewer_tools))
                }
            }
        }
    }
}

/** Grid of all pages, in a sheet that slides up from the bottom. */
@Composable
private fun PagesSheet(
    pageCount: Int,
    current: Int,
    loader: suspend (Int, Int) -> android.graphics.Bitmap?,
    onDismiss: () -> Unit,
    onSelect: (Int) -> Unit,
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false),
        containerColor = MaterialTheme.colorScheme.surface,
    ) {
        Text(
            stringResource(R.string.viewer_all_pages),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 104.dp),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 32.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            items(count = pageCount, key = { it }) { page ->
                val selected = page == current
                Column(
                    modifier = Modifier
                        .clip(MaterialTheme.shapes.medium)
                        .background(
                            if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                        )
                        .clickable { onSelect(page) }
                        .padding(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    PageThumbnail(pageIndex = page, widthPx = 260, loader = loader, modifier = Modifier.fillMaxWidth())
                    Text(
                        "${page + 1}",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun PasswordPrompt(
    fileName: String,
    busy: Boolean,
    error: String?,
    onSubmit: (String) -> Unit,
) {
    var password by rememberSaveable { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.password_title), style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(6.dp))
        Text(
            stringResource(R.string.password_desc, fileName),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(20.dp))
        PasswordField(
            value = password,
            onValueChange = { password = it },
            label = stringResource(R.string.password_label),
            isError = error != null,
            supportingText = error,
            onDone = { onSubmit(password) },
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { onSubmit(password) },
            enabled = !busy && password.isNotEmpty(),
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(vertical = 14.dp),
        ) {
            if (busy) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text(stringResource(R.string.action_open))
            }
        }
    }
}

@Composable
private fun MenuEntry(icon: ImageVector, label: String, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(label) },
        leadingIcon = { Icon(icon, contentDescription = null) },
        onClick = onClick,
    )
}

private const val SWIPE_UP_THRESHOLD = 40f
