@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.pdftools.ui.screens.viewer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.navigation.Routes
import com.example.pdftools.ui.components.ErrorState
import com.example.pdftools.ui.components.GoToPageDialog
import com.example.pdftools.ui.components.ZoomablePdfPage
import com.example.pdftools.util.Intents
import kotlinx.coroutines.launch

@Composable
fun ViewerScreen(
    onBack: () -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: ViewerViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var menuOpen by remember { mutableStateOf(false) }
    var goToOpen by remember { mutableStateOf(false) }
    val pagerState = rememberPagerState(pageCount = { state.pageCount })
    val uri = viewModel.uriString

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            state.fileName.ifEmpty { stringResource(R.string.viewer_title) },
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium,
                        )
                        if (state.pageCount > 0) {
                            Text(
                                stringResource(R.string.pages_count, state.pageCount),
                                style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.action_back))
                    }
                },
                actions = {
                    if (state.pageCount > 0 && uri != null) {
                        IconButton(onClick = {
                            viewModel.source?.let { Intents.shareFiles(context, listOf(it.file), MIME_PDF) }
                        }) {
                            Icon(Icons.Filled.Share, contentDescription = stringResource(R.string.action_share))
                        }
                        Box {
                            IconButton(onClick = { menuOpen = true }) {
                                Icon(Icons.Filled.MoreVert, contentDescription = stringResource(R.string.menu_more))
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                MenuEntry(Icons.Filled.GridView, R.string.tool_pages) {
                                    menuOpen = false; onNavigate(Routes.pages(uri))
                                }
                                MenuEntry(Icons.Filled.ContentCut, R.string.tool_split) {
                                    menuOpen = false; onNavigate(Routes.split(uri))
                                }
                                MenuEntry(Icons.Filled.Draw, R.string.tool_sign) {
                                    menuOpen = false; onNavigate(Routes.sign(uri))
                                }
                                MenuEntry(Icons.Filled.PhotoLibrary, R.string.tool_pdf_to_images) {
                                    menuOpen = false; onNavigate(Routes.convert(Routes.TAB_PDF_TO_IMAGES, uri))
                                }
                                MenuEntry(Icons.Filled.Description, R.string.tool_pdf_to_text) {
                                    menuOpen = false; onNavigate(Routes.convert(Routes.TAB_PDF_TO_TEXT, uri))
                                }
                            }
                        }
                    }
                },
            )
        },
        bottomBar = {
            if (state.pageCount > 0) {
                BottomAppBar {
                    IconButton(
                        enabled = pagerState.currentPage > 0,
                        onClick = { scope.launch { pagerState.animateScrollToPage(pagerState.currentPage - 1) } },
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                            contentDescription = stringResource(R.string.action_previous_page),
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { goToOpen = true }) {
                        Text(
                            stringResource(R.string.page_x_of_y, pagerState.currentPage + 1, state.pageCount),
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(
                        enabled = pagerState.currentPage < state.pageCount - 1,
                        onClick = { scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) } },
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = stringResource(R.string.action_next_page),
                        )
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            val error = state.error
            when {
                state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                error != null -> ErrorState(message = error, onRetry = viewModel::load)
                else -> HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize(),
                    key = { it },
                ) { page ->
                    ZoomablePdfPage(pageIndex = page, loader = viewModel::renderPage)
                }
            }
        }
    }

    if (goToOpen) {
        GoToPageDialog(
            pageCount = state.pageCount,
            onDismiss = { goToOpen = false },
            onGo = { page -> scope.launch { pagerState.scrollToPage(page) } },
        )
    }
}

@Composable
private fun MenuEntry(icon: ImageVector, label: Int, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(stringResource(label)) },
        leadingIcon = { Icon(icon, contentDescription = null) },
        onClick = onClick,
    )
}
