package com.example.pdftools.data

import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import com.example.pdftools.PdfToolsApp
import java.io.File

/** A PDF chosen by the user, copied to the private cache and validated. */
data class SourcePdf(
    val uri: Uri,
    val file: File,
    val name: String,
    val size: Long,
    val pageCount: Int,
    /** True when the file needs a password (only possible with allowLocked = true). */
    val locked: Boolean = false,
)

/** Very small manual dependency container (no DI library needed). */
class AppContainer(context: Context) {

    private val appContext: Context = context.applicationContext

    val settings = SettingsRepository(appContext)
    val recents = RecentFilesRepository(appContext)
    val files = FileRepository(appContext)
    val pdf = PdfRepository(appContext)
    val thumbnails = ThumbnailRepository(appContext)
    val ocr = OcrRepository()

    /**
     * Copies the document into the cache, checks that it is a readable PDF and,
     * when [rememberInRecents] is true, adds it to the recent files list.
     * Password protected files fail, unless [allowLocked] is true (then [SourcePdf.locked] is set).
     * Blocking – call from Dispatchers.IO.
     */
    fun openSource(uri: Uri, rememberInRecents: Boolean = true, allowLocked: Boolean = false): SourcePdf {
        val info = files.queryInfo(uri)
        val file = files.copyToCache(uri, info.name)
        var locked = false
        val pages = try {
            pdf.pageCount(file)
        } catch (e: SecurityException) {
            if (!allowLocked) throw e
            locked = true
            0
        }
        if (rememberInRecents) {
            recents.takePersistablePermission(uri)
            recents.add(uri, info.name, if (info.size >= 0) info.size else file.length())
        }
        return SourcePdf(
            uri = uri,
            file = file,
            name = info.name,
            size = if (info.size >= 0) info.size else file.length(),
            pageCount = pages,
            locked = locked,
        )
    }
}

/** Access to the container from any AndroidViewModel. */
val AndroidViewModel.container: AppContainer
    get() = getApplication<PdfToolsApp>().container
