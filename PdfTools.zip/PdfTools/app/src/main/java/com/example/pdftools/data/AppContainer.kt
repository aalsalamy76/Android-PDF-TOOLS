package com.example.pdftools.data

import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import com.example.pdftools.PdfToolsApp
import java.io.File

/** A PDF chosen by the user, copied to the private cache and validated. */
data class SourcePdf(
    val uri: Uri,
    val file: File,
    val name: String,
    val size: Long,
    val pageCount: Int,
)

/** Very small manual dependency container (no DI library needed). */
class AppContainer(context: Context) {

    private val appContext: Context = context.applicationContext

    val settings = SettingsRepository(appContext)
    val recents = RecentFilesRepository(appContext)
    val files = FileRepository(appContext)
    val pdf = PdfRepository(appContext)

    /**
     * Copies the document into the cache, checks that it is a readable PDF and,
     * when [rememberInRecents] is true, adds it to the recent files list.
     * Blocking – call from Dispatchers.IO.
     */
    fun openSource(uri: Uri, rememberInRecents: Boolean = true): SourcePdf {
        val info = files.queryInfo(uri)
        val file = files.copyToCache(uri, info.name)
        val pages = pdf.pageCount(file)
        if (rememberInRecents) {
            recents.takePersistablePermission(uri)
            recents.add(uri, info.name, if (info.size >= 0) info.size else file.length())
        }
        return SourcePdf(
            uri = uri,
            file = file,
            name = info.name,
            size = if (info.size >= 0) info.size else file.length(),
            pageCount = pages,
        )
    }
}

/** Access to the container from any AndroidViewModel. */
val AndroidViewModel.container: AppContainer
    get() = getApplication<PdfToolsApp>().container
