@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.pdftools.ui.screens.forms

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.data.FormField
import com.example.pdftools.data.FormFieldKind
import com.example.pdftools.ui.Tool
import com.example.pdftools.ui.accent
import com.example.pdftools.ui.components.AppCard
import com.example.pdftools.ui.components.BottomActionBar
import com.example.pdftools.ui.components.MessageEffect
import com.example.pdftools.ui.components.PickFileCard
import com.example.pdftools.ui.components.ResultSheet
import com.example.pdftools.ui.components.SourceFileCard
import com.example.pdftools.ui.components.ToolScaffold
import com.example.pdftools.ui.components.WorkingCard

@Composable
fun FormsScreen(
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: FormsViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    MessageEffect(state.message, snackbarHostState, viewModel::messageShown)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.load(uri)
    }
    val pick: () -> Unit = { picker.launch(arrayOf("application/pdf")) }
    val source = state.source

    ToolScaffold(
        title = stringResource(R.string.tool_forms),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
        bottomBar = {
            if (source != null && state.fields.isNotEmpty()) {
                BottomActionBar {
                    Button(
                        onClick = viewModel::save,
                        enabled = !state.working,
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 14.dp),
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(stringResource(R.string.action_save))
                    }
                }
            }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (state.loading) item(key = "loading") { LinearProgressIndicator(Modifier.fillMaxWidth()) }

            if (source == null) {
                if (!state.loading) {
                    item(key = "pick") {
                        PickFileCard(
                            icon = Tool.FORMS.icon,
                            title = stringResource(R.string.tool_forms),
                            description = stringResource(R.string.forms_empty_desc),
                            buttonText = stringResource(R.string.action_choose_pdf),
                            onPick = pick,
                            accent = Tool.FORMS.category.accent(),
                        )
                    }
                }
            } else {
                item(key = "source") { SourceFileCard(source = source, onChange = if (state.working) null else pick) }

                if (state.fields.isEmpty() && !state.loading) {
                    item(key = "none") {
                        AppCard(Modifier.fillMaxWidth()) {
                            Text(
                                stringResource(R.string.forms_none),
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(18.dp),
                            )
                        }
                    }
                } else {
                    item(key = "count") {
                        Text(
                            stringResource(R.string.forms_count, state.fields.size),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    items(state.fields, key = { it.key }) { field ->
                        FieldEditor(
                            field = field,
                            value = state.values[field.key] ?: field.value,
                            enabled = !state.working && !field.readOnly,
                            onChange = { viewModel.setValue(field.key, it) },
                        )
                    }
                    item(key = "flatten") {
                        AppCard(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(stringResource(R.string.forms_flatten), style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        stringResource(R.string.forms_flatten_desc),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                Switch(checked = state.flatten, onCheckedChange = viewModel::setFlatten)
                            }
                        }
                    }
                }
            }

            if (state.working) item(key = "working") { WorkingCard(progress = null) }
        }
    }

    state.result?.let { result ->
        ResultSheet(
            result = result,
            onDismiss = viewModel::clearResult,
            onOpenPdf = { onOpenPdf(it.uri) },
            onContinue = { tool, file -> onNavigate(tool.route(file.uri.toString())) },
            exclude = Tool.FORMS,
        )
    }
}

@Composable
private fun FieldEditor(field: FormField, value: String, enabled: Boolean, onChange: (String) -> Unit) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            when (field.kind) {
                FormFieldKind.TEXT -> OutlinedTextField(
                    value = value,
                    onValueChange = onChange,
                    enabled = enabled,
                    label = { Text(field.label) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.medium,
                )

                FormFieldKind.CHECKBOX -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = value == "true",
                        onCheckedChange = { onChange(if (it) "true" else "false") },
                        enabled = enabled,
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(field.label, style = MaterialTheme.typography.bodyLarge)
                }

                FormFieldKind.RADIO, FormFieldKind.CHOICE -> {
                    Text(field.label, style = MaterialTheme.typography.titleSmall)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        field.options.forEach { option ->
                            val selected = option == value
                            FilterChip(
                                selected = selected,
                                onClick = { onChange(option) },
                                enabled = enabled,
                                label = { Text(option) },
                                leadingIcon = if (selected) {
                                    { Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
                                } else {
                                    null
                                },
                            )
                        }
                    }
                }
            }
            if (field.readOnly) {
                Text(
                    stringResource(R.string.forms_read_only),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
