@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.pdftools.ui.screens.convert

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.data.PdfRepository
import com.example.pdftools.navigation.Routes
import com.example.pdftools.ui.components.BottomActionBar
import com.example.pdftools.ui.components.MessageEffect
import com.example.pdftools.ui.components.PickFileCard
import com.example.pdftools.ui.components.ResultCard
import com.example.pdftools.ui.components.SourceFileCard
import com.example.pdftools.ui.components.ToolScaffold
import com.example.pdftools.ui.components.WorkingCard
import com.example.pdftools.util.asString

@Composable
fun ConvertScreen(
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    viewModel: ConvertViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    MessageEffect(state.message, snackbarHostState, viewModel::messageShown)

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        viewModel.addImages(uris)
    }
    val pdfPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.loadPdf(uri)
    }
    val pickImages: () -> Unit = { imagePicker.launch(arrayOf("image/*")) }
    val pickPdf: () -> Unit = { pdfPicker.launch(arrayOf("application/pdf")) }

    val tabs = listOf(
        R.string.tab_images_to_pdf,
        R.string.tab_pdf_to_images,
        R.string.tab_pdf_to_text,
    )

    ToolScaffold(
        title = stringResource(R.string.tool_convert),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
        bottomBar = {
            val enabled = !state.working && !state.loading
            when (state.tab) {
                Routes.TAB_IMAGES_TO_PDF -> if (state.images.isNotEmpty()) {
                    BottomActionBar {
                        OutlinedButton(onClick = pickImages, enabled = enabled) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.action_add))
                        }
                        Button(
                            onClick = viewModel::convertImagesToPdf,
                            enabled = enabled,
                            modifier = Modifier.weight(1f),
                        ) { Text(stringResource(R.string.action_create_pdf)) }
                    }
                }

                Routes.TAB_PDF_TO_IMAGES -> if (state.source != null) {
                    BottomActionBar {
                        Button(
                            onClick = viewModel::convertPdfToImages,
                            enabled = enabled,
                            modifier = Modifier.weight(1f),
                        ) { Text(stringResource(R.string.action_convert)) }
                    }
                }

                else -> if (state.source != null) {
                    BottomActionBar {
                        Button(
                            onClick = viewModel::extractText,
                            enabled = enabled,
                            modifier = Modifier.weight(1f),
                        ) { Text(stringResource(R.string.action_extract_text)) }
                    }
                }
            }
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            TabRow(selectedTabIndex = state.tab) {
                tabs.forEachIndexed { index, label ->
                    Tab(
                        selected = state.tab == index,
                        onClick = { viewModel.selectTab(index) },
                        enabled = !state.working,
                        text = { Text(stringResource(label), maxLines = 2, overflow = TextOverflow.Ellipsis) },
                    )
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                if (state.loading) LinearProgressIndicator(Modifier.fillMaxWidth())

                when (state.tab) {
                    Routes.TAB_IMAGES_TO_PDF -> ImagesToPdfContent(state, viewModel, pickImages)
                    Routes.TAB_PDF_TO_IMAGES -> PdfToImagesContent(state, viewModel, pickPdf)
                    else -> PdfToTextContent(state, viewModel, pickPdf)
                }

                if (state.working) WorkingCard(progress = state.progress)

                state.result?.let { result ->
                    ResultCard(
                        result = result,
                        onOpenPdf = { onOpenPdf(it.uri) },
                        onDismiss = viewModel::clearResult,
                    )
                }
            }
        }
    }
}

@Composable
private fun ImagesToPdfContent(state: ConvertUiState, viewModel: ConvertViewModel, pickImages: () -> Unit) {
    if (state.images.isEmpty()) {
        if (!state.loading) {
            PickFileCard(
                icon = Icons.Filled.Collections,
                title = stringResource(R.string.images_empty_title),
                description = stringResource(R.string.images_empty_desc),
                buttonText = stringResource(R.string.action_choose_images),
                onPick = pickImages,
            )
        }
        return
    }

    Text(stringResource(R.string.page_size_title), style = MaterialTheme.typography.titleSmall)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ChoiceChip(
            selected = state.pageSizeMode == PdfRepository.PageSizeMode.A4,
            label = stringResource(R.string.page_size_a4),
            onClick = { viewModel.setPageSizeMode(PdfRepository.PageSizeMode.A4) },
        )
        ChoiceChip(
            selected = state.pageSizeMode == PdfRepository.PageSizeMode.FIT_IMAGE,
            label = stringResource(R.string.page_size_fit),
            onClick = { viewModel.setPageSizeMode(PdfRepository.PageSizeMode.FIT_IMAGE) },
        )
    }

    Text(
        stringResource(R.string.images_count, state.images.size),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    state.images.forEachIndexed { index, item ->
        OutlinedCard(Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center,
                ) {
                    val thumb = item.thumbnail
                    if (thumb != null) {
                        val image = remember(thumb) { thumb.asImageBitmap() }
                        Image(image, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    } else {
                        Icon(Icons.Filled.Image, contentDescription = null)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    "${index + 1}. ${item.name}",
                    modifier = Modifier.weight(1f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium,
                )
                IconButton(onClick = { viewModel.moveImage(index, -1) }, enabled = index > 0 && !state.working) {
                    Icon(Icons.Filled.KeyboardArrowUp, stringResource(R.string.action_move_up))
                }
                IconButton(
                    onClick = { viewModel.moveImage(index, 1) },
                    enabled = index < state.images.lastIndex && !state.working,
                ) {
                    Icon(Icons.Filled.KeyboardArrowDown, stringResource(R.string.action_move_down))
                }
                IconButton(onClick = { viewModel.removeImage(item.id) }, enabled = !state.working) {
                    Icon(Icons.Filled.Close, stringResource(R.string.action_remove))
                }
            }
        }
    }
}

@Composable
private fun PdfToImagesContent(state: ConvertUiState, viewModel: ConvertViewModel, pickPdf: () -> Unit) {
    val source = state.source
    if (source == null) {
        if (!state.loading) {
            PickFileCard(
                icon = Icons.Filled.PhotoLibrary,
                title = stringResource(R.string.pdf_images_empty_title),
                description = stringResource(R.string.pdf_images_empty_desc),
                buttonText = stringResource(R.string.action_choose_pdf),
                onPick = pickPdf,
            )
        }
        return
    }
    SourceFileCard(source = source, onChange = if (state.working) null else pickPdf)

    Text(stringResource(R.string.image_format_title), style = MaterialTheme.typography.titleSmall)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PdfRepository.ImageFormat.values().forEach { format ->
            ChoiceChip(
                selected = state.imageFormat == format,
                label = format.extension.uppercase(),
                onClick = { viewModel.setImageFormat(format) },
            )
        }
    }

    Text(stringResource(R.string.image_quality_title), style = MaterialTheme.typography.titleSmall)
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ImageQuality.values().forEach { quality ->
            ChoiceChip(
                selected = state.quality == quality,
                label = stringResource(quality.label, quality.dpi),
                onClick = { viewModel.setQuality(quality) },
            )
        }
    }

    OutlinedTextField(
        value = state.ranges,
        onValueChange = viewModel::setRanges,
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        label = { Text(stringResource(R.string.pages_optional_label)) },
        placeholder = { Text(stringResource(R.string.split_ranges_placeholder)) },
        supportingText = {
            val error = state.rangeError
            if (error != null) {
                Text(error.asString())
            } else {
                Text(stringResource(R.string.pages_optional_help, source.pageCount))
            }
        },
        isError = state.rangeError != null,
        keyboardOptions = KeyboardOptions.Default,
    )
}

@Composable
private fun PdfToTextContent(state: ConvertUiState, viewModel: ConvertViewModel, pickPdf: () -> Unit) {
    val source = state.source
    if (source == null) {
        if (!state.loading) {
            PickFileCard(
                icon = Icons.Filled.Description,
                title = stringResource(R.string.pdf_text_empty_title),
                description = stringResource(R.string.pdf_text_empty_desc),
                buttonText = stringResource(R.string.action_choose_pdf),
                onPick = pickPdf,
            )
        }
        return
    }
    SourceFileCard(source = source, onChange = if (state.working) null else pickPdf)

    Text(
        stringResource(R.string.pdf_text_note),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )

    val text = state.extractedText ?: return
    val clipboard = LocalClipboardManager.current
    OutlinedCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.text_preview),
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = {
                    clipboard.setText(AnnotatedString(text))
                    viewModel.textCopied()
                }) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.action_copy))
                }
            }
            if (state.textTruncated) {
                Text(
                    stringResource(R.string.text_truncated),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            SelectionContainer {
                Text(text = text, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun ChoiceChip(selected: Boolean, label: String, onClick: () -> Unit) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label) },
        leadingIcon = if (selected) {
            { Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp)) }
        } else {
            null
        },
    )
}
