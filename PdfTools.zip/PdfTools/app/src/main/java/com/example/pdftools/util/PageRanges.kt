package com.example.pdftools.util

import com.example.pdftools.R

/**
 * Parses page range expressions such as "1-3,5", "7-", "-4".
 * Arabic-Indic digits (١-٣،٥) and the Arabic comma are accepted too.
 */
object PageRanges {

    /** Returns one list of 0-based page indices per range, in the order typed by the user. */
    fun parse(input: String, pageCount: Int): List<List<Int>> {
        val text = normalize(input).replace(" ", "")
        val parts = text.split(',', ';').filter { it.isNotEmpty() }
        if (parts.isEmpty()) throw AppException(uiText(R.string.error_range_empty))

        return parts.map { part ->
            val bounds = part.split('-')
            val start: Int
            val end: Int
            when (bounds.size) {
                1 -> {
                    start = bounds[0].toIntOrNull() ?: invalid(part)
                    end = start
                }
                2 -> {
                    start = if (bounds[0].isEmpty()) 1 else bounds[0].toIntOrNull() ?: invalid(part)
                    end = if (bounds[1].isEmpty()) pageCount else bounds[1].toIntOrNull() ?: invalid(part)
                }
                else -> invalid(part)
            }
            if (start < 1 || end > pageCount || start > end) {
                throw AppException(uiText(R.string.error_range_out_of_bounds, part, pageCount))
            }
            (start - 1 until end).toList()
        }
    }

    /** Converts Arabic/Persian digits and punctuation to ASCII. */
    fun normalize(input: String): String {
        val builder = StringBuilder(input.length)
        for (c in input) {
            val mapped = when (c) {
                in '٠'..'٩' -> '0' + (c - '٠')
                in '۰'..'۹' -> '0' + (c - '۰')
                '،', '؛' -> ','
                '–', '—', '−' -> '-'
                else -> c
            }
            builder.append(mapped)
        }
        return builder.toString()
    }

    private fun invalid(part: String): Nothing =
        throw AppException(uiText(R.string.error_range_invalid, part))
}
