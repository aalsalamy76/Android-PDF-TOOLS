package com.example.pdftools.util

import android.util.Log
import com.example.pdftools.R
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.FileNotFoundException
import java.io.IOException

/** An error that already carries a user friendly, translatable message. */
class AppException(val text: UiText, cause: Throwable? = null) : Exception(cause)

/** Maps any failure to a friendly message (Arabic / English / French / Spanish). */
fun Throwable.toUiText(): UiText = when (this) {
    is AppException -> text
    is InvalidPasswordException -> uiText(R.string.error_password)
    // PdfRenderer throws SecurityException for password protected files.
    is SecurityException -> uiText(R.string.error_password)
    is OutOfMemoryError -> uiText(R.string.error_memory)
    is FileNotFoundException -> uiText(R.string.error_file_not_found)
    is IOException -> uiText(R.string.error_corrupt)
    else -> uiText(R.string.error_generic)
}

/**
 * Runs [block] on [Dispatchers.IO] and wraps the outcome in a [Result].
 * Coroutine cancellation is never swallowed.
 */
suspend fun <T> ioCatching(block: suspend CoroutineScope.() -> T): Result<T> =
    withContext(Dispatchers.IO) {
        try {
            Result.success(block())
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            Log.w("PdfTools", "Operation failed", t)
            Result.failure(t)
        }
    }
