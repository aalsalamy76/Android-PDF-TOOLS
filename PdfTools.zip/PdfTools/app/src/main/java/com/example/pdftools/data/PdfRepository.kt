package com.example.pdftools.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.example.pdftools.R
import com.example.pdftools.util.AppException
import com.example.pdftools.util.uiText
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.blend.BlendMode
import com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDChoice
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDRadioButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTerminalField
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionGoTo
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageDestination
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.util.Matrix as PdfMatrix
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.Collections
import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

fun normalizeRotation(degrees: Int): Int = ((degrees % 360) + 360) % 360

/**
 * Every PDF operation of the app. PdfBox-Android is used for editing,
 * Android's PdfRenderer for rasterizing. All functions are blocking:
 * call them from Dispatchers.IO (see ioCatching).
 */
class PdfRepository(private val context: Context) {

    /** One page of the result: which source page, and how much extra rotation to apply. */
    data class PageEdit(val sourceIndex: Int, val extraRotation: Int)

    /**
     * Signature position, expressed as fractions of the page *as displayed*
     * (0,0 = top-left corner). [widthFraction] is the signature width / page width.
     */
    data class Placement(
        val pageIndex: Int,
        val centerX: Float,
        val centerY: Float,
        val widthFraction: Float,
    )

    enum class PageSizeMode { A4, FIT_IMAGE }

    enum class ImageFormat(val extension: String, val mime: String, val compressFormat: Bitmap.CompressFormat) {
        PNG("png", MIME_PNG, Bitmap.CompressFormat.PNG),
        JPG("jpg", MIME_JPEG, Bitmap.CompressFormat.JPEG),
    }

    // ---------------------------------------------------------------- helpers

    private fun memory(): MemoryUsageSetting =
        MemoryUsageSetting.setupMixed(MAX_MAIN_MEMORY).setTempDir(context.cacheDir)

    /** Loads a document with PdfBox and converts low level errors to friendly messages. */
    private fun load(file: File, displayName: String? = null): PDDocument {
        val document = try {
            PDDocument.load(file, memory())
        } catch (e: InvalidPasswordException) {
            throw AppException(
                if (displayName != null) uiText(R.string.error_password_named, displayName)
                else uiText(R.string.error_password),
                e
            )
        } catch (e: IOException) {
            throw AppException(
                if (displayName != null) uiText(R.string.error_corrupt_named, displayName)
                else uiText(R.string.error_corrupt),
                e
            )
        }
        // Files with only an "owner" password (printing/copy restrictions) can be edited;
        // the restrictions are removed from the saved copy.
        if (document.isEncrypted) document.setAllSecurityToBeRemoved(true)
        return document
    }

    private fun closeQuietly(document: PDDocument) {
        try {
            document.close()
        } catch (_: Exception) {
        }
    }

    /** Validates the file with PdfRenderer and returns its number of pages. */
    fun pageCount(file: File): Int =
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer -> renderer.pageCount }
        }

    // ---------------------------------------------------------------- merge

    fun merge(inputs: List<Pair<File, String>>, output: File, onProgress: (Float) -> Unit) {
        val destination = PDDocument(memory())
        val sources = ArrayList<PDDocument>(inputs.size)
        try {
            val merger = PDFMergerUtility()
            inputs.forEachIndexed { index, (file, name) ->
                val source = load(file, name)
                sources.add(source)
                merger.appendDocument(destination, source)
                onProgress((index + 1f) / (inputs.size + 1f))
            }
            destination.save(output)
            onProgress(1f)
        } finally {
            closeQuietly(destination)
            sources.forEach { closeQuietly(it) }
        }
    }

    // ---------------------------------------------------------------- organize / split

    /** Reorders, rotates and deletes pages in one pass. */
    fun organize(input: File, edits: List<PageEdit>, output: File) {
        load(input).use { document ->
            val total = document.numberOfPages
            val removedSome = edits.map { it.sourceIndex }.toSet().size < total
            rebuildPageTree(document, edits)
            pruneReferences(document, removeStructure = removedSome, removeNavigation = false)
            document.save(output)
        }
    }

    /** Writes one new PDF per group of (0-based) page indices. */
    fun extract(
        input: File,
        groups: List<List<Int>>,
        outputs: List<File>,
        onProgress: (Float) -> Unit,
    ) {
        require(groups.size == outputs.size)
        groups.forEachIndexed { i, indices ->
            load(input).use { document ->
                rebuildPageTree(document, indices.distinct().map { PageEdit(it, 0) })
                pruneReferences(document, removeStructure = true, removeNavigation = true)
                document.save(outputs[i])
            }
            onProgress((i + 1f) / groups.size)
        }
    }

    /**
     * Replaces the page tree with a flat list of the requested pages.
     * Inherited attributes (media box, resources, rotation) are copied onto each page first,
     * so nothing is lost when the pages leave their original parent nodes.
     */
    private fun rebuildPageTree(document: PDDocument, edits: List<PageEdit>) {
        val total = document.numberOfPages
        val pages: List<PDPage> = edits.map { edit ->
            if (edit.sourceIndex !in 0 until total) throw AppException(uiText(R.string.error_generic))
            val page = document.getPage(edit.sourceIndex)
            val mediaBox = page.mediaBox
            page.mediaBox = mediaBox
            val cropBox = page.cropBox
            page.cropBox = cropBox
            val resources = page.resources
            if (resources != null) page.resources = resources
            page.rotation = normalizeRotation(page.rotation + edit.extraRotation)
            page
        }
        val root: COSDictionary = document.pages.cosObject
        val kids = COSArray()
        for (page in pages) {
            page.cosObject.setItem(COSName.PARENT, root)
            kids.add(page.cosObject)
        }
        root.setItem(COSName.KIDS, kids)
        root.setInt(COSName.COUNT, pages.size)
    }

    /** Drops references to removed pages so they are not written again (keeps files small). */
    private fun pruneReferences(document: PDDocument, removeStructure: Boolean, removeNavigation: Boolean) {
        val keptPages: MutableSet<COSDictionary> = Collections.newSetFromMap(IdentityHashMap())
        document.pages.forEach { keptPages.add(it.cosObject) }
        document.pages.forEach { page ->
            try {
                val annotations = page.annotations
                // Internal links that point to a removed page are dropped.
                val remaining = annotations.filter { annotation ->
                    if (annotation is PDAnnotationLink) {
                        val destination = annotation.destination
                            ?: (annotation.action as? PDActionGoTo)?.destination
                        if (destination is PDPageDestination) {
                            val target = destination.page
                            if (target != null && target.cosObject !in keptPages) return@filter false
                        }
                    }
                    true
                }
                remaining.forEach { annotation ->
                    val owner = annotation.page
                    if (owner != null && owner.cosObject !in keptPages) annotation.page = page
                }
                if (remaining.size != annotations.size) page.annotations = remaining
            } catch (_: Exception) {
                // Damaged annotations must not prevent saving the document.
            }
        }
        val catalog = document.documentCatalog.cosObject
        catalog.removeItem(COSName.getPDFName("PageLabels"))
        if (removeStructure) {
            catalog.removeItem(COSName.getPDFName("StructTreeRoot"))
            catalog.removeItem(COSName.getPDFName("MarkInfo"))
        }
        if (removeNavigation) {
            catalog.removeItem(COSName.getPDFName("Outlines"))
            catalog.removeItem(COSName.getPDFName("Dests"))
            catalog.removeItem(COSName.getPDFName("Names"))
        }
    }

    // ---------------------------------------------------------------- sign

    /** Stamps the signature image (transparent PNG) on the requested pages. */
    fun addSignature(input: File, output: File, signature: Bitmap, placements: List<Placement>) {
        load(input).use { document ->
            val imagesByRotation = HashMap<Int, PDImageXObject>()
            val aspect = signature.height.toFloat() / signature.width.toFloat()
            for (placement in placements) {
                val page = document.getPage(placement.pageIndex)
                val rotation = normalizeRotation(page.rotation)
                val box = page.cropBox
                val swapped = rotation == 90 || rotation == 270
                val shownWidth = if (swapped) box.height else box.width
                val shownHeight = if (swapped) box.width else box.height

                val width = placement.widthFraction * shownWidth
                val height = width * aspect
                val left = placement.centerX * shownWidth - width / 2f
                val top = placement.centerY * shownHeight - height / 2f
                val a = displayToUserSpace(left, top, rotation, box)
                val b = displayToUserSpace(left + width, top + height, rotation, box)

                // The image is counter-rotated so that it appears upright on rotated pages.
                val image = imagesByRotation.getOrPut(rotation) {
                    LosslessFactory.createFromImage(document, rotateBitmap(signature, -rotation))
                }
                PDPageContentStream(
                    document, page, PDPageContentStream.AppendMode.APPEND, true, true
                ).use { stream ->
                    stream.drawImage(
                        image,
                        min(a[0], b[0]), min(a[1], b[1]),
                        abs(a[0] - b[0]), abs(a[1] - b[1])
                    )
                }
            }
            document.save(output)
        }
    }

    /** Converts a point of the displayed page (origin top-left) to PDF user space. */
    private fun displayToUserSpace(x: Float, y: Float, rotation: Int, box: PDRectangle): FloatArray {
        val llx = box.lowerLeftX
        val lly = box.lowerLeftY
        val w = box.width
        val h = box.height
        return when (rotation) {
            90 -> floatArrayOf(llx + y, lly + x)
            180 -> floatArrayOf(llx + w - x, lly + y)
            270 -> floatArrayOf(llx + w - y, lly + h - x)
            else -> floatArrayOf(llx + x, lly + h - y)
        }
    }

    private fun rotateBitmap(source: Bitmap, degrees: Int): Bitmap {
        if (normalizeRotation(degrees) == 0) return source
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    // ---------------------------------------------------------------- annotate

    /** Draws the user's marks (pen, highlighter, rectangles, text) permanently into the pages. */
    fun applyMarks(input: File, output: File, marks: List<Mark>, onProgress: (Float) -> Unit) {
        load(input).use { document ->
            val byPage = marks.groupBy { it.page }
            val total = byPage.size.coerceAtLeast(1)
            var done = 0
            for ((pageIndex, pageMarks) in byPage) {
                if (pageIndex !in 0 until document.numberOfPages) continue
                val page = document.getPage(pageIndex)
                val rotation = normalizeRotation(page.rotation)
                val box = page.cropBox
                val swapped = rotation == 90 || rotation == 270
                val shownWidth = if (swapped) box.height else box.width
                val shownHeight = if (swapped) box.width else box.height
                fun user(point: MarkPoint): FloatArray =
                    displayToUserSpace(point.x * shownWidth, point.y * shownHeight, rotation, box)

                PDPageContentStream(
                    document, page, PDPageContentStream.AppendMode.APPEND, true, true
                ).use { stream ->
                    for (mark in pageMarks) {
                        if (mark.points.isEmpty()) continue
                        val red = ((mark.color shr 16) and 0xFF) / 255f
                        val green = ((mark.color shr 8) and 0xFF) / 255f
                        val blue = (mark.color and 0xFF) / 255f
                        when (mark.type) {
                            MarkType.PEN, MarkType.HIGHLIGHT, MarkType.RECT -> {
                                stream.saveGraphicsState()
                                if (mark.type == MarkType.HIGHLIGHT) {
                                    val state = PDExtendedGraphicsState()
                                    state.setStrokingAlphaConstant(HIGHLIGHT_ALPHA)
                                    state.setBlendMode(BlendMode.MULTIPLY)
                                    stream.setGraphicsStateParameters(state)
                                }
                                stream.setStrokingColor(red, green, blue)
                                stream.setLineWidth(mark.size * shownWidth)
                                stream.setLineCapStyle(if (mark.type == MarkType.RECT) 0 else 1)
                                stream.setLineJoinStyle(1)
                                val path = if (mark.type == MarkType.RECT && mark.points.size >= 2) {
                                    val a = mark.points[0]
                                    val b = mark.points[1]
                                    listOf(a, MarkPoint(b.x, a.y), b, MarkPoint(a.x, b.y))
                                } else {
                                    mark.points
                                }
                                val first = user(path[0])
                                stream.moveTo(first[0], first[1])
                                if (path.size == 1) {
                                    stream.lineTo(first[0], first[1])
                                } else {
                                    for (i in 1 until path.size) {
                                        val p = user(path[i])
                                        stream.lineTo(p[0], p[1])
                                    }
                                }
                                if (mark.type == MarkType.RECT) stream.closePath()
                                stream.stroke()
                                stream.restoreGraphicsState()
                            }

                            MarkType.TEXT -> if (mark.text.isNotBlank()) {
                                val stamp = renderTextStamp(mark.text, mark.color, 1f)
                                val image = LosslessFactory.createFromImage(document, stamp)
                                val height = mark.size * shownWidth
                                val width = height * stamp.width / stamp.height
                                val top = mark.points[0]
                                // Lower-left corner of the text box, as displayed.
                                val anchor = displayToUserSpace(
                                    top.x * shownWidth, top.y * shownHeight + height, rotation, box
                                )
                                stream.saveGraphicsState()
                                stream.transform(
                                    PdfMatrix.getRotateInstance(Math.toRadians(rotation.toDouble()), anchor[0], anchor[1])
                                )
                                stream.drawImage(image, 0f, 0f, width, height)
                                stream.restoreGraphicsState()
                            }
                        }
                    }
                }
                done++
                onProgress(done.toFloat() / (total + 1))
            }
            document.save(output)
            onProgress(1f)
        }
    }

    // ---------------------------------------------------------------- forms

    /** Lists the fillable fields of the document (empty when it has no form). */
    fun readForm(input: File): List<FormField> = load(input).use { document ->
        val form = document.documentCatalog.acroForm ?: return@use emptyList()
        val fields = ArrayList<FormField>()
        for (field in form.fieldTree) {
            if (field !is PDTerminalField) continue
            val key = field.fullyQualifiedName ?: continue
            val label = field.alternateFieldName?.takeIf { it.isNotBlank() }
                ?: field.partialName?.takeIf { it.isNotBlank() }
                ?: key
            val entry = when (field) {
                is PDTextField -> FormField(key, label, FormFieldKind.TEXT, field.valueAsString ?: "")
                is PDCheckBox -> FormField(key, label, FormFieldKind.CHECKBOX, if (field.isChecked) "true" else "false")
                is PDRadioButton -> FormField(
                    key, label, FormFieldKind.RADIO, field.value ?: "",
                    options = field.onValues.filter { it.isNotBlank() }.sorted(),
                )
                is PDChoice -> FormField(
                    key, label, FormFieldKind.CHOICE, field.value.firstOrNull() ?: "",
                    options = field.optionsDisplayValues.ifEmpty { field.options },
                )
                is PDButton -> null // push buttons
                else -> null // signature fields
            } ?: continue
            fields.add(entry.copy(readOnly = field.isReadOnly))
        }
        fields
    }

    /** Fills the form with [values] (key -> value). [flatten] makes the answers part of the page. */
    fun fillForm(input: File, output: File, values: Map<String, String>, flatten: Boolean) {
        load(input).use { document ->
            val form = document.documentCatalog.acroForm
                ?: throw AppException(uiText(R.string.error_no_form))
            for ((key, value) in values) {
                val field = form.getField(key) ?: continue
                if (field.isReadOnly) continue
                try {
                    when (field) {
                        is PDCheckBox -> if (value == "true") field.check() else field.unCheck()
                        is PDRadioButton -> if (value.isNotEmpty()) field.setValue(value)
                        is PDChoice -> if (value.isNotEmpty()) {
                            val display = field.optionsDisplayValues
                            val export = field.optionsExportValues
                            val index = display.indexOf(value)
                            field.setValue(
                                if (index >= 0 && index < export.size && export.isNotEmpty()) export[index] else value
                            )
                        }
                        is PDTextField -> field.setValue(value)
                        else -> Unit
                    }
                } catch (e: IllegalArgumentException) {
                    // The form's font cannot draw these characters (e.g. Arabic in a Helvetica field).
                    throw AppException(uiText(R.string.error_form_charset, field.partialName ?: key), e)
                }
            }
            if (flatten) form.flatten()
            document.save(output)
        }
    }

    // ---------------------------------------------------------------- optimize & security

    /** How strongly embedded photos are re-encoded. */
    enum class CompressLevel(val maxSide: Int, val quality: Int) {
        LIGHT(2200, 82),
        MEDIUM(1600, 68),
        STRONG(1100, 52),
    }

    /** Re-encodes large embedded images as JPEG. Text and vector graphics are not touched. */
    fun compress(input: File, output: File, level: CompressLevel, onProgress: (Float) -> Unit) {
        load(input).use { document ->
            val replaced = IdentityHashMap<COSBase, PDImageXObject?>()
            val visitedForms: MutableSet<COSBase> = Collections.newSetFromMap(IdentityHashMap())
            val total = document.numberOfPages
            document.pages.forEachIndexed { index, page ->
                compressResources(document, page.resources, level, replaced, visitedForms)
                onProgress((index + 1f) / (total + 1f))
            }
            document.save(output)
            onProgress(1f)
        }
    }

    private fun compressResources(
        document: PDDocument,
        resources: PDResources?,
        level: CompressLevel,
        replaced: IdentityHashMap<COSBase, PDImageXObject?>,
        visitedForms: MutableSet<COSBase>,
    ) {
        if (resources == null) return
        for (name in resources.xObjectNames.toList()) {
            val xObject = try {
                resources.getXObject(name)
            } catch (_: Exception) {
                null
            } ?: continue
            when (xObject) {
                is PDImageXObject -> {
                    val key: COSBase = xObject.cosObject
                    val replacement = if (replaced.containsKey(key)) {
                        replaced[key]
                    } else {
                        recompressImage(document, xObject, level).also { replaced[key] = it }
                    }
                    if (replacement != null) resources.put(name, replacement)
                }
                is PDFormXObject -> if (visitedForms.add(xObject.cosObject)) {
                    compressResources(document, xObject.resources, level, replaced, visitedForms)
                }
            }
        }
    }

    /** Returns a smaller JPEG version of [image], or null when it is better to keep the original. */
    private fun recompressImage(document: PDDocument, image: PDImageXObject, level: CompressLevel): PDImageXObject? =
        try {
            val stream = image.cosObject
            when {
                image.isStencil -> null
                stream.containsKey(COSName.getPDFName("SMask")) -> null
                stream.containsKey(COSName.getPDFName("Mask")) -> null
                image.width.toLong() * image.height.toLong() < MIN_IMAGE_PIXELS -> null
                else -> {
                    val bitmap: Bitmap? = image.image
                    if (bitmap == null) {
                        null
                    } else {
                        val bytes = encodeJpeg(bitmap, level.maxSide, level.quality)
                        if (bytes.size >= stream.length * 0.9) {
                            null
                        } else {
                            JPEGFactory.createFromStream(document, ByteArrayInputStream(bytes))
                        }
                    }
                }
            }
        } catch (_: Exception) {
            null
        } catch (_: OutOfMemoryError) {
            null
        }

    private fun encodeJpeg(bitmap: Bitmap, maxSide: Int, quality: Int): ByteArray {
        val largest = max(bitmap.width, bitmap.height)
        val scaled = if (largest > maxSide) {
            val ratio = maxSide.toFloat() / largest
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * ratio).roundToInt().coerceAtLeast(1),
                (bitmap.height * ratio).roundToInt().coerceAtLeast(1),
                true
            )
        } else {
            bitmap
        }
        val flat = flattenOnWhite(scaled)
        val bytes = ByteArrayOutputStream().use { out ->
            flat.compress(Bitmap.CompressFormat.JPEG, quality, out)
            out.toByteArray()
        }
        if (flat !== scaled) flat.recycle()
        if (scaled !== bitmap) scaled.recycle()
        return bytes
    }

    /** Encrypts the document with AES-256: the password is needed to open it. */
    fun protect(input: File, output: File, password: String) {
        load(input).use { document ->
            val policy = StandardProtectionPolicy(password, password, AccessPermission())
            policy.encryptionKeyLength = 256
            document.protect(policy)
            document.save(output)
        }
    }

    /** Opens a protected document with [password] and saves a copy without protection. */
    fun unlock(input: File, password: String, output: File) {
        val document = try {
            PDDocument.load(input, password, memory())
        } catch (e: InvalidPasswordException) {
            throw AppException(uiText(R.string.error_wrong_password), e)
        } catch (e: IOException) {
            throw AppException(uiText(R.string.error_corrupt), e)
        }
        document.use {
            it.setAllSecurityToBeRemoved(true)
            it.save(output)
        }
    }

    // ---------------------------------------------------------------- page numbers & watermark

    enum class NumberPosition { BOTTOM_CENTER, BOTTOM_RIGHT, BOTTOM_LEFT, TOP_RIGHT }

    /** Writes "1", "2"… (or "1 / 10") on every page, upright even on rotated pages. */
    fun addPageNumbers(
        input: File,
        output: File,
        position: NumberPosition,
        withTotal: Boolean,
        onProgress: (Float) -> Unit,
    ) {
        load(input).use { document ->
            val font = PDType1Font.HELVETICA
            val total = document.numberOfPages
            document.pages.forEachIndexed { index, page ->
                val text = if (withTotal) "${index + 1} / $total" else "${index + 1}"
                val rotation = normalizeRotation(page.rotation)
                val box = page.cropBox
                val swapped = rotation == 90 || rotation == 270
                val shownWidth = if (swapped) box.height else box.width
                val shownHeight = if (swapped) box.width else box.height
                val fontSize = (min(shownWidth, shownHeight) / 48f).coerceIn(8f, 18f)
                val textWidth = font.getStringWidth(text) / 1000f * fontSize
                val margin = fontSize * 2.2f
                val x = when (position) {
                    NumberPosition.BOTTOM_CENTER -> (shownWidth - textWidth) / 2f
                    NumberPosition.BOTTOM_LEFT -> margin
                    NumberPosition.BOTTOM_RIGHT, NumberPosition.TOP_RIGHT -> shownWidth - margin - textWidth
                }
                val baseline = if (position == NumberPosition.TOP_RIGHT) margin + fontSize else shownHeight - margin
                val origin = displayToUserSpace(x, baseline, rotation, box)
                PDPageContentStream(
                    document, page, PDPageContentStream.AppendMode.APPEND, true, true
                ).use { stream ->
                    stream.beginText()
                    stream.setFont(font, fontSize)
                    stream.setNonStrokingColor(0.25f, 0.25f, 0.25f)
                    stream.setTextMatrix(
                        PdfMatrix.getRotateInstance(Math.toRadians(rotation.toDouble()), origin[0], origin[1])
                    )
                    stream.showText(text)
                    stream.endText()
                }
                onProgress((index + 1f) / (total + 1f))
            }
            document.save(output)
            onProgress(1f)
        }
    }

    /** Stamps [stamp] (see [renderTextStamp]) in the middle of every page, optionally diagonally. */
    fun addWatermark(
        input: File,
        output: File,
        stamp: Bitmap,
        diagonal: Boolean,
        onProgress: (Float) -> Unit,
    ) {
        load(input).use { document ->
            val image = LosslessFactory.createFromImage(document, stamp)
            val aspect = stamp.height.toFloat() / stamp.width.toFloat()
            val total = document.numberOfPages
            document.pages.forEachIndexed { index, page ->
                val rotation = normalizeRotation(page.rotation)
                val box = page.cropBox
                val swapped = rotation == 90 || rotation == 270
                val shownWidth = if (swapped) box.height else box.width
                val shownHeight = if (swapped) box.width else box.height
                val angle = if (diagonal) {
                    Math.toDegrees(atan2(shownHeight.toDouble(), shownWidth.toDouble()))
                } else {
                    0.0
                }
                val span = if (diagonal) sqrt(shownWidth * shownWidth + shownHeight * shownHeight) else shownWidth
                var width = span * 0.75f
                var height = width * aspect
                val maxHeight = min(shownWidth, shownHeight) * 0.3f
                if (height > maxHeight) {
                    height = maxHeight
                    width = height / aspect
                }
                val center = displayToUserSpace(shownWidth / 2f, shownHeight / 2f, rotation, box)
                PDPageContentStream(
                    document, page, PDPageContentStream.AppendMode.APPEND, true, true
                ).use { stream ->
                    stream.saveGraphicsState()
                    stream.transform(
                        PdfMatrix.getRotateInstance(Math.toRadians(rotation + angle), center[0], center[1])
                    )
                    stream.drawImage(image, -width / 2f, -height / 2f, width, height)
                    stream.restoreGraphicsState()
                }
                onProgress((index + 1f) / (total + 1f))
            }
            document.save(output)
            onProgress(1f)
        }
    }

    /** Draws [text] (any language, Arabic included) on a transparent bitmap. */
    fun renderTextStamp(text: String, textColor: Int, opacity: Float): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = textColor
        paint.alpha = (opacity.coerceIn(0.05f, 1f) * 255f).roundToInt()
        paint.textSize = STAMP_TEXT_SIZE
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val metrics = paint.fontMetrics
        val padding = STAMP_TEXT_SIZE / 4f
        val width = (paint.measureText(text) + padding * 2f).roundToInt().coerceIn(1, 8000)
        val height = (metrics.descent - metrics.ascent + padding).roundToInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        Canvas(bitmap).drawText(text, padding, padding / 2f - metrics.ascent, paint)
        return bitmap
    }

    // ---------------------------------------------------------------- convert

    /** Images (any format Android can decode, EXIF orientation applied) to one PDF. */
    fun imagesToPdf(
        images: List<Pair<Uri, String>>,
        mode: PageSizeMode,
        output: File,
        onProgress: (Float) -> Unit,
    ) {
        PDDocument(memory()).use { document ->
            images.forEachIndexed { index, (uri, name) ->
                val bitmap = try {
                    decodeImage(uri, MAX_IMAGE_SIDE)
                } catch (e: Exception) {
                    throw AppException(uiText(R.string.error_image_named, name), e)
                }
                val imageWidth = bitmap.width
                val imageHeight = bitmap.height
                val jpegBytes = ByteArrayOutputStream().use { out ->
                    val flat = flattenOnWhite(bitmap)
                    flat.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
                    if (flat !== bitmap) flat.recycle()
                    out.toByteArray()
                }
                bitmap.recycle()
                val image = JPEGFactory.createFromStream(document, ByteArrayInputStream(jpegBytes))

                val pageRect = when (mode) {
                    PageSizeMode.A4 -> if (imageWidth > imageHeight) {
                        PDRectangle(PDRectangle.A4.height, PDRectangle.A4.width)
                    } else {
                        PDRectangle(PDRectangle.A4.width, PDRectangle.A4.height)
                    }
                    PageSizeMode.FIT_IMAGE -> {
                        val pointsPerPixel = 72f / IMAGE_DPI
                        PDRectangle(imageWidth * pointsPerPixel, imageHeight * pointsPerPixel)
                    }
                }
                val page = PDPage(pageRect)
                document.addPage(page)

                val margin = if (mode == PageSizeMode.A4) A4_MARGIN else 0f
                val scale = min(
                    (pageRect.width - 2 * margin) / imageWidth,
                    (pageRect.height - 2 * margin) / imageHeight
                )
                val drawWidth = imageWidth * scale
                val drawHeight = imageHeight * scale
                val x = (pageRect.width - drawWidth) / 2f
                val y = (pageRect.height - drawHeight) / 2f
                PDPageContentStream(document, page).use { stream ->
                    stream.drawImage(image, x, y, drawWidth, drawHeight)
                }
                onProgress((index + 1f) / (images.size + 1f))
            }
            document.save(output)
            onProgress(1f)
        }
    }

    /** Decodes an image with a software bitmap, scaled down so its longest side is <= [maxSide]. */
    fun decodeImage(uri: Uri, maxSide: Int): Bitmap {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val width = info.size.width
            val height = info.size.height
            val largest = max(width, height)
            if (largest > maxSide) {
                val ratio = maxSide.toFloat() / largest
                decoder.setTargetSize(
                    (width * ratio).roundToInt().coerceAtLeast(1),
                    (height * ratio).roundToInt().coerceAtLeast(1)
                )
            }
        }
    }

    private fun flattenOnWhite(bitmap: Bitmap): Bitmap {
        if (!bitmap.hasAlpha()) return bitmap
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(bitmap, 0f, 0f, null)
        return result
    }

    /** Renders the given (0-based) pages to PNG/JPG files. */
    fun pdfToImages(
        input: File,
        pages: List<Int>,
        dpi: Int,
        format: ImageFormat,
        outputs: List<File>,
        onProgress: (Float) -> Unit,
    ) {
        require(pages.size == outputs.size)
        ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                pages.forEachIndexed { i, pageIndex ->
                    renderer.openPage(pageIndex).use { page ->
                        var scale = dpi / 72f
                        val pixels = page.width * scale * page.height * scale
                        if (pixels > MAX_PIXELS) scale *= sqrt(MAX_PIXELS / pixels)
                        val width = (page.width * scale).roundToInt().coerceAtLeast(1)
                        val height = (page.height * scale).roundToInt().coerceAtLeast(1)
                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        try {
                            bitmap.eraseColor(Color.WHITE)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            outputs[i].outputStream().use { out ->
                                bitmap.compress(format.compressFormat, IMAGE_QUALITY, out)
                            }
                        } finally {
                            bitmap.recycle()
                        }
                    }
                    onProgress((i + 1f) / pages.size)
                }
            }
        }
    }

    /** Extracts the plain text of every page. Throws when the PDF has no text layer. */
    fun extractText(input: File, onProgress: (Float) -> Unit): String = load(input).use { document ->
        // Text on pages flagged with /Rotate is drawn horizontally in page space; reading it
        // with the rotation applied splits every word into fragments. The document is not saved.
        document.pages.forEach { page -> if (page.rotation != 0) page.rotation = 0 }
        val stripper = PDFTextStripper()
        val total = document.numberOfPages
        val builder = StringBuilder()
        for (pageNumber in 1..total) {
            stripper.setStartPage(pageNumber)
            stripper.setEndPage(pageNumber)
            val text = stripper.getText(document).trim()
            if (total > 1) builder.append("— ").append(pageNumber).append(" —\n")
            builder.append(text).append("\n\n")
            onProgress(pageNumber.toFloat() / total)
        }
        val result = builder.toString().trim()
        if (result.replace(Regex("[—\\d\\s]"), "").isEmpty()) {
            throw AppException(uiText(R.string.error_no_text))
        }
        result
    }

    private companion object {
        const val MAX_MAIN_MEMORY = 64L * 1024L * 1024L
        const val MAX_IMAGE_SIDE = 3000
        const val JPEG_QUALITY = 88
        const val IMAGE_QUALITY = 92
        const val IMAGE_DPI = 150f
        const val A4_MARGIN = 20f
        const val MAX_PIXELS = 12_000_000f
        const val MIN_IMAGE_PIXELS = 160_000L
        const val STAMP_TEXT_SIZE = 160f
        const val HIGHLIGHT_ALPHA = 0.4f
    }
}
