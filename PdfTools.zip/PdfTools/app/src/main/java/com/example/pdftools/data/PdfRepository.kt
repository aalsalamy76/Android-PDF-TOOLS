package com.example.pdftools.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.example.pdftools.R
import com.example.pdftools.util.AppException
import com.example.pdftools.util.uiText
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionGoTo
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageDestination
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.Collections
import java.util.IdentityHashMap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

fun normalizeRotation(degrees: Int): Int = ((degrees % 360) + 360) % 360

/**
 * Every PDF operation of the app. PdfBox-Android is used for editing,
 * Android's PdfRenderer for rasterizing. All functions are blocking:
 * call them from Dispatchers.IO (see ioCatching).
 */
class PdfRepository(private val context: Context) {

    /** One page of the result: which source page, and how much extra rotation to apply. */
    data class PageEdit(val sourceIndex: Int, val extraRotation: Int)

    /**
     * Signature position, expressed as fractions of the page *as displayed*
     * (0,0 = top-left corner). [widthFraction] is the signature width / page width.
     */
    data class Placement(
        val pageIndex: Int,
        val centerX: Float,
        val centerY: Float,
        val widthFraction: Float,
    )

    enum class PageSizeMode { A4, FIT_IMAGE }

    enum class ImageFormat(val extension: String, val mime: String, val compressFormat: Bitmap.CompressFormat) {
        PNG("png", MIME_PNG, Bitmap.CompressFormat.PNG),
        JPG("jpg", MIME_JPEG, Bitmap.CompressFormat.JPEG),
    }

    // ---------------------------------------------------------------- helpers

    private fun memory(): MemoryUsageSetting =
        MemoryUsageSetting.setupMixed(MAX_MAIN_MEMORY).setTempDir(context.cacheDir)

    /** Loads a document with PdfBox and converts low level errors to friendly messages. */
    private fun load(file: File, displayName: String? = null): PDDocument {
        val document = try {
            PDDocument.load(file, memory())
        } catch (e: InvalidPasswordException) {
            throw AppException(
                if (displayName != null) uiText(R.string.error_password_named, displayName)
                else uiText(R.string.error_password),
                e
            )
        } catch (e: IOException) {
            throw AppException(
                if (displayName != null) uiText(R.string.error_corrupt_named, displayName)
                else uiText(R.string.error_corrupt),
                e
            )
        }
        // Files with only an "owner" password (printing/copy restrictions) can be edited;
        // the restrictions are removed from the saved copy.
        if (document.isEncrypted) document.setAllSecurityToBeRemoved(true)
        return document
    }

    private fun closeQuietly(document: PDDocument) {
        try {
            document.close()
        } catch (_: Exception) {
        }
    }

    /** Validates the file with PdfRenderer and returns its number of pages. */
    fun pageCount(file: File): Int =
        ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer -> renderer.pageCount }
        }

    // ---------------------------------------------------------------- merge

    fun merge(inputs: List<Pair<File, String>>, output: File, onProgress: (Float) -> Unit) {
        val destination = PDDocument(memory())
        val sources = ArrayList<PDDocument>(inputs.size)
        try {
            val merger = PDFMergerUtility()
            inputs.forEachIndexed { index, (file, name) ->
                val source = load(file, name)
                sources.add(source)
                merger.appendDocument(destination, source)
                onProgress((index + 1f) / (inputs.size + 1f))
            }
            destination.save(output)
            onProgress(1f)
        } finally {
            closeQuietly(destination)
            sources.forEach { closeQuietly(it) }
        }
    }

    // ---------------------------------------------------------------- organize / split

    /** Reorders, rotates and deletes pages in one pass. */
    fun organize(input: File, edits: List<PageEdit>, output: File) {
        load(input).use { document ->
            val total = document.numberOfPages
            val removedSome = edits.map { it.sourceIndex }.toSet().size < total
            rebuildPageTree(document, edits)
            pruneReferences(document, removeStructure = removedSome, removeNavigation = false)
            document.save(output)
        }
    }

    /** Writes one new PDF per group of (0-based) page indices. */
    fun extract(
        input: File,
        groups: List<List<Int>>,
        outputs: List<File>,
        onProgress: (Float) -> Unit,
    ) {
        require(groups.size == outputs.size)
        groups.forEachIndexed { i, indices ->
            load(input).use { document ->
                rebuildPageTree(document, indices.distinct().map { PageEdit(it, 0) })
                pruneReferences(document, removeStructure = true, removeNavigation = true)
                document.save(outputs[i])
            }
            onProgress((i + 1f) / groups.size)
        }
    }

    /**
     * Replaces the page tree with a flat list of the requested pages.
     * Inherited attributes (media box, resources, rotation) are copied onto each page first,
     * so nothing is lost when the pages leave their original parent nodes.
     */
    private fun rebuildPageTree(document: PDDocument, edits: List<PageEdit>) {
        val total = document.numberOfPages
        val pages: List<PDPage> = edits.map { edit ->
            if (edit.sourceIndex !in 0 until total) throw AppException(uiText(R.string.error_generic))
            val page = document.getPage(edit.sourceIndex)
            val mediaBox = page.mediaBox
            page.mediaBox = mediaBox
            val cropBox = page.cropBox
            page.cropBox = cropBox
            val resources = page.resources
            if (resources != null) page.resources = resources
            page.rotation = normalizeRotation(page.rotation + edit.extraRotation)
            page
        }
        val root: COSDictionary = document.pages.cosObject
        val kids = COSArray()
        for (page in pages) {
            page.cosObject.setItem(COSName.PARENT, root)
            kids.add(page.cosObject)
        }
        root.setItem(COSName.KIDS, kids)
        root.setInt(COSName.COUNT, pages.size)
    }

    /** Drops references to removed pages so they are not written again (keeps files small). */
    private fun pruneReferences(document: PDDocument, removeStructure: Boolean, removeNavigation: Boolean) {
        val keptPages: MutableSet<COSDictionary> = Collections.newSetFromMap(IdentityHashMap())
        document.pages.forEach { keptPages.add(it.cosObject) }
        document.pages.forEach { page ->
            try {
                val annotations = page.annotations
                // Internal links that point to a removed page are dropped.
                val remaining = annotations.filter { annotation ->
                    if (annotation is PDAnnotationLink) {
                        val destination = annotation.destination
                            ?: (annotation.action as? PDActionGoTo)?.destination
                        if (destination is PDPageDestination) {
                            val target = destination.page
                            if (target != null && target.cosObject !in keptPages) return@filter false
                        }
                    }
                    true
                }
                remaining.forEach { annotation ->
                    val owner = annotation.page
                    if (owner != null && owner.cosObject !in keptPages) annotation.page = page
                }
                if (remaining.size != annotations.size) page.annotations = remaining
            } catch (_: Exception) {
                // Damaged annotations must not prevent saving the document.
            }
        }
        val catalog = document.documentCatalog.cosObject
        catalog.removeItem(COSName.getPDFName("PageLabels"))
        if (removeStructure) {
            catalog.removeItem(COSName.getPDFName("StructTreeRoot"))
            catalog.removeItem(COSName.getPDFName("MarkInfo"))
        }
        if (removeNavigation) {
            catalog.removeItem(COSName.getPDFName("Outlines"))
            catalog.removeItem(COSName.getPDFName("Dests"))
            catalog.removeItem(COSName.getPDFName("Names"))
        }
    }

    // ---------------------------------------------------------------- sign

    /** Stamps the signature image (transparent PNG) on the requested pages. */
    fun addSignature(input: File, output: File, signature: Bitmap, placements: List<Placement>) {
        load(input).use { document ->
            val imagesByRotation = HashMap<Int, PDImageXObject>()
            val aspect = signature.height.toFloat() / signature.width.toFloat()
            for (placement in placements) {
                val page = document.getPage(placement.pageIndex)
                val rotation = normalizeRotation(page.rotation)
                val box = page.cropBox
                val swapped = rotation == 90 || rotation == 270
                val shownWidth = if (swapped) box.height else box.width
                val shownHeight = if (swapped) box.width else box.height

                val width = placement.widthFraction * shownWidth
                val height = width * aspect
                val left = placement.centerX * shownWidth - width / 2f
                val top = placement.centerY * shownHeight - height / 2f
                val a = displayToUserSpace(left, top, rotation, box)
                val b = displayToUserSpace(left + width, top + height, rotation, box)

                // The image is counter-rotated so that it appears upright on rotated pages.
                val image = imagesByRotation.getOrPut(rotation) {
                    LosslessFactory.createFromImage(document, rotateBitmap(signature, -rotation))
                }
                PDPageContentStream(
                    document, page, PDPageContentStream.AppendMode.APPEND, true, true
                ).use { stream ->
                    stream.drawImage(
                        image,
                        min(a[0], b[0]), min(a[1], b[1]),
                        abs(a[0] - b[0]), abs(a[1] - b[1])
                    )
                }
            }
            document.save(output)
        }
    }

    /** Converts a point of the displayed page (origin top-left) to PDF user space. */
    private fun displayToUserSpace(x: Float, y: Float, rotation: Int, box: PDRectangle): FloatArray {
        val llx = box.lowerLeftX
        val lly = box.lowerLeftY
        val w = box.width
        val h = box.height
        return when (rotation) {
            90 -> floatArrayOf(llx + y, lly + x)
            180 -> floatArrayOf(llx + w - x, lly + y)
            270 -> floatArrayOf(llx + w - y, lly + h - x)
            else -> floatArrayOf(llx + x, lly + h - y)
        }
    }

    private fun rotateBitmap(source: Bitmap, degrees: Int): Bitmap {
        if (normalizeRotation(degrees) == 0) return source
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
    }

    // ---------------------------------------------------------------- convert

    /** Images (any format Android can decode, EXIF orientation applied) to one PDF. */
    fun imagesToPdf(
        images: List<Pair<Uri, String>>,
        mode: PageSizeMode,
        output: File,
        onProgress: (Float) -> Unit,
    ) {
        PDDocument(memory()).use { document ->
            images.forEachIndexed { index, (uri, name) ->
                val bitmap = try {
                    decodeImage(uri, MAX_IMAGE_SIDE)
                } catch (e: Exception) {
                    throw AppException(uiText(R.string.error_image_named, name), e)
                }
                val imageWidth = bitmap.width
                val imageHeight = bitmap.height
                val jpegBytes = ByteArrayOutputStream().use { out ->
                    val flat = flattenOnWhite(bitmap)
                    flat.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
                    if (flat !== bitmap) flat.recycle()
                    out.toByteArray()
                }
                bitmap.recycle()
                val image = JPEGFactory.createFromStream(document, ByteArrayInputStream(jpegBytes))

                val pageRect = when (mode) {
                    PageSizeMode.A4 -> if (imageWidth > imageHeight) {
                        PDRectangle(PDRectangle.A4.height, PDRectangle.A4.width)
                    } else {
                        PDRectangle(PDRectangle.A4.width, PDRectangle.A4.height)
                    }
                    PageSizeMode.FIT_IMAGE -> {
                        val pointsPerPixel = 72f / IMAGE_DPI
                        PDRectangle(imageWidth * pointsPerPixel, imageHeight * pointsPerPixel)
                    }
                }
                val page = PDPage(pageRect)
                document.addPage(page)

                val margin = if (mode == PageSizeMode.A4) A4_MARGIN else 0f
                val scale = min(
                    (pageRect.width - 2 * margin) / imageWidth,
                    (pageRect.height - 2 * margin) / imageHeight
                )
                val drawWidth = imageWidth * scale
                val drawHeight = imageHeight * scale
                val x = (pageRect.width - drawWidth) / 2f
                val y = (pageRect.height - drawHeight) / 2f
                PDPageContentStream(document, page).use { stream ->
                    stream.drawImage(image, x, y, drawWidth, drawHeight)
                }
                onProgress((index + 1f) / (images.size + 1f))
            }
            document.save(output)
            onProgress(1f)
        }
    }

    /** Decodes an image with a software bitmap, scaled down so its longest side is <= [maxSide]. */
    fun decodeImage(uri: Uri, maxSide: Int): Bitmap {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val width = info.size.width
            val height = info.size.height
            val largest = max(width, height)
            if (largest > maxSide) {
                val ratio = maxSide.toFloat() / largest
                decoder.setTargetSize(
                    (width * ratio).roundToInt().coerceAtLeast(1),
                    (height * ratio).roundToInt().coerceAtLeast(1)
                )
            }
        }
    }

    private fun flattenOnWhite(bitmap: Bitmap): Bitmap {
        if (!bitmap.hasAlpha()) return bitmap
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(bitmap, 0f, 0f, null)
        return result
    }

    /** Renders the given (0-based) pages to PNG/JPG files. */
    fun pdfToImages(
        input: File,
        pages: List<Int>,
        dpi: Int,
        format: ImageFormat,
        outputs: List<File>,
        onProgress: (Float) -> Unit,
    ) {
        require(pages.size == outputs.size)
        ParcelFileDescriptor.open(input, ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
            PdfRenderer(descriptor).use { renderer ->
                pages.forEachIndexed { i, pageIndex ->
                    renderer.openPage(pageIndex).use { page ->
                        var scale = dpi / 72f
                        val pixels = page.width * scale * page.height * scale
                        if (pixels > MAX_PIXELS) scale *= sqrt(MAX_PIXELS / pixels)
                        val width = (page.width * scale).roundToInt().coerceAtLeast(1)
                        val height = (page.height * scale).roundToInt().coerceAtLeast(1)
                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        try {
                            bitmap.eraseColor(Color.WHITE)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            outputs[i].outputStream().use { out ->
                                bitmap.compress(format.compressFormat, IMAGE_QUALITY, out)
                            }
                        } finally {
                            bitmap.recycle()
                        }
                    }
                    onProgress((i + 1f) / pages.size)
                }
            }
        }
    }

    /** Extracts the plain text of every page. Throws when the PDF has no text layer. */
    fun extractText(input: File, onProgress: (Float) -> Unit): String = load(input).use { document ->
        // Text on pages flagged with /Rotate is drawn horizontally in page space; reading it
        // with the rotation applied splits every word into fragments. The document is not saved.
        document.pages.forEach { page -> if (page.rotation != 0) page.rotation = 0 }
        val stripper = PDFTextStripper()
        val total = document.numberOfPages
        val builder = StringBuilder()
        for (pageNumber in 1..total) {
            stripper.setStartPage(pageNumber)
            stripper.setEndPage(pageNumber)
            val text = stripper.getText(document).trim()
            if (total > 1) builder.append("— ").append(pageNumber).append(" —\n")
            builder.append(text).append("\n\n")
            onProgress(pageNumber.toFloat() / total)
        }
        val result = builder.toString().trim()
        if (result.replace(Regex("[—\\d\\s]"), "").isEmpty()) {
            throw AppException(uiText(R.string.error_no_text))
        }
        result
    }

    private companion object {
        const val MAX_MAIN_MEMORY = 64L * 1024L * 1024L
        const val MAX_IMAGE_SIDE = 3000
        const val JPEG_QUALITY = 88
        const val IMAGE_QUALITY = 92
        const val IMAGE_DPI = 150f
        const val A4_MARGIN = 20f
        const val MAX_PIXELS = 12_000_000f
    }
}
