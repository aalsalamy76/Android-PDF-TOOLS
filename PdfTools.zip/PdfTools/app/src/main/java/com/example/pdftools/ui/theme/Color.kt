package com.example.pdftools.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

val LightColors = lightColorScheme(
    primary = Color(0xFFD32F2F),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFE3E0),
    onPrimaryContainer = Color(0xFF5F0F0B),
    secondary = Color(0xFF7A5754),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFCE4E1),
    onSecondaryContainer = Color(0xFF2E1513),
    tertiary = Color(0xFF00796B),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFD9F2EE),
    onTertiaryContainer = Color(0xFF00201C),
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF7F5F5),
    onBackground = Color(0xFF1F1B1B),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1F1B1B),
    surfaceVariant = Color(0xFFF2EBEA),
    onSurfaceVariant = Color(0xFF5A4D4B),
    outline = Color(0xFF8F7F7D),
    outlineVariant = Color(0xFFE4DAD8),
)

val DarkColors = darkColorScheme(
    primary = Color(0xFFFFB4AB),
    onPrimary = Color(0xFF690005),
    primaryContainer = Color(0xFF8C1D18),
    onPrimaryContainer = Color(0xFFFFDAD6),
    secondary = Color(0xFFE7BDB8),
    onSecondary = Color(0xFF442926),
    secondaryContainer = Color(0xFF3B2B29),
    onSecondaryContainer = Color(0xFFFFDAD6),
    tertiary = Color(0xFF7DDBCB),
    onTertiary = Color(0xFF003731),
    tertiaryContainer = Color(0xFF153B36),
    onTertiaryContainer = Color(0xFFA0F2E3),
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Color(0xFF141213),
    onBackground = Color(0xFFECE0DF),
    surface = Color(0xFF1E1B1B),
    onSurface = Color(0xFFECE0DF),
    surfaceVariant = Color(0xFF2D2727),
    onSurfaceVariant = Color(0xFFD8C2BF),
    outline = Color(0xFFA08C8A),
    outlineVariant = Color(0xFF3D3433),
)

/** Background + icon colors of a tool category chip. */
data class Accent(val container: Color, val content: Color)

val AccentRedLight = Accent(Color(0xFFFFE3E0), Color(0xFFC62828))
val AccentRedDark = Accent(Color(0xFF4A1F1C), Color(0xFFFFB4AB))
val AccentIndigoLight = Accent(Color(0xFFE3E7FF), Color(0xFF3949AB))
val AccentIndigoDark = Accent(Color(0xFF262B4D), Color(0xFFB8C3FF))
val AccentTealLight = Accent(Color(0xFFD9F2EE), Color(0xFF00796B))
val AccentTealDark = Accent(Color(0xFF153B36), Color(0xFF7DDBCB))
val AccentAmberLight = Accent(Color(0xFFFFF0D6), Color(0xFFB26A00))
val AccentAmberDark = Accent(Color(0xFF3E2E12), Color(0xFFFFCC80))

/** Gradient of the big "Open a PDF" card. */
val HeroGradientLight = listOf(Color(0xFFE53935), Color(0xFFFF7043))
val HeroGradientDark = listOf(Color(0xFF8C1D18), Color(0xFFB0412A))

/** Backdrop behind PDF pages in the viewer. */
val ViewerBackdropLight = Color(0xFFE8E4E4)
val ViewerBackdropDark = Color(0xFF0E0D0D)
