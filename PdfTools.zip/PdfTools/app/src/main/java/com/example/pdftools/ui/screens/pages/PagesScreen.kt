@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.example.pdftools.ui.screens.pages

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pdftools.R
import com.example.pdftools.ui.Tool
import com.example.pdftools.ui.components.BottomActionBar
import com.example.pdftools.ui.components.MessageEffect
import com.example.pdftools.ui.components.PageThumbnail
import com.example.pdftools.ui.components.PickFileCard
import com.example.pdftools.ui.components.ResultSheet
import com.example.pdftools.ui.components.SourceFileCard
import com.example.pdftools.ui.components.ToolScaffold
import com.example.pdftools.ui.components.WorkingCard

private const val THUMB_WIDTH_PX = 320

@Composable
fun PagesScreen(
    onBack: () -> Unit,
    onOpenPdf: (Uri) -> Unit,
    onNavigate: (String) -> Unit,
    viewModel: PagesViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    MessageEffect(state.message, snackbarHostState, viewModel::messageShown)

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.load(uri)
    }
    val pick: () -> Unit = { picker.launch(arrayOf("application/pdf")) }
    val source = state.source

    ToolScaffold(
        title = stringResource(R.string.tool_pages),
        onBack = onBack,
        snackbarHostState = snackbarHostState,
        actions = {
            if (source != null && !state.working) {
                IconButton(onClick = { viewModel.rotateAll(90) }) {
                    Icon(Icons.Filled.RotateRight, contentDescription = stringResource(R.string.action_rotate_all))
                }
                IconButton(onClick = viewModel::reset, enabled = state.isModified) {
                    Icon(Icons.Filled.Restore, contentDescription = stringResource(R.string.action_reset))
                }
            }
        },
        bottomBar = {
            if (source != null) {
                BottomActionBar {
                    Text(
                        stringResource(R.string.pages_count, state.pages.size),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f),
                    )
                    Button(onClick = viewModel::save, enabled = !state.working && state.isModified) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.action_save))
                    }
                }
            }
        },
    ) { padding ->
        if (source == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (state.loading) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                } else {
                    PickFileCard(
                        icon = Icons.Filled.GridView,
                        title = stringResource(R.string.pages_empty_title),
                        description = stringResource(R.string.pages_empty_desc),
                        buttonText = stringResource(R.string.action_choose_pdf),
                        onPick = pick,
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 156.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item(key = "header", span = { GridItemSpan(maxLineSpan) }) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SourceFileCard(source = source, onChange = if (state.working) null else pick)
                        if (state.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                        Text(
                            stringResource(R.string.pages_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (state.working) WorkingCard(progress = null)
                    }
                }
                itemsIndexed(state.pages, key = { _, tile -> tile.sourceIndex }) { position, tile ->
                    PageTileCard(
                        position = position,
                        tile = tile,
                        isFirst = position == 0,
                        isLast = position == state.pages.lastIndex,
                        enabled = !state.working,
                        loader = viewModel::thumbnail,
                        onRotate = { viewModel.rotate(position, 90) },
                        onMoveBack = { viewModel.move(position, -1) },
                        onMoveForward = { viewModel.move(position, 1) },
                        onDelete = { viewModel.delete(position) },
                        modifier = Modifier.animateItemPlacement(),
                    )
                }
            }
        }
    }
    state.result?.let { result ->
        ResultSheet(
            result = result,
            onDismiss = viewModel::clearResult,
            onOpenPdf = { onOpenPdf(it.uri) },
            onContinue = { tool, file -> onNavigate(tool.route(file.uri.toString())) },
            exclude = Tool.PAGES,
        )
    }
}

@Composable
private fun PageTileCard(
    position: Int,
    tile: PageTile,
    isFirst: Boolean,
    isLast: Boolean,
    enabled: Boolean,
    loader: suspend (Int, Int) -> Bitmap?,
    onRotate: () -> Unit,
    onMoveBack: () -> Unit,
    onMoveForward: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    OutlinedCard(modifier = modifier.fillMaxWidth()) {
        Box {
            PageThumbnail(
                pageIndex = tile.sourceIndex,
                widthPx = THUMB_WIDTH_PX,
                loader = loader,
                rotation = tile.rotation,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
            )
            Text(
                text = "${position + 1}",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(horizontal = 8.dp, vertical = 2.dp),
            )
        }
        Text(
            text = if (tile.rotation != 0) {
                stringResource(R.string.pages_original_rotated, tile.sourceIndex + 1, tile.rotation)
            } else {
                stringResource(R.string.pages_original, tile.sourceIndex + 1)
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 10.dp),
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            SmallIconButton(onMoveBack, enabled && !isFirst) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, stringResource(R.string.action_move_before))
            }
            SmallIconButton(onRotate, enabled) {
                Icon(Icons.Filled.RotateRight, stringResource(R.string.action_rotate))
            }
            SmallIconButton(onDelete, enabled) {
                Icon(Icons.Filled.Delete, stringResource(R.string.action_delete))
            }
            SmallIconButton(onMoveForward, enabled && !isLast) {
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, stringResource(R.string.action_move_after))
            }
        }
    }
}

@Composable
private fun SmallIconButton(onClick: () -> Unit, enabled: Boolean, content: @Composable () -> Unit) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(36.dp), content = content)
}
