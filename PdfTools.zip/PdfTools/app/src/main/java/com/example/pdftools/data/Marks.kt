package com.example.pdftools.data

/** Point on a page, as fractions of the page *as displayed* (0,0 = top-left, 1,1 = bottom-right). */
data class MarkPoint(val x: Float, val y: Float)

enum class MarkType { PEN, HIGHLIGHT, RECT, TEXT }

/**
 * Something drawn by the user on a page (annotate tool).
 * - PEN / HIGHLIGHT: free-hand stroke through [points]; [size] = stroke width / page width.
 * - RECT: rectangle between points[0] and points[1]; [size] = stroke width / page width.
 * - TEXT: [text] whose top-left corner is points[0]; [size] = text box height / page width.
 */
data class Mark(
    val id: Long,
    val page: Int,
    val type: MarkType,
    val points: List<MarkPoint>,
    /** ARGB color. */
    val color: Int,
    val size: Float,
    val text: String = "",
)

/** One field of a fillable PDF form. */
data class FormField(
    /** Fully qualified name: unique key used to fill the field. */
    val key: String,
    val label: String,
    val kind: FormFieldKind,
    val value: String,
    /** Choices for CHOICE / RADIO fields. */
    val options: List<String> = emptyList(),
    val readOnly: Boolean = false,
)

enum class FormFieldKind { TEXT, CHECKBOX, RADIO, CHOICE }
