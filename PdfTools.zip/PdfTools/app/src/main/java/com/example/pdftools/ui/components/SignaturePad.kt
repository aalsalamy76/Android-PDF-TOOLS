package com.example.pdftools.ui.components

import android.graphics.Bitmap
import android.graphics.Paint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.pdftools.R
import kotlin.math.ceil

/** Ink colors offered on the pad: black, blue, dark red. */
private val InkColors = listOf(Color(0xFF111111), Color(0xFF0D47A1), Color(0xFF8E0000))

/**
 * Full screen pad where the user draws a signature with the finger.
 * [onSave] receives a tightly cropped, transparent PNG-ready bitmap.
 */
@Composable
fun SignaturePadDialog(onDismiss: () -> Unit, onSave: (Bitmap) -> Unit) {
    val strokes = remember { mutableStateListOf<List<Offset>>() }
    val current = remember { mutableStateListOf<Offset>() }
    var ink by remember { mutableStateOf(InkColors.first()) }
    var thicknessDp by remember { mutableFloatStateOf(4f) }
    val density = LocalDensity.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(stringResource(R.string.sign_pad_title), style = MaterialTheme.typography.titleLarge)
                Text(
                    stringResource(R.string.sign_pad_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                // Drawing area (always white, like paper). Forced LTR: raw touch coordinates.
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp)),
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    awaitEachGesture {
                                        val down = awaitFirstDown()
                                        current.clear()
                                        current.add(down.position)
                                        down.consume()
                                        while (true) {
                                            val event = awaitPointerEvent()
                                            val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                            if (!change.pressed) break
                                            current.add(change.position)
                                            change.consume()
                                        }
                                        strokes.add(current.toList())
                                        current.clear()
                                    }
                                },
                        ) {
                            val width = thicknessDp.dp.toPx()
                            // Signature base line
                            val lineY = size.height * 0.75f
                            drawLine(
                                color = Color(0x22000000),
                                start = Offset(size.width * 0.08f, lineY),
                                end = Offset(size.width * 0.92f, lineY),
                                strokeWidth = 2f,
                            )
                            strokes.forEach { drawInk(it, ink, width) }
                            drawInk(current, ink, width)
                        }
                    }
                }

                // Ink color + thickness
                Row(verticalAlignment = Alignment.CenterVertically) {
                    InkColors.forEach { color ->
                        Box(
                            modifier = Modifier
                                .padding(end = 10.dp)
                                .size(if (color == ink) 34.dp else 28.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (color == ink) 3.dp else 0.dp,
                                    color = MaterialTheme.colorScheme.primary,
                                    shape = CircleShape,
                                )
                                .clickable { ink = color },
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.sign_thickness), style = MaterialTheme.typography.labelLarge)
                    Slider(
                        value = thicknessDp,
                        onValueChange = { thicknessDp = it },
                        valueRange = 2f..10f,
                        modifier = Modifier.weight(1f),
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { strokes.clear(); current.clear() }) {
                        Text(stringResource(R.string.action_clear))
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = strokes.isNotEmpty(),
                        onClick = {
                            val strokePx = with(density) { thicknessDp.dp.toPx() }
                            val bitmap = renderSignature(strokes.toList(), ink.toArgb(), strokePx)
                            if (bitmap != null) onSave(bitmap)
                        },
                    ) { Text(stringResource(R.string.action_use_signature)) }
                }
            }
        }
    }
}

private fun DrawScope.drawInk(points: List<Offset>, color: Color, width: Float) {
    if (points.isEmpty()) return
    if (points.size == 1) {
        drawCircle(color = color, radius = width / 2f, center = points[0])
        return
    }
    val path = Path()
    path.moveTo(points[0].x, points[0].y)
    for (i in 1 until points.size) {
        val previous = points[i - 1]
        val point = points[i]
        path.quadraticBezierTo(previous.x, previous.y, (previous.x + point.x) / 2f, (previous.y + point.y) / 2f)
    }
    path.lineTo(points.last().x, points.last().y)
    drawPath(path, color = color, style = Stroke(width = width, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

/** Draws the strokes on a transparent bitmap cropped to the ink (2x for sharpness). */
private fun renderSignature(strokes: List<List<Offset>>, inkColor: Int, strokePx: Float): Bitmap? {
    val points = strokes.flatten()
    if (points.isEmpty()) return null
    val pad = strokePx * 2f
    val minX = points.minOf { it.x } - pad
    val minY = points.minOf { it.y } - pad
    val maxX = points.maxOf { it.x } + pad
    val maxY = points.maxOf { it.y } + pad
    val scale = 2f
    val width = ceil((maxX - minX) * scale).toInt().coerceAtLeast(1)
    val height = ceil((maxY - minY) * scale).toInt().coerceAtLeast(1)

    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bitmap)
    canvas.scale(scale, scale)
    canvas.translate(-minX, -minY)

    val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = inkColor
        style = Paint.Style.STROKE
        strokeWidth = strokePx
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = inkColor
        style = Paint.Style.FILL
    }
    strokes.forEach { stroke ->
        if (stroke.size == 1) {
            canvas.drawCircle(stroke[0].x, stroke[0].y, strokePx / 2f, dotPaint)
        } else if (stroke.size > 1) {
            val path = android.graphics.Path()
            path.moveTo(stroke[0].x, stroke[0].y)
            for (i in 1 until stroke.size) {
                val previous = stroke[i - 1]
                val point = stroke[i]
                path.quadTo(previous.x, previous.y, (previous.x + point.x) / 2f, (previous.y + point.y) / 2f)
            }
            path.lineTo(stroke.last().x, stroke.last().y)
            canvas.drawPath(path, strokePaint)
        }
    }
    return bitmap
}
