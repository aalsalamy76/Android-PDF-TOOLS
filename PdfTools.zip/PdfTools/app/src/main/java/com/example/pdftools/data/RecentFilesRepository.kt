package com.example.pdftools.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class RecentFile(
    val uri: String,
    val name: String,
    val size: Long,
    val openedAt: Long,
)

/** Keeps the last opened PDFs (stored locally in SharedPreferences as JSON). */
class RecentFilesRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("recent_files", Context.MODE_PRIVATE)

    private val _items = MutableStateFlow(read())
    val items: StateFlow<List<RecentFile>> = _items.asStateFlow()

    /** Keeps read access to a picked document after the app restarts. */
    fun takePersistablePermission(uri: Uri) {
        try {
            context.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
            // Not a document picked with ACTION_OPEN_DOCUMENT: nothing to persist.
        }
    }

    @Synchronized
    fun add(uri: Uri, name: String, size: Long) {
        val key = uri.toString()
        val updated = listOf(RecentFile(key, name, size, System.currentTimeMillis())) +
            _items.value.filterNot { it.uri == key }
        updated.drop(MAX_ITEMS).forEach { release(it.uri) }
        save(updated.take(MAX_ITEMS))
    }

    @Synchronized
    fun remove(uri: String) {
        release(uri)
        save(_items.value.filterNot { it.uri == uri })
    }

    @Synchronized
    fun clear() {
        _items.value.forEach { release(it.uri) }
        save(emptyList())
    }

    private fun release(uri: String) {
        try {
            context.contentResolver.releasePersistableUriPermission(
                Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
    }

    private fun save(list: List<RecentFile>) {
        val array = JSONArray()
        list.forEach { item ->
            array.put(
                JSONObject()
                    .put("uri", item.uri)
                    .put("name", item.name)
                    .put("size", item.size)
                    .put("time", item.openedAt)
            )
        }
        prefs.edit().putString(KEY, array.toString()).apply()
        _items.value = list
    }

    private fun read(): List<RecentFile> = try {
        val array = JSONArray(prefs.getString(KEY, "[]") ?: "[]")
        List(array.length()) { i ->
            val o = array.getJSONObject(i)
            RecentFile(
                uri = o.getString("uri"),
                name = o.optString("name", "document.pdf"),
                size = o.optLong("size", -1L),
                openedAt = o.optLong("time", 0L),
            )
        }
    } catch (_: Exception) {
        emptyList()
    }

    private companion object {
        const val KEY = "items"
        const val MAX_ITEMS = 20
    }
}
