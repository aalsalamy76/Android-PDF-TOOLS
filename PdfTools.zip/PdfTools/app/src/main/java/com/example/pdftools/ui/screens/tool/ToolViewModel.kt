package com.example.pdftools.ui.screens.tool

import android.app.Application
import android.net.Uri
import android.text.format.Formatter
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.pdftools.R
import com.example.pdftools.data.MIME_PDF
import com.example.pdftools.data.OperationResult
import com.example.pdftools.data.PdfRepository
import com.example.pdftools.data.SourcePdf
import com.example.pdftools.data.baseNameOf
import com.example.pdftools.data.container
import com.example.pdftools.navigation.Routes
import com.example.pdftools.ui.Tool
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import com.example.pdftools.util.uiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Ink colors offered for the watermark. */
val WatermarkColors: List<Int> = listOf(
    0xFFD32F2F.toInt(), // red
    0xFF616161.toInt(), // grey
    0xFF1565C0.toInt(), // blue
    0xFF2E7D32.toInt(), // green
)

data class ToolUiState(
    val tool: Tool,
    val source: SourcePdf? = null,
    val loading: Boolean = false,
    // Compress
    val compressLevel: PdfRepository.CompressLevel = PdfRepository.CompressLevel.MEDIUM,
    // Protect / unlock
    val password: String = "",
    val confirm: String = "",
    val passwordError: UiText? = null,
    // Page numbers
    val numberPosition: PdfRepository.NumberPosition = PdfRepository.NumberPosition.BOTTOM_CENTER,
    val numberWithTotal: Boolean = false,
    // Watermark
    val watermarkText: String = "",
    val watermarkColor: Int = WatermarkColors.first(),
    val watermarkOpacity: Float = 0.3f,
    val watermarkDiagonal: Boolean = true,
    // Common
    val working: Boolean = false,
    val progress: Float = 0f,
    val result: OperationResult? = null,
    val message: UiText? = null,
)

/**
 * One screen for the single-file tools: compress, protect, unlock, page numbers, watermark.
 * The tool comes from the navigation route ("tool/COMPRESS").
 */
class ToolViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    private val tool: Tool = savedStateHandle.get<String>(Routes.ARG_KIND)
        ?.let { kind -> Tool.values().firstOrNull { it.name == kind } }
        ?: Tool.COMPRESS

    private val _state = MutableStateFlow(ToolUiState(tool = tool))
    val state: StateFlow<ToolUiState> = _state.asStateFlow()

    init {
        savedStateHandle.get<String>(Routes.ARG_URI)?.let { load(Uri.parse(it)) }
    }

    fun load(uri: Uri) {
        viewModelScope.launch {
            _state.update { it.copy(loading = true, result = null, password = "", confirm = "", passwordError = null) }
            ioCatching { container.openSource(uri, allowLocked = tool == Tool.UNLOCK) }
                .onSuccess { pdf -> _state.update { it.copy(loading = false, source = pdf) } }
                .onFailure { error -> _state.update { it.copy(loading = false, message = error.toUiText()) } }
        }
    }

    fun setCompressLevel(level: PdfRepository.CompressLevel) = _state.update { it.copy(compressLevel = level) }
    fun setPassword(value: String) = _state.update { it.copy(password = value, passwordError = null) }
    fun setConfirm(value: String) = _state.update { it.copy(confirm = value, passwordError = null) }
    fun setNumberPosition(value: PdfRepository.NumberPosition) = _state.update { it.copy(numberPosition = value) }
    fun setNumberWithTotal(value: Boolean) = _state.update { it.copy(numberWithTotal = value) }
    fun setWatermarkText(value: String) = _state.update { it.copy(watermarkText = value.take(60)) }
    fun setWatermarkColor(value: Int) = _state.update { it.copy(watermarkColor = value) }
    fun setWatermarkOpacity(value: Float) = _state.update { it.copy(watermarkOpacity = value) }
    fun setWatermarkDiagonal(value: Boolean) = _state.update { it.copy(watermarkDiagonal = value) }

    fun canRun(s: ToolUiState): Boolean = s.source != null && !s.working && when (tool) {
        Tool.PROTECT -> s.password.isNotEmpty() && s.confirm.isNotEmpty()
        Tool.UNLOCK -> !s.source.locked || s.password.isNotEmpty()
        Tool.WATERMARK -> s.watermarkText.isNotBlank()
        else -> true
    }

    fun execute() {
        val s = _state.value
        val source = s.source ?: return
        if (!canRun(s)) return
        if (tool == Tool.PROTECT) {
            if (s.password.length < MIN_PASSWORD) {
                _state.update { it.copy(passwordError = uiText(R.string.error_password_short, MIN_PASSWORD)) }
                return
            }
            if (s.password != s.confirm) {
                _state.update { it.copy(passwordError = uiText(R.string.error_password_mismatch)) }
                return
            }
        }
        viewModelScope.launch {
            _state.update { it.copy(working = true, progress = 0f, result = null) }
            ioCatching {
                val base = baseNameOf(source.name)
                val suffix = when (tool) {
                    Tool.COMPRESS -> "compressed"
                    Tool.PROTECT -> "protected"
                    Tool.UNLOCK -> "unlocked"
                    Tool.PAGE_NUMBERS -> "numbered"
                    else -> "watermark"
                }
                val output = container.files.newOutputFile("${base}_$suffix.pdf")
                val progress: (Float) -> Unit = { p -> _state.update { st -> st.copy(progress = p * 0.9f) } }
                when (tool) {
                    Tool.COMPRESS -> container.pdf.compress(source.file, output, s.compressLevel, progress)
                    Tool.PROTECT -> container.pdf.protect(source.file, output, s.password)
                    Tool.UNLOCK -> container.pdf.unlock(source.file, s.password, output)
                    Tool.PAGE_NUMBERS -> container.pdf.addPageNumbers(
                        source.file, output, s.numberPosition, s.numberWithTotal, progress
                    )
                    else -> {
                        val stamp = container.pdf.renderTextStamp(
                            s.watermarkText.trim(), s.watermarkColor, s.watermarkOpacity
                        )
                        container.pdf.addWatermark(source.file, output, stamp, s.watermarkDiagonal, progress)
                    }
                }
                val summary: UiText? = if (tool == Tool.COMPRESS) {
                    val before = source.size.coerceAtLeast(1L)
                    val after = output.length()
                    val app = getApplication<Application>()
                    if (after < before) {
                        val saved = ((before - after) * 100.0 / before).roundToInt()
                        uiText(
                            R.string.compress_summary,
                            Formatter.formatShortFileSize(app, before),
                            Formatter.formatShortFileSize(app, after),
                            saved,
                        )
                    } else {
                        uiText(R.string.compress_no_gain)
                    }
                } else {
                    null
                }
                container.files.publish(listOf(output), MIME_PDF).copy(summary = summary)
            }.onSuccess { result ->
                _state.update { it.copy(working = false, result = result, password = "", confirm = "") }
            }.onFailure { error ->
                _state.update { it.copy(working = false, message = error.toUiText()) }
            }
        }
    }

    fun clearResult() = _state.update { it.copy(result = null) }

    fun messageShown() = _state.update { it.copy(message = null) }

    private companion object {
        const val MIN_PASSWORD = 4
    }
}
