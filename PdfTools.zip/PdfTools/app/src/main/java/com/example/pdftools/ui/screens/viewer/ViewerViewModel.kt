package com.example.pdftools.ui.screens.viewer

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.util.Size
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.pdftools.R
import com.example.pdftools.data.PdfPageRenderer
import com.example.pdftools.data.container
import com.example.pdftools.navigation.Routes
import com.example.pdftools.util.AppException
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import com.example.pdftools.util.uiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class ViewerUiState(
    val loading: Boolean = true,
    val fileName: String = "",
    val fileSize: Long = 0,
    val pageCount: Int = 0,
    val pageSizes: List<Size> = emptyList(),
    val error: UiText? = null,
    /** The file is password protected: ask for the password. */
    val needsPassword: Boolean = false,
    /** Opened after typing the password (tools must start with "Unlock"). */
    val wasLocked: Boolean = false,
    val unlocking: Boolean = false,
    val passwordError: UiText? = null,
) {
    val ready: Boolean get() = !loading && error == null && !needsPassword && pageCount > 0
}

class ViewerViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    /** The document URI as received from navigation (also passed to the other tools). */
    val uriString: String? = savedStateHandle.get<String>(Routes.ARG_URI)

    private val _state = MutableStateFlow(ViewerUiState())
    val state: StateFlow<ViewerUiState> = _state.asStateFlow()

    private var renderer: PdfPageRenderer? = null

    /** Private copy of the original document (used for sharing). */
    var sourceFile: File? = null
        private set

    init {
        load()
    }

    fun load() {
        val uri = uriString?.let(Uri::parse)
        if (uri == null) {
            _state.value = ViewerUiState(loading = false, error = uiText(R.string.error_file_not_found))
            return
        }
        viewModelScope.launch {
            _state.value = ViewerUiState(loading = true)
            ioCatching {
                val info = container.files.queryInfo(uri)
                val file = container.files.copyToCache(uri, info.name)
                val size = if (info.size >= 0) info.size else file.length()
                container.recents.takePersistablePermission(uri)
                container.recents.add(uri, info.name, size)
                Triple(info.name, size, file)
            }.onSuccess { (name, size, file) ->
                sourceFile = file
                _state.update { it.copy(fileName = name, fileSize = size) }
                openRenderer(file)
            }.onFailure { error ->
                _state.update { it.copy(loading = false, error = error.toUiText()) }
            }
        }
    }

    private suspend fun openRenderer(file: File) {
        ioCatching { PdfPageRenderer.open(file) }
            .onSuccess { newRenderer ->
                renderer?.close()
                renderer = newRenderer
                _state.update {
                    it.copy(
                        loading = false,
                        needsPassword = false,
                        pageCount = newRenderer.pageCount,
                        pageSizes = newRenderer.pageSizes,
                    )
                }
            }
            .onFailure { error ->
                if (error is SecurityException) {
                    _state.update { it.copy(loading = false, needsPassword = true) }
                } else {
                    _state.update { it.copy(loading = false, error = error.toUiText()) }
                }
            }
    }

    /** Decrypts a private copy with [password] and shows it. */
    fun submitPassword(password: String) {
        val file = sourceFile ?: return
        if (password.isEmpty() || _state.value.unlocking) return
        viewModelScope.launch {
            _state.update { it.copy(unlocking = true, passwordError = null) }
            ioCatching {
                val output = File(file.parentFile, "unlocked_" + file.name)
                container.pdf.unlock(file, password, output)
                output
            }.onSuccess { output ->
                _state.update { it.copy(unlocking = false, wasLocked = true, loading = true) }
                openRenderer(output)
            }.onFailure { error ->
                val message = if (error is AppException) error.text else error.toUiText()
                _state.update { it.copy(unlocking = false, passwordError = message) }
            }
        }
    }

    suspend fun renderPage(index: Int, widthPx: Int): Bitmap? =
        renderer?.renderOrNull(index, widthPx)

    override fun onCleared() {
        renderer?.close()
        renderer = null
    }
}
