package com.example.pdftools.ui.screens.viewer

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import com.example.pdftools.R
import com.example.pdftools.data.PdfPageRenderer
import com.example.pdftools.data.SourcePdf
import com.example.pdftools.data.container
import com.example.pdftools.navigation.Routes
import com.example.pdftools.util.UiText
import com.example.pdftools.util.ioCatching
import com.example.pdftools.util.toUiText
import com.example.pdftools.util.uiText
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ViewerUiState(
    val loading: Boolean = true,
    val fileName: String = "",
    val pageCount: Int = 0,
    val error: UiText? = null,
)

class ViewerViewModel(
    application: Application,
    savedStateHandle: SavedStateHandle,
) : AndroidViewModel(application) {

    /** The document URI as received from navigation (also passed to the other tools). */
    val uriString: String? = savedStateHandle.get<String>(Routes.ARG_URI)

    private val _state = MutableStateFlow(ViewerUiState())
    val state: StateFlow<ViewerUiState> = _state.asStateFlow()

    private var renderer: PdfPageRenderer? = null

    var source: SourcePdf? = null
        private set

    init {
        load()
    }

    fun load() {
        val uri = uriString?.let(Uri::parse)
        if (uri == null) {
            _state.value = ViewerUiState(loading = false, error = uiText(R.string.error_file_not_found))
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(loading = true, error = null) }
            ioCatching {
                val pdf = container.openSource(uri)
                pdf to PdfPageRenderer.open(pdf.file)
            }.onSuccess { (pdf, newRenderer) ->
                renderer?.close()
                renderer = newRenderer
                source = pdf
                _state.value = ViewerUiState(
                    loading = false,
                    fileName = pdf.name,
                    pageCount = newRenderer.pageCount,
                )
            }.onFailure { error ->
                _state.update { it.copy(loading = false, error = error.toUiText()) }
            }
        }
    }

    suspend fun renderPage(index: Int, widthPx: Int): Bitmap? =
        renderer?.renderOrNull(index, widthPx)

    override fun onCleared() {
        renderer?.close()
        renderer = null
    }
}
