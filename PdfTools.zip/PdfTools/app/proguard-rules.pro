# Only used if you enable minification (isMinifyEnabled = true) for release builds.

# PdfBox-Android loads resources and classes reflectively.
-keep class com.tom_roush.pdfbox.** { *; }
-keep class com.tom_roush.fontbox.** { *; }
-keep class com.tom_roush.harmony.** { *; }

# Optional JPEG2000 decoder referenced by PdfBox-Android (not bundled).
-dontwarn com.gemalto.jp2.**
-dontwarn org.bouncycastle.**
